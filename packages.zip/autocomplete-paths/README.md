# autocomplete+ paths suggestions [![Build Status](https://travis-ci.org/atom-community/autocomplete-paths.svg?branch=master)](https://travis-ci.org/atom-community/autocomplete-paths)

[![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/atom-community/autocomplete-paths?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

[View the changelog](https://github.com/atom-community/autocomplete-paths/blob/master/CHANGELOG.md)

Adds path autocompletion to autocomplete+

![autocomplete-paths](http://s1.directupload.net/images/140411/p5kvife6.gif)

## Installation

You can install autocomplete-paths using the Preferences pane.

**Please make sure you have autocomplete-plus installed as well**
