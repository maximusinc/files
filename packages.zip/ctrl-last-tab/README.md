# ctrl-last-tab package

A package for the Atom editor, which allows you to go to previous tabs by pressing ctrl-tab.
