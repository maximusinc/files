# A Monokai Theme
## Inspired by Sublime Text

A Monokai syntax theme for Atom.

Forked from [kevinsawicki's Monokai](https://github.com/kevinsawicki/monokai) Theme, but made more consistent with the theme from Sublime Text
