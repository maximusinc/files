var Foo = require('foo');
