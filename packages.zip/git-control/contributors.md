## This is a list of contributors that helped improve and create git-control in a major way
- [Antoine Weber](https://github.com/TwanoO67)
- [nounoursheureux](https://github.com/nounoursheureux)
- [Nishanth Shankar] (https://github.com/NishanthShankar)
- [Julian Reyes Escrigas] (https://github.com/rkmax)
