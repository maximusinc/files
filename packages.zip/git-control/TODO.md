- focus on critical issues (bugs, performance)

- prompt should just "sit there" - i.e. mark-khan's issue
