(function () {
	var defaultKeyWordsMap = ['default'];
	var targetingManager = {
		timeout: 2000,
		def: $.Deferred(),
		endPoint: 'http://webapi.pad.mgf.hosted:8080/webapi-3.0/targetedOfferings',
		_val: null,
		_setVal: function (val) {
			if (this._val) {
				return;
			} else {
				this._val = val;
			}
		},
		get: function () {
			this.request();
			this.timer();
			return this.def.promise();
		},
		proccesResponse: function (jsonResp) {
			var result = [];
			$.each(jsonResp, function (i,item) {
				result.push( item.id );
			});

			if (result.length) {
				this._setVal( window.encodeURIComponent(result.join(' ')) );
				this.def.resolve( window.encodeURIComponent(result.join(' ')) );
			} else {
				this.resolveDefault();
			}
		},
		request: function () {
			var self = this;
			$.ajax({
				url: self.endPoint,
				dataType: 'json',
				success: function (json) {
					self.proccesResponse(json);
				},
				error: function () {
					self.resolveDefault();
				}
			})
		},
		timer: function () {
			var self = this;
			window.setTimeout(function () {
				if (!self._val) {
					console.info("timer > " + self.timeout);
					self.resolveDefault();
				}
			}, self.timeout);
		},
		resolveDefault: function () {
			this._setVal( window.encodeURIComponent( defaultKeyWordsMap.join(' ') ) );
			this.def.resolve( window.encodeURIComponent( defaultKeyWordsMap.join(' ') ) );
		},
		val: function () {
			return this._val;
		}
	};
	var addFoxHelper = {
		getSrc: function (keyWordData) {
			var pr = Math.floor(Math.random() * 1000000);
			var addate = new Date();
			return '//ads.adfox.ru/228840/getCode?pp=g&ps=bvxe&p2=c&p3=a&p4=a&pct=a&plp=a&pli=a&pop=a&pr=' + pr + '&pt=b&pd=' + addate.getDate() + '&pw=' + addate.getDay() + '&pv=' + addate.getHours() + '&pk=' + keyWordData + '&pke=1';
		},
		getIframeHTML: function (keyWordData) {
			return '<iframe id="AddFox_frame" src="' + this.getSrc(keyWordData) + '" frameborder="1" width="468" height="60" marginWidth="0" marginHeight="0" scrolling="no" style="border: 0px; margin: 0px; padding: 0px;" ></iframe>';
		}
	};
	var BannerWrapper = function () {
		this.$el = $('<div>');
		this.$el.attr('id','RooX_Wrapper_'+this.rnd());
		this.$el.css({
			position: 'relative'
		});
		this.$clickEl = $('<div>');
		this.$clickEl.css({
			width: '468px',
			height: '60px',
			position: 'absolute',
			top: 0,
			left: 0,
			background: 'transparent',
			cursor: 'pointer'
		});
	};

	BannerWrapper.prototype = {
		rnd: function() {
            return Math.floor(Math.random() * 1e6)
        },
        insert: function ($el) {
        	$el = $el || $('body');
        	$el.append(this.$el);
        },
        setContent: function (html) {
        	this.$el.html(html);
        	// this.$el.append(this.$clickEl);
        	this.registerHandlers();
        },
        registerHandlers: function () {
        	var self = this;
        	self.$ifr = this.$el.find('iframe');
        	self.$ifr.on('load', function () {
        		console.log('log display');
        		com.rooxteam.statistic.client.logOperation('bannerDisplay', {name: 'some'});
        	});
        	// this.$clickEl.mousedown( function () {
        	// 	self.$clickEl.hide();
        	// 	console.log('log click');
        		// window.setTimeout(function () {
        		// 	self.$clickEl.show();
        		// });
        	//});
        	// this.$clickEl.mouseup( function () {
        	// 	self.$clickEl.hide();
        	// 	console.log('log click uuuuuuuup');
        	// 	// window.setTimeout(function () {
        	// 	// 	self.$clickEl.show();
        	// 	// });
        	// });
        	$(window).blur(function(event){
			    if (document.activeElement === self.$ifr.get(0)) {
			    	com.rooxteam.statistic.client.logOperation('bannerClicked', {name: 'some'});
			    	console.info('log bannerClicked');
			    }
			    window.setTimeout(function () {
			    	$(window).focus();
			    }, 10);
			});
        	$(document).on('click', function  () {
        		console.log('log doc click');
        	});
        }
	};

	$(function () {
		var banner = new BannerWrapper();
		banner.insert($('#main'));
		targetingManager.get().done(function (keyWordData) {
			banner.setContent(addFoxHelper.getIframeHTML(keyWordData));
		});

	});
	window.addFoxHelper = addFoxHelper;
	window.BannerWrapper = BannerWrapper;
})();