(function () {
	window.addEventListener('resize', function (e) {
		console.log('resize', e);
	});
})();