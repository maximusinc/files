window.rooxTargetingManager = (function ($) {

	var config = {
		defaultKeyWordsMap: ['default'],
		targetingEndpoint: 'http://sso.mgf.hosted:8080/webapi-3.0/targetedOfferings',
		contextScripts: [ 'http://sso.mgf.hosted:8080/banner-client/scripts/rooxmgf/cdn/mobile.build-1.0.1.min.js' ],
		redirectorPrefix: 'http://sso.mgf.hosted:8080/redirector-10/redirect?goto=',
		contextStatisticOverrides: {
			ACCUMULATE_OPERATION_LIMIT: 0,
			SERVER_ADDRESS: 'http://sso.mgf.hosted:8080/pushreport/'
		}
	};
	/* Context constructor for executing external scripts */
	var RooxContext = function () {
		this.pr1 = this.rnd();
		this.$iframe = null;
		this.contentWindow = null;
		this.loaded = [];
		this.srcScripts = config.contextScripts;
	};

	RooxContext.prototype = {
		rnd: function() {
            return Math.floor(Math.random() * 1e6);
        },
        insert: function ($el) {
        	$el = $el || $('body');
        	$el.append(this.$el);
        },
        addScripts: function () {
        	console.warn('addd script');
        	var src;
        	for( var index in this.srcScripts ) {
        		src = this.srcScripts[index];
        		this.loadScripts(src);
        	}
        },
        overrideStaticticConfig: function () {
        	console.warn('overrideStaticticConfig');
        	 try {
        		var statConfig = this.contentWindow.com.rooxteam.config.statistic;
        		for (var prop in config.contextStatisticOverrides) {
        			statConfig[ prop ] = config.contextStatisticOverrides[ prop ];
        		}
        	}catch (e) {

        	}
        },
        loadScripts: function (link) {
        	var self = this,
        		script;
        	try {
	            if (this.contentDocument) {
	                if (+"1") {
	                    this.contentDocument.open();
	                    this.contentDocument.close()
	                }
	                link = link.replace(/&amp;/g, "&");
	                script = this.contentDocument.createElement("script");
	                script.src = link;
	                script.onload = function() {
	                	self.loaded.push(link);
	                };
	                script.onerror = function() {

	                };
	                tryAppendScript();
	            }
	        } catch (h) {

	        }
	        function tryAppendScript() {
	            setTimeout(function() {
	                var head = self.contentDocument.getElementsByTagName("head")[0];
	                if (head) {
	                    head.appendChild(script);
	                } else {
	                    tryAppendScript();
	                }
	            }, 30);
	        }
        },
        tryGetWindow: function () {
        	var iframe;
        	try {
        		if (document.all && !window.opera) {
	                iframe = window.frames["Roox_iframe_" + this.pr1];
	                this.contentDocument = iframe.document;
	            } else if (document.getElementById) {
	                iframe = document.getElementById("Roox_iframe_" + this.pr1);
	                this.contentDocument = iframe.contentDocument;
	            }
	            this.iframe = iframe;
	            this.contentWindow = (iframe.contentWindow || iframe.contentDocument);
        	} catch (e) {

        	}
        	if ( !this.contentWindow || !this.contentDocument ) {
        		console.warn('tryGetWindow');
        		window.setTimeout(function () {
        			RooxContext.prototype.tryGetWindow.call(RooxContext);
        		}, 100);
        	} else {
        		this.addScripts();
        	}
        },
        init: function () {
        	this.tryGetWindow();
        },
        getCode: function() {
            return '<div style="visibility:hidden; position:absolute;"><iframe id="Roox_iframe_' + this.pr1 + '" width=1 height=1 marginwidth=0 marginheight=0 scrolling=no frameborder=0></iframe></div>';
        },
        getWindow: function () {
        	return this.contentWindow;
        }
	};

	var targetingManager = {
		rooxContext: null,
		timeout: 2000,
		def: $.Deferred(),
		endPoint: config.targetingEndpoint,
		_val: null,
		_setVal: function (val) {
			if (this._val) {
				return;
			} else {
				this._val = val;
			}
		},
		get: function () {
			this.request();
			this.timer();
			return this.def.promise();
		},
		init: function () {
			this.request();
			this.timer();
		},
		wait: function () {
			return this.def.promise();
		},
		proccesResponse: function (jsonResp) {
			var result = [];
			$.each(jsonResp, function (i,item) {
				result.push( item.id );
			});

			if (result.length) {
				this._setVal( window.encodeURIComponent(result.join(' ')) );
				this.def.resolve( window.encodeURIComponent(result.join(' ')) );
			} else {
				this.resolveDefault();
			}
		},
		request: function () {
			var self = this;
			$.ajax({
				url: self.endPoint,
				dataType: 'json',
				success: function (json) {
					self.proccesResponse(json);
				},
				error: function () {
					self.resolveDefault();
				}
			})
		},
		timer: function () {
			var self = this;
			window.setTimeout(function () {
				if (!self._val) {
					console.info("timer > " + self.timeout);
					self.resolveDefault();
				}
			}, self.timeout);
		},
		resolveDefault: function () {
			this._setVal( window.encodeURIComponent( config.defaultKeyWordsMap.join(' ') ) );
			this.def.resolve( window.encodeURIComponent( config.defaultKeyWordsMap.join(' ') ) );
		},
		val: function () {
			return this._val;
		},
		makeRooxContext: function () {
			var rooxContext = new RooxContext();
			return this.rooxContext = rooxContext;
		},
		getRedirector: function () {
        	return config.redirectorPrefix;
        }
	};

	/* Statistic subModule */
	targetingManager.statistic = {
		counter: 0,
		operations: [],
		_tryLogOperations: function (name, data) {
			var self = this, item;
			try {
				for (var i in self.operations) {
					item = self.operations[i];
					targetingManager.rooxContext.contentWindow.com.rooxteam.statistic.client.logOperation(item.name, item.data);
					console.warn('targetingManager.rooxContext.contentWindow.com.rooxteam.statistic.client.logOperation');
				}
				self.operations.length = 0;
			} catch (e) {
				if (self.counter < 5) {
					setTimeout(targetingManager.statistic._tryLogOperations ,100);
				}
			}
			self.counter += 1;
		},
		logOperation: function (name, data) {
			targetingManager.rooxContext.overrideStaticticConfig();
			this.operations.push({
				name: name,
				data: data
			});
			this._tryLogOperations();
		}
	};

	targetingManager.init();
	return targetingManager;

})(window.jQuery);