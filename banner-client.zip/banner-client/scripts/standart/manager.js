(function () {
	console.log('Hello manageer');
	// var addFoxHelper = {
	// 	getSrc: function (pr) {
	// 		if (typeof(pr) == 'undefined') { var pr = Math.floor(Math.random() * 1000000); }
	// 		var addate = new Date();
	// 		return '//ads.adfox.ru/228840/getCode?pp=g&ps=buqk&p2=c&p3=a&p4=a&pct=b&plp=a&pli=a&pop=a&pr=' + pr + '&pt=b&pd=' + addate.getDate() + '&pw=' + addate.getDay() + '&pv=' + addate.getHours() + '&random=671375798';
	// 	},
	// 	getIframeHTML: function () {
	// 		return '<iframe id="AddFox_frame" src="' + this.getSrc() + '" frameborder="1" width="468" height="60" marginWidth="0" marginHeight="0" scrolling="no" style="border: 0px; margin: 0px; padding: 0px;" ></iframe>';
	// 	}
	// };

	// document.body.innerHTML = addFoxHelper.getIframeHTML();

})();