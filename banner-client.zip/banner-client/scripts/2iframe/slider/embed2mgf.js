(function () {
	console.info("Embed 2 MGF");
})();