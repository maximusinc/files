// FFFFFFFFF
(function (window, document) {
	var _p = {};
	if (!document.getElementsByClassName) {
		document.getElementsByClassName = function (class_name) {
			var elements = document.body.getElementsByTagName("*"),
				length = elements.length,
				out = [], i;
			for (i = 0; i < length; i += 1) {
				if (elements[i].className.indexOf(class_name) !== -1) {
					out.push(elements[i]);
				}
			}
			return out;
		};
	}

	var sliderBlock = document.getElementsByClassName('b-banners-slider')[0];

	window.slides = [];
	window.stopSlide = false;
	var list = document.createElement('div'),
		limit = 10,
		testJQ = false,
		curInt,
		count = 0,
		prot = document.location.protocol == 'https:' ? 'https:' : 'http:',
		pr = Math.floor(Math.random() * 9999999),
		cssSliderText = '.b-banners-simple-slider {   width: 100%;   /*border: 1px solid #ccc;*/   overflow: hidden;   position: relative;   height: auto;   margin-bottom: 30px; } .b-banners-simple-slider::-moz-selection {background: transparent; color: #fff; text-shadow: none;} .b-banners-simple-slider::selection {background: transparent; color: #fff; text-shadow: none;}  .b-banners-simple-slider__container {   margin: 0;   padding: 0;   overflow: hidden;   height: 100%; } .b-banners-simple-slider__list {   /*position: relative;   left: 0px;   top: 0;*/   /*width: 100000000px;*/   white-space: nowrap; } .b-banners-simple-slider__item {   width: 100%;   max-width: 1400px;   float: left;   /*margin-bottom: 50px;*/   display:none; } .b-banners-simple-slider__item_state_selected {   display:block; } .b-banners-simple-slider__item-image {   width: 100%;   max-width: 1400px;   border: none; } .b-banners-simple-slider__item-image_size_wide {display:inline-block;} .b-banners-simple-slider__item-image_size_small {display:none;} @media screen and (max-width: 768px) {   .b-banners-simple-slider__item-image_size_wide {display:none;}   .b-banners-simple-slider__item-image_size_small {display:inline-block;} }  .b-banners-simple-slider__next-slide {   position:absolute;   top:0;   left:0;   width:100%;   height:100%;   visibility:hidden; } .b-banners-simple-slider__next-slide_state_transible {   visibility:visible;   margin:0;   transition: margin 0.5s;   -webkit-transition: margin 0.5s; /* Safari */ }  .b-banners-simple-slider__navy-button {   position: absolute;   top: 0;   z-index: 1;   height: 100%;   cursor: pointer;   width: 40px;   color: rgba(0, 0, 0, 0);   cursor: pointer;   display: block;   opacity: 0.4;   transition: opacity 0.2s;   -moz-transition: opacity 0.2s; } .b-banners-simple-slider__navy-button:hover {   opacity:0.7; } .b-banners-simple-slider__navy-button::-moz-selection {background: transparent; color: #fff; text-shadow: none;} .b-banners-simple-slider__navy-button::selection {background: transparent; color: #fff; text-shadow: none;}  .b-banners-simple-slider__navy-button_action_prev {left: 0;} .b-banners-simple-slider__navy-button_action_next {right: 0;} .b-banners-simple-slider__navy-button-content {   display: block;   height: 40px;   opacity: 1;   width: 30px;   padding: 0 0 0 15px;   top: 50%;   margin-top: -20px;   position: relative; } .b-banners-simple-slider__navy-button_action_next .b-banners-simple-slider__navy-button-content {   background: white url(' + prot + '//adfox.megafon.ru/131217/adfox/322968/right.png) no-repeat scroll 50% 30%; } .b-banners-simple-slider__navy-button_action_prev .b-banners-simple-slider__navy-button-content {   background: white url(' + prot + '//adfox.megafon.ru/131217/adfox/322968/left.png) no-repeat scroll 50% 30%; }  .b-banners-simple-slider__switcher {   margin: 0 auto;   position: absolute;   bottom: 4%;   z-index: 99;   left: 50%;   margin-left: -50px; } .b-banners-simple-slider__switcher-button {   display: block;   float: left;   margin-right: 5px;   width: 14px;   height: 14px;   border-radius: 10px;   margin: 4px;   cursor: pointer;   background: rgba(255,255,255,0.1);   transition: background 0.5s;   -moz-transition: background 0.5s;   border: 1px solid #ddd;   box-shadow: 0 0 6px -2px #777; } .b-banners-simple-slider__switcher-button:hover {   transition: none;   border: 1px solid #aaa;   background: #fff; } .b-banners-simple-slider__switcher-button_state_active {   border: 1px solid #ddd;   background: #ddd; }  @media screen and (max-width: 300px) {   .b-banners-simple-slider__navy-button_action_prev {left: 2%;}   .b-banners-simple-slider__navy-button_action_next {right: 2%;} } @media screen and (max-width: 600px) {   .b-banners-simple-slider__switcher { bottom:10px; } }',
		slider = '';
	list.className = 'b-banners-simple-slider__list';
	createSlider();
	adfoxSliderStyle();
	getImage();
	checkJQ();

	function adfoxSliderStyle() {
		var cssTag = document.createElement('style');
		cssTag.type = 'text/css';
		if (!+"\v1") {
			cssTag.styleSheet.cssText = cssSliderText;

			document.body.appendChild(cssTag);
		}
		else {
			if (cssTag.innerText) cssTag.innerText = cssSliderText;
			else cssTag.textContent = cssSliderText;
			document.body.appendChild(cssTag);
		}
	}

	function getImage() {
		//var keyWordData = window.location.href.substr(window.location.href.indexOf('?')+1);
		if (count < limit && window.stopSlide == false) {
			var gImg = document.createElement('script'),
				addate = new Date(),
				dl = escape(document.location),
				afReferrer = escape(document.referrer),
				pr1 = Math.floor(Math.random() * 1000000);
			gImg.async = true;
			gImg.type = 'text/javascript';
			document.body.appendChild(gImg);

			gImg.onload = function () {
				crn();
			};
			if (!+"\v1")
				gImg.onreadystatechange = function () {
					if (gImg.readyState == 'loaded') {
						setTimeout(crn, 100);
					}
				};
			//old gImg.src = (prot + '//adfox.megafon.ru/218063/prepareCode?p1=bmcls&p2=euxx&pct=b&pfc=a&pfb=a&pr=' + pr + '&pt=b&pd=' + addate.getDate() + '&pw=' + addate.getDay() + '&pv=' + addate.getHours() + '&prr=' + afReferrer + '&puid1=spb.&random=' + Math.floor(Math.random() * 9999999) + '&dl=' + dl + '&pr1=' + pr1);
			//gImg.src = (prot + '//ads.adfox.ru/228840/prepareCode?p1=bqysi&p2=fami&pct=b&pfc=a&pfb=a&pr=' + pr + '&pt=b&pd=' + addate.getDate() + '&pw=' + addate.getDay() + '&pv=' + addate.getHours() + '&prr=' + afReferrer + '&pk=' + keyWordData + '&pke=1' +'&random=' + Math.floor(Math.random() * 9999999) + '&dl=' + dl + '&pr1=' + pr1);
			gImg.src = (prot + '//ads.adfox.ru/228840/prepareCode?p1=bqysi&p2=fami&pct=b&pfc=a&pfb=a&pr=' + pr + '&pt=b&pd=' + addate.getDate() + '&pw=' + addate.getDay() + '&pv=' + addate.getHours() + '&prr=' + afReferrer + '&' + window.location.href.substr(window.location.href.indexOf('?')+1) + '&pke=1' +'&random=' + Math.floor(Math.random() * 9999999) + '&dl=' + dl + '&pr1=' + pr1);
		}
		else {
			var f = new Date().getTime();
			var listItem = document.getElementsByClassName('b-banners-simple-slider__list')[0];
			if (!+"\v1") {
			}
			else {
				sortList(listItem);
			}
			//sortItem.sort(function(a,b) {return a.getAttribute('data-w')-b.getAttribute('data-w');});
			canPlay();
			var a = document.getElementsByClassName('b-banners-simple-slider__switcher-button')[0];
			a.click();
		}
		function crn() {
			createSlide(count);
			count++;
			canPlay();
			getImage();
		}
	}

	function checkJQ() {
		if (typeof window.$ == 'function') {
			window.$(window).trigger('adfox-loaded');
			window.$(window).trigger('resize');
			testJQ = true;
		}
		else {
			setTimeout(checkJQ, 30);
		}
	}

	function canPlay() {
		var item = document.getElementsByClassName('b-banners-simple-slider__item');
		if (item.length > 0 && testJQ == true) {
			playSlider();
		}
		else {
			setTimeout(canPlay, 30);
		}
	}

	function sortList(list) {
		var items = list.childNodes;
		var itemsArr = [];
		for (var i = 0; i < items.length; i++) {
			itemsArr.push(items[i]);
		}
		itemsArr.sort(function (a, b) {

			return a.getAttribute('data-w') == b.getAttribute('data-w')
				? 0
				: (a.getAttribute('data-w') > b.getAttribute('data-w') ? -1 : 1);
		});
		for (i = 0; i < itemsArr.length; ++i) {
			list.appendChild(itemsArr[i]);
		}

	}

	function createSlider() {
		slider += '<div class="b-banners-simple-slider"><div class="b-banners-simple-slider__container"><div class="b-banners-simple-slider__list"><span class="b-banners-simple-slider__next-slide"><img class="b-banners-simple-slider__item-image b-banners-simple-slider__item-image_size_wide" src="" alt=""><img class="b-banners-simple-slider__item-image b-banners-simple-slider__item-image_size_small" src="" alt=""></span></div>';
		slider += '<div class="clear"></div></div><div class="b-banners-simple-slider__navy-button b-banners-simple-slider__navy-button_action_next"><span class="b-banners-simple-slider__navy-button-content"></span></div><div class="b-banners-simple-slider__navy-button b-banners-simple-slider__navy-button_action_prev"><span class="b-banners-simple-slider__navy-button-content"></span></div><div class="b-banners-simple-slider__switcher"><span class="b-banners-simple-slider__switcher-button b-banners-simple-slider__switcher-button_state_active"></span><span class="b-banners-simple-slider__switcher-button"></span><span class="b-banners-simple-slider__switcher-button"></span></div></div>';
		sliderBlock.innerHTML = slider;
		window.document.documentElement.className = window.document.documentElement.className.replace('ua_adfox_no', 'ua_adfox_yes');
	}

	function createSlide(count) {
		list = document.getElementsByClassName('b-banners-simple-slider__list')[0];
		var i = count;
		var slide = window.slides[i];
		if (slide == undefined) {
			return;
		}
		if (count===0) {
			// после загрузки первого слайда - говорим что нас можно показываться
			window.rooxTargetingManager.postAggregator('notify','showSlider');
		}
		list.innerHTML += '<div class="b-banners-simple-slider__item" data-w="' + slide.weight + '">' +
			'<a href="' + window.encodeURIComponent(slide.reference) + '" target="_blank" ><img class="b-banners-simple-slider__item-image b-banners-simple-slider__item-image_size_wide" src="' + slide.url1 + '" onclick="window.rooxTargetingManager.postAggregator(\'log\', \'bannerClick\');" alt="' + (i + 1) + '" /><img class="b-banners-simple-slider__item-image b-banners-simple-slider__item-image_size_small" src="' + slide.url2 + '" onclick="window.rooxTargetingManager.postAggregator(\'log\', \'bannerClick\');" alt="' + (i + 1) + '"></a>' +
			'</div>';
	}

	function playSlider() {
		window.jQuery(function ($) {
			(function htmSlider() {
				var list = $('.b-banners-simple-slider__list'),
					nextButton = $('.b-banners-simple-slider__navy-button_action_next'),
					prevButton = $('.b-banners-simple-slider__navy-button_action_prev'),
					items = $('.b-banners-simple-slider__item'),
					width = function () {
						return list.outerWidth();
					},
					position = (function (result) {
						items.each(function (i, el) {
							if ($(el).hasClass('b-banners-simple-slider__item_state_selected')) {
								result = i;
							}
						});
						return result;
					}(0)),
					count = items.length,
					isAnimated = false,
					switcher = $('.b-banners-simple-slider__switcher'),
					switcherT = '<span class="b-banners-simple-slider__switcher-button"></span>',
					nextSlide = $('.b-banners-simple-slider__next-slide'),
					nextSlideWideImg = nextSlide.find('.b-banners-simple-slider__item-image_size_wide'),
					nextSlideSmallImg = nextSlide.find('.b-banners-simple-slider__item-image_size_small'),
					autosliderIteration = 0,
					switcherButtons = $();

				$(sliderBlock).data('isAnimated', isAnimated);

				if (!count) {
					return;
				}

				(function (i, button) {
					switcher.css('visibility', 'hidden');
					switcher.empty();
					for (i = 0; i < count; i++) {
						button = $(switcherT);
						button.data('id', i);
						$(items[i]).data('srcWide', $(items[i]).find('.b-banners-simple-slider__item-image_size_wide').attr('src'));
						$(items[i]).data('srcSmall', $(items[i]).find('.b-banners-simple-slider__item-image_size_small').attr('src'));
						switcher.append(button);
					}
					switcher.css('visibility', 'visible');
					switcherButtons = switcher.find('.b-banners-simple-slider__switcher-button');
					go(position);
					list.append(nextSlide);
				}());

				function show(i) {
					nextSlide.hide();
					items.removeClass('b-banners-simple-slider__item_state_selected');
					$(items[i]).addClass('b-banners-simple-slider__item_state_selected');
					$(switcherButtons[i]).addClass('b-banners-simple-slider__switcher-button_state_active');
					isAnimated = 0;
					$(sliderBlock).data('isAnimated', 0);
					position = i;
					if (window.slides) if (window.slides[i].event != '') {
						var im = document.createElement('img');
						im.src = window.slides[i].event;
						window.slides[i].event = '';
						//window.rooxTargetingManager.statistic.logOperation('bannerDisplay', window.slides[i] );
						window.rooxTargetingManager.postAggregator('log', 'bannerDisplay', window.slides[i]);
					}
				}

				function go(i) {
					if (isAnimated && $(sliderBlock).data('isAnimated')) {
						return;
					}
					var direction = (i > position) ? 1 : -1;
					i = (i + count) % count;
					if (i == position) {
						show(i);
						return;
					}
					var newWideImage = $(items[i]).data('srcWide');
					var newSmallImage = $(items[i]).data('srcSmall');
					isAnimated = 1;
					$(sliderBlock).data('isAnimated', 1);

					nextSlide.removeClass('b-banners-simple-slider__next-slide_state_transible').show().css('margin-left', direction * width());

					setTimeout(function () {
						switcherButtons.removeClass('b-banners-simple-slider__switcher-button_state_active');
						$(switcherButtons[i]).addClass('b-banners-simple-slider__switcher-button_state_active');
						nextSlideWideImg.attr('src', newWideImage);
						nextSlideSmallImg.attr('src', newSmallImage);
						nextSlide.addClass('b-banners-simple-slider__next-slide_state_transible').css('margin-left', 0);
						autosliderIteration = 0;
					}, 42);

					setTimeout(function () {
						show(i);
					}, 542);
				}

				nextButton.click(function () {
					go(position + 1);
				});
				prevButton.click(function () {
					go(position - 1);
				});
				switcherButtons.on('click', function (e) {
					go($(e.target).data('id'));
				});

				if (curInt) clearInterval(curInt);
				curInt = setInterval(function () {
					autosliderIteration++;
					if (autosliderIteration % 10 === 0) {
						go(position + 1);
					}
				}, 500);
			}());
		});
	}
})(parent, parent.document);
if (parent != window)    document.close();