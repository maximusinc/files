window.rooxTargetingManager = window.rooxTargetingManager || {};
window.rooxTargetingManager.postAggregator = (function () {
	'use strict';
	var parentWindow = window.parent,
		post = function (message) {
			if (parentWindow) {
				parentWindow.postMessage(message,'http://pad.mgf.hosted:8080');
			}
		},
		stringify = function (obj) {
			var result;
			try {
				result = JSON.stringify(obj);
			} catch(e) {
				result = '{"error":"stringify error"}';
			}
			return result;
		},
		makeMessage = function (action, data) {
			var toMessage = {
				action: action
			};
			if (action === 'show') {
				toMessage.data = data;
			} else if (action === 'click') {
				toMessage.data = data;
			}
			return toMessage;
		},
		log = function (action, data) {
			var messObj = {
				type: 'log',
				action: action,
				data: (data || {})
			};
			post(stringify(messObj));
		},
		notify = function (action) {
			var messObj = {
				type: 'notify',
				action: action
			};
			post(stringify(messObj));
		},
		decorator = function (type, action, data) {
			data = data || {};
			if (type === 'log') {
				log(action, data);
			} else if(type === 'notify') {
				notify(action);
			}
		};

	return decorator;
})();