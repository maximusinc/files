/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/**
 * @type {Object} The namespace declaration for this file.
 */
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.sharedcontext = com.rooxteam.sharedcontext || {};


/**
 * @type {Object} Global DataContext to contain requested data sets.
 */
(function() {

    function DataContext(isPersistent) {
        var listeners = [];

        var _storage;
        if (isPersistent) {
            _storage = window.localStorage;
        } else {
            _storage = window.sessionStorage;
        }
//  var dataSets = {};

        /**
         * Puts a data set into the global DataContext object. Fires listeners
         * if they are satisfied by the associated key being inserted.
         *
         * @param {string} key The key to associate with this object.
         * @param {ResponseItem|Object} obj The data object.
         * @param {boolean=} opt_fireListeners Default true.
         */
        var putDataSet = function(key, obj, opt_fireListeners) {
            if (typeof obj === 'undefined' || obj === null) {
                return;
            }
            _storage.setItem(key, JSON.stringify(obj));

            if (!(opt_fireListeners === false)) {
                fireCallbacks(key);
            }
        };

        var removeDataSet = function(key, opt_fireListeners) {
            _storage.removeItem(key);

            if (!(opt_fireListeners === false)) {
                fireCallbacks(key);
            }
        };

        /**
         * Registers a callback listener for a given set of keys.
         * @param {string|Array.<string>} keys Key or set of keys to listen on.
         * @param {function(Array.<string>)} callback Function to call when a
         * listener is fired.
         * @param {booelan} oneTimeListener Remove this listener after first callback?
         * @param {boolean} fireIfReady Instantly fire this if all data is available?
         */
        var registerListener = function(keys, callback, oneTimeListener, fireIfReady) {
            var oneTime = !!oneTimeListener;
            var listener = {keys: {}, callback: callback, oneTime: oneTime};

            if (typeof keys === 'string') {
                listener.keys[keys] = true;
                if (keys != '*') {
                    keys = [keys];
                }
            } else {
                for (var i = 0; i < keys.length; i++) {
                    listener.keys[keys[i]] = true;
                }
            }

            listeners.push(listener);

            // Check to see if this one should fire immediately.
            if (fireIfReady && keys !== '*' && isDataReady(listener.keys)) {
                window.setTimeout(function() {
                    maybeFireListener(listener, keys);
                }, 1);
            }
        };

        /**
         * Checks if the data for a map of keys is available.
         * @param {Object.<string, *>} keys An map of keys to check.
         * @return {boolean} Data for all the keys is present.
         */
        var isDataReady = function(keys) {
            if (keys['*']) {
                return true;
            }

//        for (var key in keys) {
//            if (typeof dataSets[key] === 'undefined') {
//                return false;
//            }
//        }
            return true;
        };

        /**
         * Fires a listener for a key, but only if the data is ready for other
         * keys this listener is bound to.
         * @param {Object} listener The listener object.
         * @param {string} key The key that this listener is being fired for.
         */
        var maybeFireListener = function(listener, key) {
            if (isDataReady(listener.keys)) {
                listener.callback(key);
                if (listener.oneTime) {
                    removeListener(listener);
                }
            }
        };

        /**
         * Removes a listener from the list.
         * @param {Object} listener The listener to remove.
         */
        var removeListener = function(listener) {
            for (var i = 0; i < listeners.length; ++i) {
                if (listeners[i] == listener) {
                    listeners.splice(i, 1);
                    return;
                }
            }
        };

        /**
         * Scans all active listeners and fires off any callbacks that inserting this
         * key or list of keys satisfies.
         * @param {string|Array.<string>} keys The key that was updated.
         * @private
         */
        var fireCallbacks = function(keys) {
            if (typeof(keys) == 'string') {
                keys = [keys];
            }
            for (var i = 0; i < listeners.length; ++i) {
                var listener = listeners[i];
                for (var j = 0; j < keys.length; j++) {
                    var key = keys[j];
                    if (listener.keys[key] || listener.keys['*']) {
                        maybeFireListener(listener, keys);
                        break;
                    }
                }
            }
        };


        return {

            /**
             * Returns a map of existing data.
             * @return {Object} A map of current data sets.
             * TODO: Add to the spec API?
             */
            getData: function() {
                var data = {};
                for (var keyIdx = 0; keyIdx < _storage.length; keyIdx++) {
                    data[keyIdx] = _storage.getItem(_storage.key(keyIdx));
                }
            },

            /**
             * Registers a callback listener for a given set of keys.
             * @param {string|Array.<string>} keys Key or set of keys to listen on.
             * @param {function(Array.<string>)} callback Function to call when a
             * listener is fired.
             */
            registerListener: function(keys, callback) {
                registerListener(keys, callback, false, true);
            },

            /**
             * Private version of registerListener which allows one-time listeners to
             * be registered. Not part of the spec. Exposed because needed by
             * opensocial-templates.
             * @param {string|Array.<string>} keys Key or set of keys to listen on.
             * @param {function(Array.<string>)} callback Function to call when a.
             */
            registerOneTimeListener_: function(keys, callback) {
                registerListener(keys, callback, true, true);
            },

            /**
             * Private version of registerListener which allows listeners to be
             * registered that do not fire initially, but only after a data change.
             * Exposed because needed by opensocial-templates.
             * @param {string|Array.<string>} keys Key or set of keys to listen on.
             * @param {function(Array.<string>)} callback Function to call when a.
             */
            registerDeferredListener_: function(keys, callback) {
                registerListener(keys, callback, false, false);
            },

            /**
             * Retrieve a data set for a given key.
             * @param {string} key Key for the requested data set.
             * @return {Object} The data set object.
             */
            getDataSet: function(key) {
                var result = _storage.getItem(key)
                if (typeof result === 'undefined' || result === null) {
                    return result;
                }
                return JSON.parse(result);
            },

            /**
             * Puts a data set into the global DataContext object. Fires listeners
             * if they are satisfied by the associated key being inserted.
             *
             * @param {string} key The key to associate with this object.
             * @param {ResponseItem|Object} obj The data object.
             */
            putDataSet: function(key, obj) {
                putDataSet(key, obj, true);
            },

            /**
             * Removes value from data set
             *
             * @param {string} key The key to associate with this object.
             */
            removeDataSet: function(key) {
                removeDataSet(key, true);
            },

            /**
             * Inserts multiple data sets from a JSON object.
             * @param {Object.<string, Object>} dataSets a JSON object containing Data
             * sets keyed by Data Set Key. All the DataSets are added, before firing
             * listeners.
             */
            putDataSets: function(dataSets) {
                var keys = [];
                for (var key in dataSets) {
                    keys.push(key);
                    putDataSet(key, dataSets[key], false);
                }
                fireCallbacks(keys);
            }
        };

    }

    com.rooxteam.sharedcontext.DataContext = DataContext(false);

    com.rooxteam.sharedcontext.PersistentDataContext = DataContext(true);

})();

/**
 * Accessor to the shared, global SharedContext.
 */
com.rooxteam.sharedcontext.getDataContext = function() {
    return com.rooxteam.sharedcontext.DataContext;
};

/**
 * Accessor to the persistent global storage
 */
com.rooxteam.sharedcontext.getPersistentDataContext = function() {
    return com.rooxteam.sharedcontext.PersistentDataContext;
};;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.deferred = com.rooxteam.deferred || {};
/* global dust, jQuery, WinJS */



/**
 * Feature to work with Promises
 * @class com.rooxteam.deferred
 * @singleton
 */

/**
 * Instance of jQuery Deferred Class. See [Deferred Object](http://api.jquery.com/category/deferred-object/).
 * @class com.rooxteam.deferred.Deferred
 */
com.rooxteam.deferred.Deferred = jQuery.Deferred;

/*
 * Allows join together jQuery and WinJS.Promise
 * @method
 * @param {com.rooxteam.deferred.Deferred/WinJS.Promise...} - variable number of Promises to join.
 * @returns {com.rooxteam.deferred.Deferred} new joined promise that fulfills when all templates done, or any fails
 */
com.rooxteam.deferred.when = function () {
    "use strict";
    var args = Array.prototype.slice.call(arguments);

    args = jQuery.map(args, function (arg) {
        if (typeof WinJS !== "undefined" && arg instanceof WinJS.Promise) {
            arg = jQuery.Deferred(function (dfd) {
                arg.then(
                    function complete() {
                        dfd.resolveWith(this, arguments);
                    }, function error() {
                        dfd.rejectWith(this, arguments);
                    }, function progress() {
                        dfd.notifyWith(this, arguments);
                    });
            }).promise();
        }
        return arg;
    });

    return jQuery.when.apply(this, args);
};

/*
 * Allows join together jquery and winjs.promise
 * @method
 * @param {com.rooxteam.deferred.Deferred[] | WinJS.Promise[]} - variable number of Promises to join as array.
 * @returns {com.rooxteam.deferred.Deferred} new joined promise that fulfills when all templates done, or any fails
 */
com.rooxteam.deferred.whenArray = function (deferreds) {
    "use strict";
    return com.rooxteam.deferred.when.apply(null, deferreds);
};

/*
 * Allows join together jquery and winjs.promise, resolve or reject only when all arguments resolved or rejected
 * @method
 * @param {com.rooxteam.deferred.Deferred/WinJS.Promise...} - variable number of Promises to join.
 * @returns {com.rooxteam.deferred.Deferred} new joined promise that fulfills when all templates done, or all fails
 */
com.rooxteam.deferred.whenAll = function (deferreds) {
    "use strict";
    var args = Array.prototype.slice.call(arguments);
    if (args && args.length) {
        var deferred = $.Deferred(),
            toResolve = args.length,
            someFailed = false,
            fail,
            always;
        always = function () {
            if (!--toResolve) {
                deferred[someFailed ? 'reject' : 'resolve']();
            }
        };
        fail = function () {
            someFailed = true;
        };
        args.forEach(function (d) {
            d.fail(fail).always(always);
        });
        return deferred;
    } else {
        return $.Deferred().resolve();
    }
};

/*
 * Allows join together jquery and winjs.promise, resolve or reject only when all arguments resolved or rejected
 * @method
 * @param {com.rooxteam.deferred.Deferred[] | WinJS.Promise[]} - variable number of Promises to join as array.
 * @returns {com.rooxteam.deferred.Deferred} new joined promise that fulfills when all templates done, or all fails
 */
com.rooxteam.deferred.whenAllArray = function (deferreds) {
    "use strict";
    return com.rooxteam.deferred.whenAll.apply(null, deferreds);
};

/*
 * Allows join together jquery and winjs.promise, resolve or reject when some of argument resolved or all rejected
 * @method
 * @param {com.rooxteam.deferred.Deferred/WinJS.Promise...} - variable number of Promises to join.
 * @returns {com.rooxteam.deferred.Deferred} new joined promise that fulfills when some template done, or all fails
 */
com.rooxteam.deferred.whenSome = function (deferreds) {
    "use strict";
    var args = Array.prototype.slice.call(arguments);
    if (args && args.length) {
        var deferred = $.Deferred(),
            toResolve = args.length,
            someDone = false,
            done,
            always;
        always = function () {
            if (!--toResolve || someDone) {
                deferred[someDone ? 'resolve' : 'reject']();
            }
        };
        done = function () {
            someDone = true;
        };
        args.forEach(function (d) {
            d.done(done).always(always);
        });
        return deferred;
    } else {
        return $.Deferred().resolve();
    }
};

/*
 * Allows join together jquery and winjs.promise, resolve or reject when some of argument resolved or all rejected
 * @method
 * @param {com.rooxteam.deferred.Deferred[] | WinJS.Promise[]} - variable number of Promises to join as array.
 * @returns {com.rooxteam.deferred.Deferred} new joined promise that fulfills when some template done, or all fails
 */
com.rooxteam.deferred.whenSomeArray = function (deferreds) {
    "use strict";
    return com.rooxteam.deferred.whenSome.apply(null, deferreds);
};


/*
 * Allows create new promise that fulfills after period of time or that cancel promise after period of time. See [WinJs.Promise.timeout](http://msdn.microsoft.com/en-us/library/windows/apps/br229729.aspx).
 * @method
 * @param {Number} delay quantity of milliseconds to wait.
 * @param {com.rooxteam.deferred.Deferred} [promise] Promise to cancel after timeout.
 * @returns {com.rooxteam.deferred.Deferred} new promise that fulfills after period of time, or new promise with timeout logic
 */
com.rooxteam.deferred.timeout = function(delay, promise) {
    "use strict";
    var args = Array.prototype.slice.call(arguments, 1);

    var timeout = jQuery.Deferred(function(deferred) {
        deferred.timeoutID = setTimeout(function() {
            deferred.resolveWith(deferred, args);
        }, delay);

        deferred.fail(function() {
            clearTimeout(deferred.timeoutID);
        });
    });
    //check if second parameter is jquery deferred
    if (promise.promise && promise.resolve) {
        var cancelPromise = function () { promise.rejectWith(promise, args.slice(1)); };
        var cancelTimeout = function () { timeout.rejectWith(timeout, args.slice(1)); };
        timeout.then(cancelPromise);
        promise.then(cancelTimeout, cancelTimeout);
        return promise;
    } else {
        return timeout;
    }
};


if (typeof dust !== "undefined" && dust.helpers) {

    /**
     * @class dust
     * @singleton
     */

    /**
     * @class dust.helpers
     * @singleton
     */

    /**
     * Dustjs helpers to work with not completed deferreds
     * @param {com.rooxteam.deferred.Deferred} value Promise for processing.
     * @param {String} body Body block will be evaluated when deferred done, there will be new return value and args Array in context.
     * @param {String} else Else block will be evaluated when deferred fails, there will be new return value and args Array in context.
     * @returns {String} Rendered html for body or else blocks
     *
     *     @example
     *     var customer_get = new com.rooxteam.deferred.Deferred();
     *
     *     {@deferred value="{customer_get}"}
     *        Ваш бонус:  ${return.bonus}
     *     {:else}
     *        Ошибка получения данных
     *     {/deferred}
     *
     *     customer_get.resolve({bonus: 100});
     */
    dust.helpers.deferred = function (chunk, context, bodies, params) {
        "use strict";
        var body = bodies.block,
            error = bodies['else'];
        if( params && params.value){
            var promise = params.value;
            return chunk.map(function(chunk) {
                promise.then(
                    function(){
                        chunk.render(body, context.push({"return": arguments[0], "args": arguments}));
                        chunk.end();
                    },
                    function(){
                        if(error) {
                            chunk.render(error, context.push({"return": arguments[0], "args": arguments}));
                        }
                        chunk.end();
                    }
                );
            });
        } else {
            return chunk;
        }
    };
}
;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};
com.rooxteam.statistic.utils = com.rooxteam.statistic.utils || {};

(function () {
    var utils = com.rooxteam.statistic.utils,
        parameters = null;

  /**
   * Parses URL parameters into an object.
   * @param {string} url - the url parameters to parse.
   * @return {Array.<string>} The parameters as an array.
   */
  function parseUrlParams(url) {
    // Get settings from url, 'hash' takes precedence over 'search' component
    // don't use document.location.hash due to browser differences.
    var query;
    var queryIdx = url.indexOf('?');
    var hashIdx = url.indexOf('#');
    if (hashIdx === -1) {
        query = url.substr(queryIdx + 1);
    } else {
        // essentially replaces "#" with "&"
        query = [url.substr(queryIdx + 1, hashIdx - queryIdx - 1), '&',
                 url.substr(hashIdx + 1)].join('');
    }
    return query.split('&');
  }


  utils.parseUrlParams = parseUrlParams;

  /**
   * Gets the URL parameters.
   *
   * @param {string=} opt_url Optional URL whose parameters to parse.
   *                         Defaults to window's current URL.
   * @return {Object} Parameters passed into the query string.
   * @private Implementation detail.
   */
  utils.getUrlParameters = function(opt_url) {
    var no_opt_url = typeof opt_url === 'undefined';
    if (parameters !== null && no_opt_url) {
        // "parameters" is a cache of current window params only.
        return parameters;
    }
    var parsed = {};
    var pairs = parseUrlParams(opt_url || document.location.href);
    var unesc = window.decodeURIComponent ? decodeURIComponent : unescape;
    for (var i = 0, j = pairs.length; i < j; ++i) {
        var pos = pairs[i].indexOf('=');
        if (pos === -1) {
            continue;
        }
        var argName = pairs[i].substring(0, pos);
        var value = pairs[i].substring(pos + 1);
        // difference to IG_Prefs, is that args doesn't replace spaces in
        // argname. Unclear on if it should do:
        // argname = argname.replace(/\+/g, " ");
        value = value.replace(/\+/g, ' ');
        try {
            parsed[argName] = unesc(value);
        } catch (e) {
            // Undecodable/invalid value; ignore.
        }
    }
    if (no_opt_url) {
        // Cache current-window params in parameters var.
        parameters = parsed;
    }
    return parsed;
  };

    /**
     * return window.console object or fake object
     * @return {object}
     */
    utils.getConsole = function (){
        if (window.console && window.console.log) {
            return window.console;
        } else {
            // fake console
            return {
                log: function (){}
            };
        }
    };

    /**
     * Generates UUID
     * @return {string}
     */

    utils.guid = function () {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                .toString(16)
                .substring(1);
        }

        return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
            s4() + '-' + s4() + s4() + s4();
    };

})();;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.config = com.rooxteam.config || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};

//default statistic configuration
com.rooxteam.config.statistic = {
    "ENABLED": true,
    "LIC_ENABLED": false,
    "LIC_SERVER_ADDRESS": 'http://rcmlic.roox.ru/YA/PushReport/',
    "LIC_OBFUSCATED_DATA": ["userid", "msisdn", "^pn$", "authentication_token"], //Regexp as string
    "TRANSPORT": "GET",
    "SERVER_ADDRESS" : 'http://rcmlic.roox.ru/YA/PushReport/',
    "SERVICE_TYPE_PARAMETER" : 'YA_REPORT_SERVICE',
    "CHECKSUM_PARAMETER" : 'YA_REPORT_CHECKSUM',
    "SENDING_TIME_PARAMETER" : 'YA_REPORT_SENDING_TIME',
    "FILTERING_ERROR_PARAMETER": 'filtering_error',
    "COUNTER_SERVICE_TYPE": 'counter',
    "ACCUMULATE_TIME" : 60000,
    'TIMER_UPDATE_INTERVAL': 5000,
    "ACCUMULATE_OPERATION_LIMIT" : 20,        //after this accumulate operation limit - try send to server report
    "OVER_ACCUMULATE_OPERATION_LIMIT" : 100,     //max over accumulation limit if can't send report
    "COUNT_OF_IMMEDIATE_SENDING" : 3,
    "MAX_URL_LENGTH" : 2000,
    "TRACEKIT_ENABLED": false,
    "IO_EVENTS_ENABLED": true,
    "VIEW_EVENTS_ENABLED": true,
    "DOM_EVENTS_ENABLED": true,
    "DOM_EVENTS": {
        "click": {
            "verbose": 4,
            "selector": "a, button"
        }
    },
    META: {
        "CONTAINER": {
            "LOADED": null
        },
        "WIDGET": {
            "LOADED": null
        }
    }
};


(function (gadgets, console) {

    function traverse(o, func) {
        for (var i in o) {
            if (o.hasOwnProperty(i)) {
                if (typeof o[i] == "object") {
                    traverse(o[i], func);
                } else {
                    func.apply(o, [i, o[i]]);
                }
            }
        }
    }

    // workaround for incorrect types
    function convertTypes(obj) {
        traverse(obj, function (key, value) {
            if (/^[\s]*true[\s]*$/i.test(value)) {
                this[key] = true;
            } else if (/^[\s]*false[\s]*$/i.test(value)) {
                this[key] = false;
            } else if (/^[\s]*[\d]+[\s]*$/.test(value)) {
                this[key] = parseInt(value, 10);
            }
        });
        return obj;
    }

    com.rooxteam.statistic.updateConfiguration = function(localConfig, overrideConfig, widgetName, pageName){
    if(widgetName){
        if(
            typeof overrideConfig.DOM_EVENTS_WIDGETS != "undefined" &&
            typeof overrideConfig.DOM_EVENTS_WIDGETS[widgetName] != "undefined"
        ){
            $.extend(localConfig, overrideConfig, {
                "DOM_EVENTS": overrideConfig.DOM_EVENTS_WIDGETS[widgetName]
            });
        } else {
            $.extend(localConfig, overrideConfig);
        }
    } else if(pageName){
        if(
            typeof overrideConfig.DOM_EVENTS_PAGES != "undefined" &&
            typeof overrideConfig.DOM_EVENTS_PAGES[pageName] != "undefined"
        ){
            $.extend(localConfig, overrideConfig, {
                "DOM_EVENTS": overrideConfig.DOM_EVENTS_PAGES[pageName]
            });
        } else {
            $.extend(localConfig, overrideConfig);
        }
    } else {
        $.extend(localConfig, overrideConfig);
    }
    //Hack to disable stat in CM screenshots
    var dataContext = com.rooxteam.sharedcontext.getDataContext();
    if(dataContext.getDataSet('com.roox.cm.Common.App.Properties.unit.IsScreenshotting') === true) {
        localConfig['ENABLED'] = false;
    }
};

com.rooxteam.statistic.initConfiguration = function(widgetName, pageName){
    if(pageName && com.rooxteam.config.statistic.ENABLED === true && com.rooxteam.config.statistic.META.CONTAINER.LOADED === null){
        $.ajax({
            url: 'container-ver.json',
            dataType: 'json'
            //,async: false
        }).done(function(data) {
                com.rooxteam.config.statistic.META.CONTAINER.LOADED = true;
                $.extend(com.rooxteam.config.statistic.META.CONTAINER, data);
            }).fail(function() {
                com.rooxteam.config.statistic.META.CONTAINER.LOADED = false;
            })
    }
    //update configuration from gadgets.config
    if (gadgets && gadgets.config) {
        com.rooxteam.config.statistic.ENABLED=false;
        var updateConfiguration = function() {
            com.rooxteam.statistic.updateConfiguration(com.rooxteam.config.statistic, convertTypes(gadgets.config.get('com.rooxteam.statistic')), widgetName, pageName)
            if(com.rooxteam.config.statistic.ENABLED === true){
                console.log("Stats enabled");
            } else {
                console.log("Stats disabled");
            }
            com.rooxteam.statistic.client.initTransport(com.rooxteam.config.statistic.TRANSPORT);
        };
        gadgets.config.register('com.rooxteam.statistic', {}, updateConfiguration, updateConfiguration);
        if (gadgets.config.get()) {
            com.rooxteam.statistic.updateConfiguration(com.rooxteam.config.statistic, convertTypes(gadgets.config.get('com.rooxteam.statistic')), widgetName, pageName)
        }
    }

};

})(window.gadgets, com.rooxteam.statistic.utils.getConsole());;
/*global com */
com.rooxteam.config.statistic.LIC_ENABLED = true;;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};

(function () {
    'use strict';
    var CURRENT_VERSION = '2.1';
    var VERSION_PARAM   = 'version';
    var STORAGE_ID = 'com.rooxteam.statistic';

    function StatisticDao(storage_statistic, init_context) {

//        this.storage = com.rooxteam.sharedcontext.getPersistentDataContext();
        var localStorageObj = {};
        this.storage = {
            getDataSet: function (key) {
                return localStorageObj[key] || null;
            },
            putDataSet: function (key, name) {
                localStorageObj[key] = name;
            }
        };
        this.storageId = STORAGE_ID;

        this.storage_statistic = storage_statistic ? storage_statistic : 'statistic';
        this.storage_statistic_context = this.storage_statistic    + '_context';

        this._init(init_context);
    }

    StatisticDao.prototype = {
        _init: function (init_context) {
            var data = this.storage.getDataSet(this.storageId);
            if (!data) {
                data = {};
                data[VERSION_PARAM] = CURRENT_VERSION;
            } else if (!data[VERSION_PARAM] || (data[VERSION_PARAM] && data[VERSION_PARAM] !== CURRENT_VERSION)) {
                data = {};
                data[VERSION_PARAM] = CURRENT_VERSION;
            }
            if (!data[this.storage_statistic]) {
                data[this.storage_statistic] = [];
            }
            if (!data[this.storage_statistic_context]) {
                data[this.storage_statistic_context] = {};
            }
            this.storage.putDataSet(this.storageId, data);
            if (init_context) {
                this._initContext(init_context);
            }
        },

        saveUpdateStatistic: function (report) {
            this._saveUpdateStorageItem(this.storage_statistic, report);
        },

        getStatistic: function () {
            return this._getStorageItem(this.storage_statistic) || [];
        },

        saveUpdateContextValue: function (key, value) {
            var context = this._getStorageItem(this.storage_statistic_context);
            if (!context) {
                context = {};
            }
            context[key] = value;
            this._saveUpdateStorageItem(this.storage_statistic_context, context);
        },

        getContextValue: function (key) {
            var context = this._getStorageItem(this.storage_statistic_context);
            if (context) {
                return context[key];
            } else {
                return null;
            }
        },

        getContext: function () {
            return this._getStorageItem(this.storage_statistic_context);
        },

        _initContext: function (init_context) {
            var context = this._getStorageItem(this.storage_statistic_context);
            if (!context) {
                context = {};
            }
            for (var key in init_context) {
                if (!context[key]) {
                    context[key] = init_context[key];
                }
            }
            this._saveUpdateStorageItem(this.storage_statistic_context, context);
        },

        _saveUpdateStorageItem: function (name, item) {
            var data = this.storage.getDataSet(this.storageId);
            if (data) {
                data[name] = item;
                this.storage.putDataSet(this.storageId, data);
            }
        },

        _getStorageItem: function (name) {
            var data = this.storage.getDataSet(this.storageId);
            if (data) {
                return data[name];
            } else {
                return null;
            }
        }

    };

    com.rooxteam.statistic.StatisticDao = StatisticDao;

})();
;
/*
CryptoJS v3.1.2
code.google.com/p/crypto-js
(c) 2009-2013 by Jeff Mott. All rights reserved.
code.google.com/p/crypto-js/wiki/License
*/
var CryptoJS=CryptoJS||function(e,m){var p={},j=p.lib={},l=function(){},f=j.Base={extend:function(a){l.prototype=this;var c=new l;a&&c.mixIn(a);c.hasOwnProperty("init")||(c.init=function(){c.$super.init.apply(this,arguments)});c.init.prototype=c;c.$super=this;return c},create:function(){var a=this.extend();a.init.apply(a,arguments);return a},init:function(){},mixIn:function(a){for(var c in a)a.hasOwnProperty(c)&&(this[c]=a[c]);a.hasOwnProperty("toString")&&(this.toString=a.toString)},clone:function(){return this.init.prototype.extend(this)}},
n=j.WordArray=f.extend({init:function(a,c){a=this.words=a||[];this.sigBytes=c!=m?c:4*a.length},toString:function(a){return(a||h).stringify(this)},concat:function(a){var c=this.words,q=a.words,d=this.sigBytes;a=a.sigBytes;this.clamp();if(d%4)for(var b=0;b<a;b++)c[d+b>>>2]|=(q[b>>>2]>>>24-8*(b%4)&255)<<24-8*((d+b)%4);else if(65535<q.length)for(b=0;b<a;b+=4)c[d+b>>>2]=q[b>>>2];else c.push.apply(c,q);this.sigBytes+=a;return this},clamp:function(){var a=this.words,c=this.sigBytes;a[c>>>2]&=4294967295<<
32-8*(c%4);a.length=e.ceil(c/4)},clone:function(){var a=f.clone.call(this);a.words=this.words.slice(0);return a},random:function(a){for(var c=[],b=0;b<a;b+=4)c.push(4294967296*e.random()|0);return new n.init(c,a)}}),b=p.enc={},h=b.Hex={stringify:function(a){var c=a.words;a=a.sigBytes;for(var b=[],d=0;d<a;d++){var f=c[d>>>2]>>>24-8*(d%4)&255;b.push((f>>>4).toString(16));b.push((f&15).toString(16))}return b.join("")},parse:function(a){for(var c=a.length,b=[],d=0;d<c;d+=2)b[d>>>3]|=parseInt(a.substr(d,
2),16)<<24-4*(d%8);return new n.init(b,c/2)}},g=b.Latin1={stringify:function(a){var c=a.words;a=a.sigBytes;for(var b=[],d=0;d<a;d++)b.push(String.fromCharCode(c[d>>>2]>>>24-8*(d%4)&255));return b.join("")},parse:function(a){for(var c=a.length,b=[],d=0;d<c;d++)b[d>>>2]|=(a.charCodeAt(d)&255)<<24-8*(d%4);return new n.init(b,c)}},r=b.Utf8={stringify:function(a){try{return decodeURIComponent(escape(g.stringify(a)))}catch(c){throw Error("Malformed UTF-8 data");}},parse:function(a){return g.parse(unescape(encodeURIComponent(a)))}},
k=j.BufferedBlockAlgorithm=f.extend({reset:function(){this._data=new n.init;this._nDataBytes=0},_append:function(a){"string"==typeof a&&(a=r.parse(a));this._data.concat(a);this._nDataBytes+=a.sigBytes},_process:function(a){var c=this._data,b=c.words,d=c.sigBytes,f=this.blockSize,h=d/(4*f),h=a?e.ceil(h):e.max((h|0)-this._minBufferSize,0);a=h*f;d=e.min(4*a,d);if(a){for(var g=0;g<a;g+=f)this._doProcessBlock(b,g);g=b.splice(0,a);c.sigBytes-=d}return new n.init(g,d)},clone:function(){var a=f.clone.call(this);
a._data=this._data.clone();return a},_minBufferSize:0});j.Hasher=k.extend({cfg:f.extend(),init:function(a){this.cfg=this.cfg.extend(a);this.reset()},reset:function(){k.reset.call(this);this._doReset()},update:function(a){this._append(a);this._process();return this},finalize:function(a){a&&this._append(a);return this._doFinalize()},blockSize:16,_createHelper:function(a){return function(c,b){return(new a.init(b)).finalize(c)}},_createHmacHelper:function(a){return function(b,f){return(new s.HMAC.init(a,
f)).finalize(b)}}});var s=p.algo={};return p}(Math);
(function(){var e=CryptoJS,m=e.lib,p=m.WordArray,j=m.Hasher,l=[],m=e.algo.SHA1=j.extend({_doReset:function(){this._hash=new p.init([1732584193,4023233417,2562383102,271733878,3285377520])},_doProcessBlock:function(f,n){for(var b=this._hash.words,h=b[0],g=b[1],e=b[2],k=b[3],j=b[4],a=0;80>a;a++){if(16>a)l[a]=f[n+a]|0;else{var c=l[a-3]^l[a-8]^l[a-14]^l[a-16];l[a]=c<<1|c>>>31}c=(h<<5|h>>>27)+j+l[a];c=20>a?c+((g&e|~g&k)+1518500249):40>a?c+((g^e^k)+1859775393):60>a?c+((g&e|g&k|e&k)-1894007588):c+((g^e^
k)-899497514);j=k;k=e;e=g<<30|g>>>2;g=h;h=c}b[0]=b[0]+h|0;b[1]=b[1]+g|0;b[2]=b[2]+e|0;b[3]=b[3]+k|0;b[4]=b[4]+j|0},_doFinalize:function(){var f=this._data,e=f.words,b=8*this._nDataBytes,h=8*f.sigBytes;e[h>>>5]|=128<<24-h%32;e[(h+64>>>9<<4)+14]=Math.floor(b/4294967296);e[(h+64>>>9<<4)+15]=b;f.sigBytes=4*e.length;this._process();return this._hash},clone:function(){var e=j.clone.call(this);e._hash=this._hash.clone();return e}});e.SHA1=j._createHelper(m);e.HmacSHA1=j._createHmacHelper(m)})();
;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};

(function (CryptoJS, $, utils) {
    'use strict';
    var filters = com.rooxteam.config.statistic.LIC_OBFUSCATED_DATA;

    function shouldBeObfuscated(key) {
        var re = new RegExp(filters.join('|'), 'i');
        return (key.match(re) !== null);
    }

    function obfuscateUrlParams(url) {
        var queryIdx = url.indexOf('?'),
            urlParams = utils.parseUrlParams(url),
            makeRegExp = function () {
                var regExpArr = [];
                for (var i in filters) {
                    regExpArr.push(filters[i]);
                }
                return new RegExp(regExpArr.join('|'), 'i');
            },
            replaceObfuscatedParam = function (paramStr) {
                var aux = paramStr.split('=');
                if (aux.length !== 2) {
                    return paramStr;
                }
                aux[1] = 'NA';
                return aux.join('=');
            },
            testParam = function (re, param) {
                var name = param.split('=')[0];
                return re.test(name);
            },
            regExpObj = makeRegExp(),
            arrNewUrlParams = [];
        for (var index in urlParams) {
            if (testParam(regExpObj, urlParams[index])) {
                arrNewUrlParams[index] = replaceObfuscatedParam(urlParams[index]);
            } else {
                arrNewUrlParams[index] = urlParams[index];
            }
        }
        return url.substr(0, queryIdx + 1) + arrNewUrlParams.join('&');
    }
    // make function reference for testing unit
    com.rooxteam.statistic.obfuscateUrlParams = obfuscateUrlParams;
    //todo implement real deep filtering of json
    com.rooxteam.statistic.deepFilter = function (content, isRcmLicUrl) {
        var data = {};
        try {
            var contentObj = JSON.parse(content);
            data = contentObj.data;
            $.each(data, function (idx, val) {
                $.each(val.data, function (cidx, cval) {
                    if (isRcmLicUrl) {
                        if (cidx === 'url') {
                            data[idx]['data'][cidx] = obfuscateUrlParams(cval);
                        }
                    }
                    if (shouldBeObfuscated(cidx)) {
                        if (isRcmLicUrl) {
                            if (cval && cval.toString && cval.toString().length) {
                                data[idx]['data'][cidx] = CryptoJS.SHA1(cval).toString(CryptoJS.enc.Base64);
                            } else {
                                data[idx]['data'][cidx] = cval;
                            }
                        } else {
                            data[idx]['data'][cidx] = CryptoJS.SHA1(cval).toString(CryptoJS.enc.Base64);
                        }
                    }
                });
            });
            return JSON.stringify({data: data});
        } catch (e) {
            return {
                data: content,
                error: 'filtering'
            };
        }
    };

})(window.CryptoJS, window.jQuery, com.rooxteam.statistic.utils);;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};

(function ($) {
    'use strict';
    var config = com.rooxteam.config.statistic;
    var transports;

    function JoinStatisticTransport() {
        transports = arguments;
    }

    JoinStatisticTransport.prototype = {
        sendReport: function (content, parameters, successCallback, errorCallback) {
            var promises = [];
            $.each(transports, function (indexInArray, transport) {
                promises.push(transport.sendReport(content, parameters));
            });
            //call successCallback if any of callbacks success
            return com.rooxteam.deferred.whenSomeArray(promises).then(successCallback, errorCallback);
        },

        validate: function (content, parameters) {
            var isValid = true;
            $.each(transports, function (indexInArray, transport) {
                isValid = isValid && transport.validate(content, parameters);
            });
            return isValid;
        }
    };

    com.rooxteam.statistic.JoinStatisticTransport = JoinStatisticTransport;

})(window.jQuery);;
/*global Image,document */
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};

(function ($) {
    'use strict';
    var config = com.rooxteam.config.statistic;
    var STATISTIC_IMG_ID = 'roox-statistic-img';
    var MAX_URL_LENGTH = config.MAX_URL_LENGTH;

    function GetStatisticTransport(serverAddressKeyOverride, useFiltersOverride) {
        this.serverAddressKey = serverAddressKeyOverride;
        this.useFilters = useFiltersOverride || false;
    }

    GetStatisticTransport.prototype = {
        isRcmLicUrl: function () {
            var url = (config[this.serverAddressKey || 'SERVER_ADDRESS']);
            return url === config.LIC_SERVER_ADDRESS;
        },

        sendReport: function (content, parameters, successCallback, errorCallback) {
            if (this.useFilters) {
                content = com.rooxteam.statistic.deepFilter(content, this.isRcmLicUrl());
                if (typeof content !== 'string' && content && typeof content.data === 'string') {
                    if (content.error && content.error === 'filtering') {
                        parameters[config.FILTERING_ERROR_PARAMETER] = '1';
                    }
                    content = content.data;
                }
                parameters[config.CHECKSUM_PARAMETER] = com.rooxteam.statistic.calculateChecksum(content);
            }
            return this._createUpdateImage(this._composeUrl(content, parameters), successCallback, errorCallback);
        },

        validate: function (content, parameters) {
            var url = this._composeUrl(content, parameters);
            return url.length <= MAX_URL_LENGTH;
        },

        _composeUrl: function (content, parameters) {
            var url = (config[this.serverAddressKey || 'SERVER_ADDRESS']) + '?content=' + encodeURIComponent(content);
            for (var key in parameters) {
                url += '&' + key + '=' + parameters[key];
            }
            return url;
        },

        _createUpdateImage: function (imgSrc, onLoad, onError) {
            return $.Deferred($.proxy(function (d) {
                var img = document.getElementById(STATISTIC_IMG_ID + '-' + this.serverAddressKey);
                if (!img) {
                    img = new Image(1, 1);
                    img.id = STATISTIC_IMG_ID + '-' + this.serverAddressKey;
                    img.style.position = 'absolute';
                    img.style.left = '-99999';
                    $('body').append(img);
                }
                img.onload = function () {
                    if (typeof onLoad === 'function') {
                        onLoad();
                    }
                    d.resolveWith(img, ['success']);
                };
                img.onerror = function () {
                    if (typeof onError === 'function') {
                        onError();
                    }
                    d.rejectWith(img, ['error']);
                };
                img.src = imgSrc;
            }, this)).promise();
        }
    };

    com.rooxteam.statistic.GetStatisticTransport = GetStatisticTransport;

})(window.jQuery);;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};

(function () {
    'use strict';
    com.rooxteam.statistic.calculateChecksum = function (buffer) {
        var result = 0;
        var i;
        var bytes = [];

        for (i = 0; i < buffer.length; i++) {
            var code = buffer.charCodeAt(i);
            if (code < 128) {
                bytes.push(code);
            }
            else if (code < 2048) {
                bytes.push(192 + (code >> 6));
                bytes.push(128 + (code & 63));
            }
            else if (code < 65536) {
                bytes.push(224 + (code >> 12));
                bytes.push(128 + ((code >> 6) & 63));
                bytes.push(128 + (code & 63));
            }
            else if (code < 2097152) {
                bytes.push(240 + (code >> 18));
                bytes.push(128 + ((code >> 12) & 63));
                bytes.push(128 + ((code >> 6) & 63));
                bytes.push(128 + (code & 63));
            }
        }

        for (i = 0; i < bytes.length; i++) {
            var tmp, to_shift;
            if (i % 3 === 0 || i % 5 === 2) {
                to_shift = bytes[i] > 127 ? 0xffffff00 | bytes[i] : bytes[i];
                result ^= (to_shift << (i % 24));
            }
            else {
                result ^= ((0xff & ~bytes[i]) << (i % 24));
            }
        }
        return result;
    };
})();

com.rooxteam.statistic.client = (function (self, gadgets) {
    'use strict';
    var statisticDao = new com.rooxteam.statistic.StatisticDao('statistic', {'lastSend': (new Date()).getTime()});
    var statisticBufferDao = new com.rooxteam.statistic.StatisticDao('statisticBuffer', {'lastSend': 0});

    var statisticTransport;


    var config = com.rooxteam.config.statistic;

    if (!Date.prototype.toISOString) {
        (function () {
            function pad(number) {
                var r = String(number);
                if (r.length === 1) {
                    r = '0' + r;
                }
                return r;
            }

            Date.prototype.toISOString = function () {
                return this.getUTCFullYear() +
                    '-' + pad(this.getUTCMonth() + 1) +
                    '-' + pad(this.getUTCDate()) +
                    'T' + pad(this.getUTCHours()) +
                    ':' + pad(this.getUTCMinutes()) +
                    ':' + pad(this.getUTCSeconds()) +
                    '.' + String((this.getUTCMilliseconds() / 1000).toFixed(3)).slice(2, 5) +
                    'Z';
            };
        }());
    }

    self.initTransport = function (name) {
        var licStatisticTransport;

        //Prepare main stat transport
        if (name === 'GET') {
            statisticTransport = new com.rooxteam.statistic.GetStatisticTransport('SERVER_ADDRESS');
        } else if (name === 'POST') {
            statisticTransport = new com.rooxteam.statistic.PostStatisticTransport('SERVER_ADDRESS');
        }
        //Prepare lic stat transport
        if (config.LIC_ENABLED === true) {
            if (name === 'GET') {
                licStatisticTransport = new com.rooxteam.statistic.GetStatisticTransport('LIC_SERVER_ADDRESS', true);
            } else if (name === 'POST') {
                licStatisticTransport = new com.rooxteam.statistic.PostStatisticTransport('LIC_SERVER_ADDRESS', true);
            }
            statisticTransport = new com.rooxteam.statistic.JoinStatisticTransport(statisticTransport, licStatisticTransport);
        }
    };

    self.initTransport(config.TRANSPORT);

    self._init = function () {
        if (self.beforeLoadLogData && self.beforeLoadLogData.length) {
            for (var i = 0; i < self.beforeLoadLogData.length; i++) {
                self.logOperation.apply(self, self.beforeLoadLogData[i]);
            }
        }
        setInterval(function () {
            self.trySendReport();
        }, config.TIMER_UPDATE_INTERVAL);
    };

    self.trySendReport = function () {
        if (!config.ENABLED) {
            return;
        }

        var statisticBuffer = statisticBufferDao.getStatistic();
        var bufferLastSend = statisticBufferDao.getContextValue('lastSend');

        if (statisticBuffer && statisticBuffer.length > 0) {
            if (self.isExpired(config.ACCUMULATE_TIME, bufferLastSend)) {

                var remainedBuffer = [];
                var report = self.getCreateReport(statisticBuffer);
                var parameters = self.calculateParams(config.COUNTER_SERVICE_TYPE, report);
                var isValid = statisticTransport.validate(report, parameters);

                while (!isValid && statisticBuffer.length > 0) {
                    while (!isValid && statisticBuffer.length > 0) {
                        var elem = statisticBuffer.pop();
                        if (statisticBuffer.length > 0) {
                            remainedBuffer.push(elem);
                            report = self.getCreateReport(statisticBuffer);
                            parameters = self.calculateParams(config.COUNTER_SERVICE_TYPE, report);
                            isValid = statisticTransport.validate(report, parameters);
                        } else {
                            if (window.console) {
                                window.console.log('Remove report operation (too big): ' + JSON.stringify(elem));
                            }
                        }
                    }

                    remainedBuffer.reverse();

                    if (!isValid) {
                        statisticBuffer = remainedBuffer;
                        remainedBuffer = [];
                    }
                }

                if (isValid) {
                    statisticTransport.sendReport(report, parameters,
                        function () {
                            statisticBufferDao.saveUpdateStatistic(remainedBuffer);

                            //quick fix; smart logic for calculating threshold, timeout before sending of remainedbuffer
                            var toSend = (remainedBuffer.length + statisticDao.getStatistic().length),
                                lastSendValue;
                            if (toSend > config.COUNT_OF_IMMEDIATE_SENDING) {

                                var now = (new Date()).getTime();
                                var waitBeforeSend = config.ACCUMULATE_TIME * (toSend / (config.ACCUMULATE_OPERATION_LIMIT + config.OVER_ACCUMULATE_OPERATION_LIMIT));
                                //lastSend should not be in future
                                lastSendValue = Math.min(now - 1, now - config.ACCUMULATE_TIME + waitBeforeSend);
                            } else {
                                lastSendValue = 0;
                            }
                            //end, smart logic
                            statisticBufferDao.saveUpdateContextValue('lastSend', lastSendValue);

                            if (remainedBuffer.length > 0) {
                                self.trySendReport();
                            }

                        },
                        function () {
                            if (window.console) {
                                window.console.log('Can\'t send statistic report.');
                            }
                        });
                    statisticBufferDao.saveUpdateContextValue('lastSend', (new Date()).getTime());
                } else {
                    statisticBufferDao.saveUpdateStatistic(remainedBuffer);
                    if (remainedBuffer.length > 0) {
                        setTimeout(self.trySendReport, 0);
                    }
                }

            }
            return;
        }

        var statistic = statisticDao.getStatistic();
        var lastSend = statisticDao.getContextValue('lastSend');

        if (statistic && statistic.length > 0 && (self.isExpired(config.ACCUMULATE_TIME, lastSend) || statistic.length >= config.ACCUMULATE_OPERATION_LIMIT)) {
            //FIXME investigate errors in multithreaded env.
            statisticBufferDao.saveUpdateStatistic(statistic);
            statisticDao.saveUpdateStatistic([]);
            statisticDao.saveUpdateContextValue('lastSend', (new Date()).getTime());
            self.trySendReport();
        }
    };

    self.getCreateReport = function (statistic) {
        var report = {};
        report.data = statistic;
        return JSON.stringify(report) + '\n';
    };

    self.calculateParams = function (type, report) {
        var parameters = {};
        parameters[config.SERVICE_TYPE_PARAMETER] = type;
        parameters[config.CHECKSUM_PARAMETER] = com.rooxteam.statistic.calculateChecksum(report);
        parameters[config.SENDING_TIME_PARAMETER] = new Date().toISOString();
        return parameters;
    };

    self.logOperation = function (name, data, quantity, timeStart, timeEnd) {
        if (!config.ENABLED) {
            return;
        }
        if (name) {
            var operationCount = statisticDao.getStatistic().length;
            if (operationCount < config.ACCUMULATE_OPERATION_LIMIT + config.OVER_ACCUMULATE_OPERATION_LIMIT) {
                var operation = {};
                operation.name = name;
                operation.quantity = quantity ? quantity : 1;
                operation.timeStart = timeStart ? timeStart : (new Date()).getTime();
                operation.timeEnd = timeEnd ? timeEnd : operation.timeStart;
                operation.data = data ? data : '';
                var report = statisticDao.getStatistic();
                report.push(operation);
                statisticDao.saveUpdateStatistic(report);
            }
            if (operationCount >= config.ACCUMULATE_OPERATION_LIMIT) {
                self.trySendReport();
            }
        }
    };

    self.logOperationAuth = function (name, data, quantity, timeStart, timeEnd) {
        if (gadgets && gadgets.util && gadgets.util.hasFeature('com.rooxteam.auth')) {
            var userId = com.rooxteam.auth.getPrincipal();
            if (data) {
                data.userId = userId;
            } else {
                data = {};
                data.userId = userId;
            }
        }
        self.logOperation(name, data, quantity, timeStart, timeEnd);
    };

    self.isExpired = function (interval, time) {
        var now_time = (new Date()).getTime();
        return now_time < time || now_time - time > interval;
    };



    self._init();
    return self;

})(com.rooxteam.statistic.client || {}, window.gadgets);

;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};

(function (gadgets, $, WinJS, document, TraceKit) {
    'use strict';
    if (TraceKit && TraceKit.report) {
        TraceKit.report.subscribe(function myTraceKitLogger(errorReport) {
            var config = com.rooxteam.config.statistic;
            if (config.TRACEKIT_ENABLED !== true) {
                return false;
            }
            var data = com.rooxteam.statistic.getContext(errorReport);
            try {
                com.rooxteam.statistic.client.logOperationAuth('event.exception', data, 1, null, null);
            } catch (e) {
                //stay silent if couldn't send
            }
        });
    }

    com.rooxteam.statistic.setupCapturingEvent = function setupCapturingEvent(data) {
        var config = com.rooxteam.config.statistic;
        if (!config.DOM_EVENTS_ENABLED || !config.DOM_EVENTS) {
            return true;
        }
        var configData = data;

        //Change current page in winapp
        if (typeof WinJS !== 'undefined' && typeof WinJS.Navigation !== 'undefined') {
            WinJS.Navigation.addEventListener('navigated', function (event) {
                configData['p'] = com.rooxteam.statistic.getPageName(event.detail.location);
            });
        }

        if (document.addEventListener) {
            $.each(config.DOM_EVENTS, function (eventName, eventSettings) {
                if (eventName === 'mouseleave' || eventName === 'mouseenter') {
                    $(document).on(eventName, eventSettings.selector, configData, function (event) {
                        if (!config.DOM_EVENTS_ENABLED) {
                            return true;
                        }
                        event.data = $.extend(event.data, configData);
                        com.rooxteam.statistic.processEvent(event);
                        return true;
                    });
                } else {
                    document.addEventListener(eventName, function (event) {
                        if (!config.DOM_EVENTS_ENABLED) {
                            return true;
                        }
                        if (eventSettings.selector && !$(event.target).is(eventSettings.selector)) {
                            return true;
                        }
                        var jevent = $.event.fix(event);
                        jevent.data = configData;
                        com.rooxteam.statistic.processEvent(jevent);
                    }, true);
                }
            });
        } else {
            //Fallback to jquery event if ie<9
            $.each(config.DOM_EVENTS, function (eventName, eventSettings) {
                $(document).on(eventName, eventSettings.selector, configData, function (event) {
                    if (!config.DOM_EVENTS_ENABLED) {
                        return true;
                    }
                    event.data = $.extend(event.data, configData);
                    com.rooxteam.statistic.processEvent(event);
                    return true;
                });
            });
        }
    };

    com.rooxteam.statistic.getDomPath = function getDomPath(el) {
        var stack = [];
        while (el.parentNode !== null) {
            var sibCount = 0;
            var sibIndex = 0;
            for (var i = 0; i < el.parentNode.childNodes.length; i++) {
                var sib = el.parentNode.childNodes[i];
                if (sib.nodeName === el.nodeName) {
                    if (sib === el) {
                        sibIndex = sibCount;
                    }
                    sibCount++;
                }
            }
            if (el.hasAttribute('id') && el.id !== '') {
                stack.unshift(el.nodeName.toLowerCase() + '#' + el.id);
            } else if (sibCount > 1) {
                stack.unshift(el.nodeName.toLowerCase() + ':eq(' + sibIndex + ')');
            } else {
                stack.unshift(el.nodeName.toLowerCase());
            }
            el = el.parentNode;
        }

        return stack.slice(1).join(' ');
    };

    com.rooxteam.statistic.getContext =  function getContext(additional) {
        var dataContext = com.rooxteam.sharedcontext.getDataContext();
        var persistentDataContext = com.rooxteam.sharedcontext.getPersistentDataContext();
        var args = Array.prototype.slice.call(arguments);

        function getProperty(propertyName, autogenerate) {
            propertyName = 'com.roox.cm.Common.App.Properties.unit.' + propertyName;
            if (autogenerate) {
                var propertyValue = persistentDataContext.getDataSet(propertyName);
                if (!propertyValue) {
                    propertyValue = com.rooxteam.statistic.utils.guid();
                    persistentDataContext.putDataSet(propertyName, propertyValue);
                }
                dataContext.putDataSet(propertyName, propertyValue);
                return propertyValue;
            }
            return dataContext.getDataSet(propertyName);
        }

        if (dataContext) {
            args.unshift({
                'cmver': dataContext.getDataSet('com.roox.cm.Common.App.Properties.unit.AppArtifact') || '',
                'oid': dataContext.getDataSet('com.roox.cm.Common.App.Properties.unit.AppCode') || '',
                'uiid':  getProperty('UserInstallationId', com.rooxteam.config.statistic.AUTO_GENERATE_UIID) || '',
                'iid': dataContext.getDataSet('com.roox.cm.Common.App.Properties.unit.InstallationId') || ''
            });
        }
        if (com.rooxteam.config.statistic.META.CONTAINER.LOADED) {
            args.unshift({
                'cwrsver': com.rooxteam.config.statistic.META.CONTAINER.jobName + '-' + com.rooxteam.config.statistic.META.CONTAINER.buildNumber
            });
        }

        if (gadgets && gadgets.util && gadgets.util.hasFeature('com.rooxteam.network')) {
            var cachedMsisdn = persistentDataContext.getDataSet('com.rooxteam.cached_msisdn') || '';
            var currentMsisdn = (com.rooxteam.network.getMobileDevice() && com.rooxteam.network.getMobileDevice().getDeviceInfo().getPhoneNumber()) || '';
            currentMsisdn = currentMsisdn.replace('+', '');

            args.unshift({
                'mst': com.rooxteam.network.getMobileState(),
                'wst': com.rooxteam.network.getWifiState(),
                'fst': com.rooxteam.network.getFixedState(),
                'pn': currentMsisdn || cachedMsisdn
            });
        }

        args.unshift({});
        return $.extend.apply(null, args);
    };

    com.rooxteam.statistic.processEvent =  function precessEvent(event) {
        var config = com.rooxteam.config.statistic;
        var elementProperties = {};
        var verbose = (config.DOM_EVENTS[event.type] && config.DOM_EVENTS[event.type]['verbose']) || 4;
        if (event.target) {

            if (event.target.id) {
                elementProperties['id'] = event.target.id;
            } else {
                var path = com.rooxteam.statistic.getDomPath(event.target);
                if (path) {
                    elementProperties['path'] = path;
                }
            }

            if (event.target.className && verbose >= 1) {
                elementProperties['cls'] = event.target.className;
            }

            if (event.target.getAttribute('href') && verbose >= 4) {
                elementProperties['href'] = event.target.getAttribute('href');
            }

            if (event.target.getAttribute('onclick') && verbose >= 4) {
                elementProperties['clk'] = event.target.getAttribute('onclick');
            }


            if (event.target.getAttribute('alt') && verbose >= 7) {
                elementProperties['alt'] = event.target.getAttribute('alt');
            }

            if (event.target.getAttribute('title') && verbose >= 7) {
                elementProperties['title'] = event.target.getAttribute('title');
            }

            if ((!event.target.children || event.target.children.length === 0) && event.target.textContent && verbose === 9) {
                elementProperties['txt'] = event.target.textContent;
            }
        }
        var data = com.rooxteam.statistic.getContext(event.data, elementProperties);

        if (verbose >= 2) {
            com.rooxteam.statistic.client.logOperationAuth('event.' + event.type, data, 1, null, null);
        } else {
            com.rooxteam.statistic.client.logOperation('event.' + event.type, data, 1, null, null);
        }
    };

})(window.gadgets, window.jQuery, window.WinJS, window.document, window.TraceKit);;
var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};

(function (gadgets, $, document) {
    'use strict';
    com.rooxteam.statistic.getWidgetData = function getWidgetData() {
        var urlParams = com.rooxteam.statistic.utils.getUrlParameters(),
            widgetNameWithExt =  urlParams['widgetDescriptor'] || urlParams['url'] || '',
            widgetName = widgetNameWithExt.substr(0, widgetNameWithExt.lastIndexOf('.')) || widgetNameWithExt,
            mid = urlParams['mid'];
        if (widgetName) {
            widgetName = widgetName.split('/').pop();
        }
        return {'w': widgetName, 'mid': mid};
    };

    var widgetData = com.rooxteam.statistic.getWidgetData();
    com.rooxteam.statistic.initConfiguration(widgetData.w, null);
    $(window).on('load', function () {
        com.rooxteam.statistic.setupCapturingEvent(widgetData);
    });


    if (document.hidden !== 'undefined') {
        if (com.rooxteam.container && typeof com.rooxteam.container.renderType === 'string') {
            if (com.rooxteam.container.renderType.toUpperCase() === 'IFRAME' || com.rooxteam.container.renderType.toUpperCase() === 'INLINE') {
                // run under S-WRS
                $(document).on('visibilitychange', function () {
                    var id = document.hidden === true ? 'widget.hidden' : 'widget.display';
                    window.postMessage(JSON.stringify({id: id}), '*');
                });

                if (document.hidden === false) {
                    window.postMessage(JSON.stringify({id: 'widget.display'}), '*');
                }
            }
        }
    }

    var eventMethod = window.addEventListener ? 'addEventListener' : 'attachEvent',
        messageEvent = eventMethod === 'attachEvent' ? 'onmessage' : 'message';

    window[eventMethod](messageEvent, function (e) {
        var message;
        try {
            message = JSON.parse(e.data);
        } catch (e) {
            return;
        }
        if (message && message.id === 'widget.display') {
            var config = com.rooxteam.config.statistic;
            if (config.VIEW_EVENTS_ENABLED === true) {
                var dataLog = com.rooxteam.statistic.getContext(widgetData);
                com.rooxteam.statistic.client.logOperationAuth('widget.display', dataLog, 1, null, null);
            }
        }
    });
})(window.gadgets, window.jQuery, window.document);