/* global console */
if (!window.console || (window.console && !window.console.log)) {
    window.console = { log: function(){}};
}