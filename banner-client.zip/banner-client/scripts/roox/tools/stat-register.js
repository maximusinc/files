/*global com*/
(function (window, document, contentLoaded, utils, config) {

    /* replace current script path, need for wrs absolute path additional route */
    var path = utils.getParameterByName('url');
    path = path.replace(/[^\/]+$/,'js/tools/mobile.build-1.0.286.min.js');

    function onIframeLoad(){
        var scriptTag = 'script';
        var firstScript=document.getElementsByTagName(scriptTag)[0];

        var elementVal=document.createElement(scriptTag);
        elementVal.defer=true;
        elementVal.src=path;
        elementVal.type='text/javascript';
        firstScript.parentNode.insertBefore(elementVal,firstScript);

        var setStatEnable = function () {
            if (!com.rooxteam.config.statistic.ENABLED) {
                com.rooxteam.config.statistic.ENABLED = true;
            }
        };

        function onScriptLoad() {
            var mainContent = document.getElementById('main-content');
            var widgetName = 'MobileBalance_h2o';

            com.rooxteam.statistic.updateConfiguration(
                com.rooxteam.config.statistic,
                {
                    "ENABLED": true,
                    "LIC_ENABLED": true,
                    "SERVER_ADDRESS": 'http://oauth.mts.ru/pushreport',
                    "SERVICE_TYPE_PARAMETER": 'YA_REPORT_SERVICE',
                    "CHECKSUM_PARAMETER": 'YA_REPORT_CHECKSUM',
                    "SENDING_TIME_PARAMETER": 'YA_REPORT_SENDING_TIME',
                    "COUNTER_SERVICE_TYPE": 'counter',
                    "ACCUMULATE_TIME": 5000,
                    'TIMER_UPDATE_INTERVAL': 2000,
                    "ACCUMULATE_OPERATION_LIMIT": 3,        //after this accumulate operation limit - try send to server report
                    "OVER_ACCUMULATE_OPERATION_LIMIT": 30,     //max over accumulation limit if can't send report
                    "MAX_URL_LENGTH": 2000,
                    "TRACEKIT_ENABLED": false,
                    "IO_EVENTS_ENABLED": true,
                    "VIEW_EVENTS_ENABLED": true,
                    "DOM_EVENTS_ENABLED": true,
                    "DOM_EVENTS": {
                        "click": {
                            "verbose": 4,
                            "selector": ""
                        }
                    }
                },
                config.WIDGET_NAME,
                ""
            );

            if (window.gadgets) {
                // if stat configuration can be overriden by container
                window.setTimeout(setStatEnable,500);
            }
        }
        //Handle statistic feature load event
        if (elementVal.addEventListener) {
            elementVal.addEventListener('load',onScriptLoad);
        } else if(elementVal.readyState) {
            elementVal.onreadystatechange = onScriptLoad;
        }
    }


    //Load statistic feature deferred
    contentLoaded(window,onIframeLoad);
})(window, document, contentLoaded, com.rooxteam.widgets.services.utils, com.rooxteam.widgets.config);