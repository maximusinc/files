var com = com || {};
com.rooxteam = com.rooxteam || {};
com.rooxteam.statistic = com.rooxteam.statistic || {};
com.rooxteam.statistic.client = com.rooxteam.statistic.client || {};

(function (cache) {
	'use strict';
	var storeProperty = 'beforeLoadLogData';
	com.rooxteam.statistic.client.logOperation = function () {
		var statStore = com.rooxteam.statistic.client,
			args = Array.prototype.slice.call(arguments);
		if (!statStore[storeProperty]) {
			statStore[storeProperty] = [];
		}
		statStore[storeProperty].push(args);
	};
	com.rooxteam.statistic.getContext = function(data){
    	var dataContext = cache.getSharedContext(false);
        try {
            data['iid'] = dataContext.getDataSet("com.roox.cm.Common.App.Properties.unit.InstallationId");
            data['cmver'] = dataContext.getDataSet('com.roox.cm.Common.App.Properties.unit.AppArtifact');
            data['oid'] = dataContext.getDataSet('com.roox.cm.Common.App.Properties.unit.AppCode');
            data['uiid'] = dataContext.getDataSet('com.roox.cm.Common.App.Properties.unit.UserInstallationId');
        } catch(e) {
            //fail silently
        }
        return data;
    };
})(com.rooxteam.widgets.services.cache);
