(function ($) {
	window.rooxTargeting = (function () {
		var targetingData,
			body = document.body,
			defer = $.Deferred(),
			makeIframe = function () {
				var random = Math.floor(Math.random() * 1e6),
					iframe = '<iframe id="RooX_iframe_' + random + '" src="number.html" width=1 height=1 marginwidth=0 marginheight=0 scrolling=no frameborder=0></iframe>';
				$('body').append(iframe);
				console.info( 'add element to body: ' + iframe);
			},
			get = function () {
				return targetingData && targetingData.data || '';
			},
			wait = function () {
				return defer.promise();
			};
		makeIframe();
		$(window).on('message', function (e) {
			var data = e.originalEvent.data;
			console.info('postMessage from RooX: ', e.originalEvent.data );
			targetingData = JSON.parse(data);
			defer.resolve( targetingData );
		});

		window.setTimeout(function () {
			console.info('resolve Defaulf after 2500');
			defer.resolve({});
		}, 2500);

		return {
			wait: wait,
			get: get
		};
	})();

	var keyWordsMap = ['one', 'two', 'three', 'four'];
	var targetingManager = {
		timeout: 2000,
		def: $.Deferred(),
		endPoint: 'http://sso.mgf.hosted:8080/webapi-3.0/targetedOfferings',
		_val: null,
		get: function () {
			this.request();
			this.timer();
			return this.def.promise();
		},
		proccesResponse: function (jsonResp) {
			var result = [];
			$.each(jsonResp, function (i,item) {
				result.push( keyWordsMap[ window.parseInt(item.id, 10) - 1 ] );
			});

			if (result.length) {
				this._val = window.encodeURIComponent(result.join(' '));
				this.def.resolve( window.encodeURIComponent(result.join(' ')) );
			} else {
				this.resolveDefault();
			}
		},
		request: function () {
			var self = this;
			$.ajax({
				url: self.endPoint,
				dataType: 'json',
				success: function (json) {
					self.proccesResponse(json);
				},
				error: function () {
					self.resolveDefault();
				}
			})
		},
		timer: function () {
			var self = this;
			window.setTimeout(function () {
				if (!self._val) {
					console.info("timer > " + self.timeout);
					self.resolveDefault();
				}
			}, self.timeout);
		},
		resolveDefault: function () {
			this._val = window.encodeURIComponent( keyWordsMap.join(' ') );
			this.def.resolve( window.encodeURIComponent( keyWordsMap.join(' ') ) );
		},
		val: function () {
			return this._val;
		}
	};

	window.targetingManager = targetingManager;

	com.rooxteam.widget.pubSub.on('roox.showSlideFirstTime', function () {
		com.rooxteam.statistic.client.logOperation('bannerDisplay', {name: 'some' + (new Date()) });
		console.info('com.rooxteam.statistic.client.logOperation:bannerDisplay');
	});

})(window.jQuery);