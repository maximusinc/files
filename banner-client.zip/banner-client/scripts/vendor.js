(function() {
	(function(e, t) {
		var n, i, r = typeof t,
			o = e.location,
			s = e.document,
			a = s.documentElement,
			u = e.jQuery,
			l = e.$,
			f = {},
			c = [],
			p = "1.10.2",
			d = c.concat,
			h = c.push,
			g = c.slice,
			m = c.indexOf,
			y = f.toString,
			v = f.hasOwnProperty,
			b = p.trim,
			x = function(e, t) {
				return new x.fn.init(e, t, i)
			},
			w = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
			T = /\S+/g,
			C = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
			N = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
			k = /^<(\w+)\s*\/?>(?:<\/\1>|)$/,
			E = /^[\],:{}\s]*$/,
			S = /(?:^|:|,)(?:\s*\[)+/g,
			A = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g,
			j = /"[^"\\\r\n]*"|true|false|null|-?(?:\d+\.|)\d+(?:[eE][+-]?\d+|)/g,
			D = /^-ms-/,
			L = /-([\da-z])/gi,
			H = function(e, t) {
				return t.toUpperCase()
			},
			q = function(e) {
				if (s.addEventListener || e.type === "load" || s.readyState === "complete") {
					_();
					x.ready()
				}
			},
			_ = function() {
				if (s.addEventListener) {
					s.removeEventListener("DOMContentLoaded", q, false);
					e.removeEventListener("load", q, false)
				} else {
					s.detachEvent("onreadystatechange", q);
					e.detachEvent("onload", q)
				}
			};
		x.fn = x.prototype = {
			jquery: p,
			constructor: x,
			init: function(e, n, i) {
				var r, o;
				if (!e) {
					return this
				}
				if (typeof e === "string") {
					if (e.charAt(0) === "<" && e.charAt(e.length - 1) === ">" && e.length >= 3) {
						r = [null, e, null]
					} else {
						r = N.exec(e)
					} if (r && (r[1] || !n)) {
						if (r[1]) {
							n = n instanceof x ? n[0] : n;
							x.merge(this, x.parseHTML(r[1], n && n.nodeType ? n.ownerDocument || n : s, true));
							if (k.test(r[1]) && x.isPlainObject(n)) {
								for (r in n) {
									if (x.isFunction(this[r])) {
										this[r](n[r])
									} else {
										this.attr(r, n[r])
									}
								}
							}
							return this
						} else {
							o = s.getElementById(r[2]);
							if (o && o.parentNode) {
								if (o.id !== r[2]) {
									return i.find(e)
								}
								this.length = 1;
								this[0] = o
							}
							this.context = s;
							this.selector = e;
							return this
						}
					} else if (!n || n.jquery) {
						return (n || i).find(e)
					} else {
						return this.constructor(n).find(e)
					}
				} else if (e.nodeType) {
					this.context = this[0] = e;
					this.length = 1;
					return this
				} else if (x.isFunction(e)) {
					return i.ready(e)
				}
				if (e.selector !== t) {
					this.selector = e.selector;
					this.context = e.context
				}
				return x.makeArray(e, this)
			},
			selector: "",
			length: 0,
			toArray: function() {
				return g.call(this)
			},
			get: function(e) {
				return e == null ? this.toArray() : e < 0 ? this[this.length + e] : this[e]
			},
			pushStack: function(e) {
				var t = x.merge(this.constructor(), e);
				t.prevObject = this;
				t.context = this.context;
				return t
			},
			each: function(e, t) {
				return x.each(this, e, t)
			},
			ready: function(e) {
				x.ready.promise().done(e);
				return this
			},
			slice: function() {
				return this.pushStack(g.apply(this, arguments))
			},
			first: function() {
				return this.eq(0)
			},
			last: function() {
				return this.eq(-1)
			},
			eq: function(e) {
				var t = this.length,
					n = +e + (e < 0 ? t : 0);
				return this.pushStack(n >= 0 && n < t ? [this[n]] : [])
			},
			map: function(e) {
				return this.pushStack(x.map(this, function(t, n) {
					return e.call(t, n, t)
				}))
			},
			end: function() {
				return this.prevObject || this.constructor(null)
			},
			push: h,
			sort: [].sort,
			splice: [].splice
		};
		x.fn.init.prototype = x.fn;
		x.extend = x.fn.extend = function() {
			var e, n, i, r, o, s, a = arguments[0] || {},
				u = 1,
				l = arguments.length,
				f = false;
			if (typeof a === "boolean") {
				f = a;
				a = arguments[1] || {};
				u = 2
			}
			if (typeof a !== "object" && !x.isFunction(a)) {
				a = {}
			}
			if (l === u) {
				a = this;
				--u
			}
			for (; u < l; u++) {
				if ((o = arguments[u]) != null) {
					for (r in o) {
						e = a[r];
						i = o[r];
						if (a === i) {
							continue
						}
						if (f && i && (x.isPlainObject(i) || (n = x.isArray(i)))) {
							if (n) {
								n = false;
								s = e && x.isArray(e) ? e : []
							} else {
								s = e && x.isPlainObject(e) ? e : {}
							}
							a[r] = x.extend(f, s, i)
						} else if (i !== t) {
							a[r] = i
						}
					}
				}
			}
			return a
		};
		x.extend({
			expando: "jQuery" + (p + Math.random()).replace(/\D/g, ""),
			noConflict: function(t) {
				if (e.$ === x) {
					e.$ = l
				}
				if (t && e.jQuery === x) {
					e.jQuery = u
				}
				return x
			},
			isReady: false,
			readyWait: 1,
			holdReady: function(e) {
				if (e) {
					x.readyWait++
				} else {
					x.ready(true)
				}
			},
			ready: function(e) {
				if (e === true ? --x.readyWait : x.isReady) {
					return
				}
				if (!s.body) {
					return setTimeout(x.ready)
				}
				x.isReady = true;
				if (e !== true && --x.readyWait > 0) {
					return
				}
				n.resolveWith(s, [x]);
				if (x.fn.trigger) {
					x(s).trigger("ready").off("ready")
				}
			},
			isFunction: function(e) {
				return x.type(e) === "function"
			},
			isArray: Array.isArray || function(e) {
				return x.type(e) === "array"
			},
			isWindow: function(e) {
				return e != null && e == e.window
			},
			isNumeric: function(e) {
				return !isNaN(parseFloat(e)) && isFinite(e)
			},
			type: function(e) {
				if (e == null) {
					return String(e)
				}
				return typeof e === "object" || typeof e === "function" ? f[y.call(e)] || "object" : typeof e
			},
			isPlainObject: function(e) {
				var n;
				if (!e || x.type(e) !== "object" || e.nodeType || x.isWindow(e)) {
					return false
				}
				try {
					if (e.constructor && !v.call(e, "constructor") && !v.call(e.constructor.prototype, "isPrototypeOf")) {
						return false
					}
				} catch (i) {
					return false
				}
				if (x.support.ownLast) {
					for (n in e) {
						return v.call(e, n)
					}
				}
				for (n in e) {}
				return n === t || v.call(e, n)
			},
			isEmptyObject: function(e) {
				var t;
				for (t in e) {
					return false
				}
				return true
			},
			error: function(e) {
				throw new Error(e)
			},
			parseHTML: function(e, t, n) {
				if (!e || typeof e !== "string") {
					return null
				}
				if (typeof t === "boolean") {
					n = t;
					t = false
				}
				t = t || s;
				var i = k.exec(e),
					r = !n && [];
				if (i) {
					return [t.createElement(i[1])]
				}
				i = x.buildFragment([e], t, r);
				if (r) {
					x(r).remove()
				}
				return x.merge([], i.childNodes)
			},
			parseJSON: function(t) {
				if (e.JSON && e.JSON.parse) {
					return e.JSON.parse(t)
				}
				if (t === null) {
					return t
				}
				if (typeof t === "string") {
					t = x.trim(t);
					if (t) {
						if (E.test(t.replace(A, "@").replace(j, "]").replace(S, ""))) {
							return new Function("return " + t)()
						}
					}
				}
				x.error("Invalid JSON: " + t)
			},
			parseXML: function(n) {
				var i, r;
				if (!n || typeof n !== "string") {
					return null
				}
				try {
					if (e.DOMParser) {
						r = new DOMParser;
						i = r.parseFromString(n, "text/xml")
					} else {
						i = new ActiveXObject("Microsoft.XMLDOM");
						i.async = "false";
						i.loadXML(n)
					}
				} catch (o) {
					i = t
				}
				if (!i || !i.documentElement || i.getElementsByTagName("parsererror").length) {
					x.error("Invalid XML: " + n)
				}
				return i
			},
			noop: function() {},
			globalEval: function(t) {
				if (t && x.trim(t)) {
					(e.execScript || function(t) {
						e["eval"].call(e, t)
					})(t)
				}
			},
			camelCase: function(e) {
				return e.replace(D, "ms-").replace(L, H)
			},
			nodeName: function(e, t) {
				return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
			},
			each: function(e, t, n) {
				var i, r = 0,
					o = e.length,
					s = M(e);
				if (n) {
					if (s) {
						for (; r < o; r++) {
							i = t.apply(e[r], n);
							if (i === false) {
								break
							}
						}
					} else {
						for (r in e) {
							i = t.apply(e[r], n);
							if (i === false) {
								break
							}
						}
					}
				} else {
					if (s) {
						for (; r < o; r++) {
							i = t.call(e[r], r, e[r]);
							if (i === false) {
								break
							}
						}
					} else {
						for (r in e) {
							i = t.call(e[r], r, e[r]);
							if (i === false) {
								break
							}
						}
					}
				}
				return e
			},
			trim: b && !b.call("﻿ ") ? function(e) {
				return e == null ? "" : b.call(e)
			} : function(e) {
				return e == null ? "" : (e + "").replace(C, "")
			},
			makeArray: function(e, t) {
				var n = t || [];
				if (e != null) {
					if (M(Object(e))) {
						x.merge(n, typeof e === "string" ? [e] : e)
					} else {
						h.call(n, e)
					}
				}
				return n
			},
			inArray: function(e, t, n) {
				var i;
				if (t) {
					if (m) {
						return m.call(t, e, n)
					}
					i = t.length;
					n = n ? n < 0 ? Math.max(0, i + n) : n : 0;
					for (; n < i; n++) {
						if (n in t && t[n] === e) {
							return n
						}
					}
				}
				return -1
			},
			merge: function(e, n) {
				var i = n.length,
					r = e.length,
					o = 0;
				if (typeof i === "number") {
					for (; o < i; o++) {
						e[r++] = n[o]
					}
				} else {
					while (n[o] !== t) {
						e[r++] = n[o++]
					}
				}
				e.length = r;
				return e
			},
			grep: function(e, t, n) {
				var i, r = [],
					o = 0,
					s = e.length;
				n = !!n;
				for (; o < s; o++) {
					i = !!t(e[o], o);
					if (n !== i) {
						r.push(e[o])
					}
				}
				return r
			},
			map: function(e, t, n) {
				var i, r = 0,
					o = e.length,
					s = M(e),
					a = [];
				if (s) {
					for (; r < o; r++) {
						i = t(e[r], r, n);
						if (i != null) {
							a[a.length] = i
						}
					}
				} else {
					for (r in e) {
						i = t(e[r], r, n);
						if (i != null) {
							a[a.length] = i
						}
					}
				}
				return d.apply([], a)
			},
			guid: 1,
			proxy: function(e, n) {
				var i, r, o;
				if (typeof n === "string") {
					o = e[n];
					n = e;
					e = o
				}
				if (!x.isFunction(e)) {
					return t
				}
				i = g.call(arguments, 2);
				r = function() {
					return e.apply(n || this, i.concat(g.call(arguments)))
				};
				r.guid = e.guid = e.guid || x.guid++;
				return r
			},
			access: function(e, n, i, r, o, s, a) {
				var u = 0,
					l = e.length,
					f = i == null;
				if (x.type(i) === "object") {
					o = true;
					for (u in i) {
						x.access(e, n, u, i[u], true, s, a)
					}
				} else if (r !== t) {
					o = true;
					if (!x.isFunction(r)) {
						a = true
					}
					if (f) {
						if (a) {
							n.call(e, r);
							n = null
						} else {
							f = n;
							n = function(e, t, n) {
								return f.call(x(e), n)
							}
						}
					}
					if (n) {
						for (; u < l; u++) {
							n(e[u], i, a ? r : r.call(e[u], u, n(e[u], i)))
						}
					}
				}
				return o ? e : f ? n.call(e) : l ? n(e[0], i) : s
			},
			now: function() {
				return (new Date).getTime()
			},
			swap: function(e, t, n, i) {
				var r, o, s = {};
				for (o in t) {
					s[o] = e.style[o];
					e.style[o] = t[o]
				}
				r = n.apply(e, i || []);
				for (o in t) {
					e.style[o] = s[o]
				}
				return r
			}
		});
		x.ready.promise = function(t) {
			if (!n) {
				n = x.Deferred();
				if (s.readyState === "complete") {
					setTimeout(x.ready)
				} else if (s.addEventListener) {
					s.addEventListener("DOMContentLoaded", q, false);
					e.addEventListener("load", q, false)
				} else {
					s.attachEvent("onreadystatechange", q);
					e.attachEvent("onload", q);
					var i = false;
					try {
						i = e.frameElement == null && s.documentElement
					} catch (r) {}
					if (i && i.doScroll) {
						(function o() {
							if (!x.isReady) {
								try {
									i.doScroll("left")
								} catch (e) {
									return setTimeout(o, 50)
								}
								_();
								x.ready()
							}
						})()
					}
				}
			}
			return n.promise(t)
		};
		x.each("Boolean Number String Function Array Date RegExp Object Error".split(" "), function(e, t) {
			f["[object " + t + "]"] = t.toLowerCase()
		});

		function M(e) {
			var t = e.length,
				n = x.type(e);
			if (x.isWindow(e)) {
				return false
			}
			if (e.nodeType === 1 && t) {
				return true
			}
			return n === "array" || n !== "function" && (t === 0 || typeof t === "number" && t > 0 && t - 1 in e)
		}
		i = x(s);
		(function(e, t) {
			var n, i, r, o, s, a, u, l, f, c, p, d, h, g, m, y, v, b = "sizzle" + -new Date,
				w = e.document,
				T = 0,
				C = 0,
				N = at(),
				k = at(),
				E = at(),
				S = false,
				A = function(e, t) {
					if (e === t) {
						S = true;
						return 0
					}
					return 0
				},
				j = typeof t,
				D = 1 << 31,
				L = {}.hasOwnProperty,
				H = [],
				q = H.pop,
				_ = H.push,
				M = H.push,
				O = H.slice,
				F = H.indexOf || function(e) {
					var t = 0,
						n = this.length;
					for (; t < n; t++) {
						if (this[t] === e) {
							return t
						}
					}
					return -1
				},
				B = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
				P = "[\\x20\\t\\r\\n\\f]",
				R = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
				W = R.replace("w", "w#"),
				$ = "\\[" + P + "*(" + R + ")" + P + "*(?:([*^$|!~]?=)" + P + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + W + ")|)|)" + P + "*\\]",
				I = ":(" + R + ")(?:\\(((['\"])((?:\\\\.|[^\\\\])*?)\\3|((?:\\\\.|[^\\\\()[\\]]|" + $.replace(3, 8) + ")*)|.*)\\)|)",
				z = new RegExp("^" + P + "+|((?:^|[^\\\\])(?:\\\\.)*)" + P + "+$", "g"),
				X = new RegExp("^" + P + "*," + P + "*"),
				U = new RegExp("^" + P + "*([>+~]|" + P + ")" + P + "*"),
				V = new RegExp(P + "*[+~]"),
				Y = new RegExp("=" + P + "*([^\\]'\"]*)" + P + "*\\]", "g"),
				J = new RegExp(I),
				G = new RegExp("^" + W + "$"),
				Q = {
					ID: new RegExp("^#(" + R + ")"),
					CLASS: new RegExp("^\\.(" + R + ")"),
					TAG: new RegExp("^(" + R.replace("w", "w*") + ")"),
					ATTR: new RegExp("^" + $),
					PSEUDO: new RegExp("^" + I),
					CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + P + "*(even|odd|(([+-]|)(\\d*)n|)" + P + "*(?:([+-]|)" + P + "*(\\d+)|))" + P + "*\\)|)", "i"),
					bool: new RegExp("^(?:" + B + ")$", "i"),
					needsContext: new RegExp("^" + P + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + P + "*((?:-\\d)?\\d*)" + P + "*\\)|)(?=[^-]|$)", "i")
				},
				K = /^[^{]+\{\s*\[native \w/,
				Z = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
				et = /^(?:input|select|textarea|button)$/i,
				tt = /^h\d$/i,
				nt = /'|\\/g,
				it = new RegExp("\\\\([\\da-f]{1,6}" + P + "?|(" + P + ")|.)", "ig"),
				rt = function(e, t, n) {
					var i = "0x" + t - 65536;
					return i !== i || n ? t : i < 0 ? String.fromCharCode(i + 65536) : String.fromCharCode(i >> 10 | 55296, i & 1023 | 56320)
				};
			try {
				M.apply(H = O.call(w.childNodes), w.childNodes);
				H[w.childNodes.length].nodeType
			} catch (ot) {
				M = {
					apply: H.length ? function(e, t) {
						_.apply(e, O.call(t))
					} : function(e, t) {
						var n = e.length,
							i = 0;
						while (e[n++] = t[i++]) {}
						e.length = n - 1
					}
				}
			}

			function st(e, t, n, r) {
				var o, s, a, u, l, f, d, m, y, x;
				if ((t ? t.ownerDocument || t : w) !== p) {
					c(t)
				}
				t = t || p;
				n = n || [];
				if (!e || typeof e !== "string") {
					return n
				}
				if ((u = t.nodeType) !== 1 && u !== 9) {
					return []
				}
				if (h && !r) {
					if (o = Z.exec(e)) {
						if (a = o[1]) {
							if (u === 9) {
								s = t.getElementById(a);
								if (s && s.parentNode) {
									if (s.id === a) {
										n.push(s);
										return n
									}
								} else {
									return n
								}
							} else {
								if (t.ownerDocument && (s = t.ownerDocument.getElementById(a)) && v(t, s) && s.id === a) {
									n.push(s);
									return n
								}
							}
						} else if (o[2]) {
							M.apply(n, t.getElementsByTagName(e));
							return n
						} else if ((a = o[3]) && i.getElementsByClassName && t.getElementsByClassName) {
							M.apply(n, t.getElementsByClassName(a));
							return n
						}
					}
					if (i.qsa && (!g || !g.test(e))) {
						m = d = b;
						y = t;
						x = u === 9 && e;
						if (u === 1 && t.nodeName.toLowerCase() !== "object") {
							f = mt(e);
							if (d = t.getAttribute("id")) {
								m = d.replace(nt, "\\$&")
							} else {
								t.setAttribute("id", m)
							}
							m = "[id='" + m + "'] ";
							l = f.length;
							while (l--) {
								f[l] = m + yt(f[l])
							}
							y = V.test(e) && t.parentNode || t;
							x = f.join(",")
						}
						if (x) {
							try {
								M.apply(n, y.querySelectorAll(x));
								return n
							} catch (T) {} finally {
								if (!d) {
									t.removeAttribute("id")
								}
							}
						}
					}
				}
				return kt(e.replace(z, "$1"), t, n, r)
			}

			function at() {
				var e = [];

				function t(n, i) {
					if (e.push(n += " ") > o.cacheLength) {
						delete t[e.shift()]
					}
					return t[n] = i
				}
				return t
			}

			function ut(e) {
				e[b] = true;
				return e
			}

			function lt(e) {
				var t = p.createElement("div");
				try {
					return !!e(t)
				} catch (n) {
					return false
				} finally {
					if (t.parentNode) {
						t.parentNode.removeChild(t)
					}
					t = null
				}
			}

			function ft(e, t) {
				var n = e.split("|"),
					i = e.length;
				while (i--) {
					o.attrHandle[n[i]] = t
				}
			}

			function ct(e, t) {
				var n = t && e,
					i = n && e.nodeType === 1 && t.nodeType === 1 && (~t.sourceIndex || D) - (~e.sourceIndex || D);
				if (i) {
					return i
				}
				if (n) {
					while (n = n.nextSibling) {
						if (n === t) {
							return -1
						}
					}
				}
				return e ? 1 : -1
			}

			function pt(e) {
				return function(t) {
					var n = t.nodeName.toLowerCase();
					return n === "input" && t.type === e
				}
			}

			function dt(e) {
				return function(t) {
					var n = t.nodeName.toLowerCase();
					return (n === "input" || n === "button") && t.type === e
				}
			}

			function ht(e) {
				return ut(function(t) {
					t = +t;
					return ut(function(n, i) {
						var r, o = e([], n.length, t),
							s = o.length;
						while (s--) {
							if (n[r = o[s]]) {
								n[r] = !(i[r] = n[r])
							}
						}
					})
				})
			}
			a = st.isXML = function(e) {
				var t = e && (e.ownerDocument || e).documentElement;
				return t ? t.nodeName !== "HTML" : false
			};
			i = st.support = {};
			c = st.setDocument = function(e) {
				var t = e ? e.ownerDocument || e : w,
					n = t.defaultView;
				if (t === p || t.nodeType !== 9 || !t.documentElement) {
					return p
				}
				p = t;
				d = t.documentElement;
				h = !a(t);
				if (n && n.attachEvent && n !== n.top) {
					n.attachEvent("onbeforeunload", function() {
						c()
					})
				}
				i.attributes = lt(function(e) {
					e.className = "i";
					return !e.getAttribute("className")
				});
				i.getElementsByTagName = lt(function(e) {
					e.appendChild(t.createComment(""));
					return !e.getElementsByTagName("*").length
				});
				i.getElementsByClassName = lt(function(e) {
					e.innerHTML = "<div class='a'></div><div class='a i'></div>";
					e.firstChild.className = "i";
					return e.getElementsByClassName("i").length === 2
				});
				i.getById = lt(function(e) {
					d.appendChild(e).id = b;
					return !t.getElementsByName || !t.getElementsByName(b).length
				});
				if (i.getById) {
					o.find["ID"] = function(e, t) {
						if (typeof t.getElementById !== j && h) {
							var n = t.getElementById(e);
							return n && n.parentNode ? [n] : []
						}
					};
					o.filter["ID"] = function(e) {
						var t = e.replace(it, rt);
						return function(e) {
							return e.getAttribute("id") === t
						}
					}
				} else {
					delete o.find["ID"];
					o.filter["ID"] = function(e) {
						var t = e.replace(it, rt);
						return function(e) {
							var n = typeof e.getAttributeNode !== j && e.getAttributeNode("id");
							return n && n.value === t
						}
					}
				}
				o.find["TAG"] = i.getElementsByTagName ? function(e, t) {
					if (typeof t.getElementsByTagName !== j) {
						return t.getElementsByTagName(e)
					}
				} : function(e, t) {
					var n, i = [],
						r = 0,
						o = t.getElementsByTagName(e);
					if (e === "*") {
						while (n = o[r++]) {
							if (n.nodeType === 1) {
								i.push(n)
							}
						}
						return i
					}
					return o
				};
				o.find["CLASS"] = i.getElementsByClassName && function(e, t) {
					if (typeof t.getElementsByClassName !== j && h) {
						return t.getElementsByClassName(e)
					}
				};
				m = [];
				g = [];
				if (i.qsa = K.test(t.querySelectorAll)) {
					lt(function(e) {
						e.innerHTML = "<select><option selected=''></option></select>";
						if (!e.querySelectorAll("[selected]").length) {
							g.push("\\[" + P + "*(?:value|" + B + ")")
						}
						if (!e.querySelectorAll(":checked").length) {
							g.push(":checked")
						}
					});
					lt(function(e) {
						var n = t.createElement("input");
						n.setAttribute("type", "hidden");
						e.appendChild(n).setAttribute("t", "");
						if (e.querySelectorAll("[t^='']").length) {
							g.push("[*^$]=" + P + "*(?:''|\"\")")
						}
						if (!e.querySelectorAll(":enabled").length) {
							g.push(":enabled", ":disabled")
						}
						e.querySelectorAll("*,:x");
						g.push(",.*:")
					})
				}
				if (i.matchesSelector = K.test(y = d.webkitMatchesSelector || d.mozMatchesSelector || d.oMatchesSelector || d.msMatchesSelector)) {
					lt(function(e) {
						i.disconnectedMatch = y.call(e, "div");
						y.call(e, "[s!='']:x");
						m.push("!=", I)
					})
				}
				g = g.length && new RegExp(g.join("|"));
				m = m.length && new RegExp(m.join("|"));
				v = K.test(d.contains) || d.compareDocumentPosition ? function(e, t) {
					var n = e.nodeType === 9 ? e.documentElement : e,
						i = t && t.parentNode;
					return e === i || !!(i && i.nodeType === 1 && (n.contains ? n.contains(i) : e.compareDocumentPosition && e.compareDocumentPosition(i) & 16))
				} : function(e, t) {
					if (t) {
						while (t = t.parentNode) {
							if (t === e) {
								return true
							}
						}
					}
					return false
				};
				A = d.compareDocumentPosition ? function(e, n) {
					if (e === n) {
						S = true;
						return 0
					}
					var r = n.compareDocumentPosition && e.compareDocumentPosition && e.compareDocumentPosition(n);
					if (r) {
						if (r & 1 || !i.sortDetached && n.compareDocumentPosition(e) === r) {
							if (e === t || v(w, e)) {
								return -1
							}
							if (n === t || v(w, n)) {
								return 1
							}
							return f ? F.call(f, e) - F.call(f, n) : 0
						}
						return r & 4 ? -1 : 1
					}
					return e.compareDocumentPosition ? -1 : 1
				} : function(e, n) {
					var i, r = 0,
						o = e.parentNode,
						s = n.parentNode,
						a = [e],
						u = [n];
					if (e === n) {
						S = true;
						return 0
					} else if (!o || !s) {
						return e === t ? -1 : n === t ? 1 : o ? -1 : s ? 1 : f ? F.call(f, e) - F.call(f, n) : 0
					} else if (o === s) {
						return ct(e, n)
					}
					i = e;
					while (i = i.parentNode) {
						a.unshift(i)
					}
					i = n;
					while (i = i.parentNode) {
						u.unshift(i)
					}
					while (a[r] === u[r]) {
						r++
					}
					return r ? ct(a[r], u[r]) : a[r] === w ? -1 : u[r] === w ? 1 : 0
				};
				return t
			};
			st.matches = function(e, t) {
				return st(e, null, null, t)
			};
			st.matchesSelector = function(e, t) {
				if ((e.ownerDocument || e) !== p) {
					c(e)
				}
				t = t.replace(Y, "='$1']");
				if (i.matchesSelector && h && (!m || !m.test(t)) && (!g || !g.test(t))) {
					try {
						var n = y.call(e, t);
						if (n || i.disconnectedMatch || e.document && e.document.nodeType !== 11) {
							return n
						}
					} catch (r) {}
				}
				return st(t, p, null, [e]).length > 0
			};
			st.contains = function(e, t) {
				if ((e.ownerDocument || e) !== p) {
					c(e)
				}
				return v(e, t)
			};
			st.attr = function(e, n) {
				if ((e.ownerDocument || e) !== p) {
					c(e)
				}
				var r = o.attrHandle[n.toLowerCase()],
					s = r && L.call(o.attrHandle, n.toLowerCase()) ? r(e, n, !h) : t;
				return s === t ? i.attributes || !h ? e.getAttribute(n) : (s = e.getAttributeNode(n)) && s.specified ? s.value : null : s
			};
			st.error = function(e) {
				throw new Error("Syntax error, unrecognized expression: " + e)
			};
			st.uniqueSort = function(e) {
				var t, n = [],
					r = 0,
					o = 0;
				S = !i.detectDuplicates;
				f = !i.sortStable && e.slice(0);
				e.sort(A);
				if (S) {
					while (t = e[o++]) {
						if (t === e[o]) {
							r = n.push(o)
						}
					}
					while (r--) {
						e.splice(n[r], 1)
					}
				}
				return e
			};
			s = st.getText = function(e) {
				var t, n = "",
					i = 0,
					r = e.nodeType;
				if (!r) {
					for (; t = e[i]; i++) {
						n += s(t)
					}
				} else if (r === 1 || r === 9 || r === 11) {
					if (typeof e.textContent === "string") {
						return e.textContent
					} else {
						for (e = e.firstChild; e; e = e.nextSibling) {
							n += s(e)
						}
					}
				} else if (r === 3 || r === 4) {
					return e.nodeValue
				}
				return n
			};
			o = st.selectors = {
				cacheLength: 50,
				createPseudo: ut,
				match: Q,
				attrHandle: {},
				find: {},
				relative: {
					">": {
						dir: "parentNode",
						first: true
					},
					" ": {
						dir: "parentNode"
					},
					"+": {
						dir: "previousSibling",
						first: true
					},
					"~": {
						dir: "previousSibling"
					}
				},
				preFilter: {
					ATTR: function(e) {
						e[1] = e[1].replace(it, rt);
						e[3] = (e[4] || e[5] || "").replace(it, rt);
						if (e[2] === "~=") {
							e[3] = " " + e[3] + " "
						}
						return e.slice(0, 4)
					},
					CHILD: function(e) {
						e[1] = e[1].toLowerCase();
						if (e[1].slice(0, 3) === "nth") {
							if (!e[3]) {
								st.error(e[0])
							}
							e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * (e[3] === "even" || e[3] === "odd"));
							e[5] = +(e[7] + e[8] || e[3] === "odd")
						} else if (e[3]) {
							st.error(e[0])
						}
						return e
					},
					PSEUDO: function(e) {
						var n, i = !e[5] && e[2];
						if (Q["CHILD"].test(e[0])) {
							return null
						}
						if (e[3] && e[4] !== t) {
							e[2] = e[4]
						} else if (i && J.test(i) && (n = mt(i, true)) && (n = i.indexOf(")", i.length - n) - i.length)) {
							e[0] = e[0].slice(0, n);
							e[2] = i.slice(0, n)
						}
						return e.slice(0, 3)
					}
				},
				filter: {
					TAG: function(e) {
						var t = e.replace(it, rt).toLowerCase();
						return e === "*" ? function() {
							return true
						} : function(e) {
							return e.nodeName && e.nodeName.toLowerCase() === t
						}
					},
					CLASS: function(e) {
						var t = N[e + " "];
						return t || (t = new RegExp("(^|" + P + ")" + e + "(" + P + "|$)")) && N(e, function(e) {
							return t.test(typeof e.className === "string" && e.className || typeof e.getAttribute !== j && e.getAttribute("class") || "")
						})
					},
					ATTR: function(e, t, n) {
						return function(i) {
							var r = st.attr(i, e);
							if (r == null) {
								return t === "!="
							}
							if (!t) {
								return true
							}
							r += "";
							return t === "=" ? r === n : t === "!=" ? r !== n : t === "^=" ? n && r.indexOf(n) === 0 : t === "*=" ? n && r.indexOf(n) > -1 : t === "$=" ? n && r.slice(-n.length) === n : t === "~=" ? (" " + r + " ").indexOf(n) > -1 : t === "|=" ? r === n || r.slice(0, n.length + 1) === n + "-" : false
						}
					},
					CHILD: function(e, t, n, i, r) {
						var o = e.slice(0, 3) !== "nth",
							s = e.slice(-4) !== "last",
							a = t === "of-type";
						return i === 1 && r === 0 ? function(e) {
							return !!e.parentNode
						} : function(t, n, u) {
							var l, f, c, p, d, h, g = o !== s ? "nextSibling" : "previousSibling",
								m = t.parentNode,
								y = a && t.nodeName.toLowerCase(),
								v = !u && !a;
							if (m) {
								if (o) {
									while (g) {
										c = t;
										while (c = c[g]) {
											if (a ? c.nodeName.toLowerCase() === y : c.nodeType === 1) {
												return false
											}
										}
										h = g = e === "only" && !h && "nextSibling"
									}
									return true
								}
								h = [s ? m.firstChild : m.lastChild];
								if (s && v) {
									f = m[b] || (m[b] = {});
									l = f[e] || [];
									d = l[0] === T && l[1];
									p = l[0] === T && l[2];
									c = d && m.childNodes[d];
									while (c = ++d && c && c[g] || (p = d = 0) || h.pop()) {
										if (c.nodeType === 1 && ++p && c === t) {
											f[e] = [T, d, p];
											break
										}
									}
								} else if (v && (l = (t[b] || (t[b] = {}))[e]) && l[0] === T) {
									p = l[1]
								} else {
									while (c = ++d && c && c[g] || (p = d = 0) || h.pop()) {
										if ((a ? c.nodeName.toLowerCase() === y : c.nodeType === 1) && ++p) {
											if (v) {
												(c[b] || (c[b] = {}))[e] = [T, p]
											}
											if (c === t) {
												break
											}
										}
									}
								}
								p -= r;
								return p === i || p % i === 0 && p / i >= 0
							}
						}
					},
					PSEUDO: function(e, t) {
						var n, i = o.pseudos[e] || o.setFilters[e.toLowerCase()] || st.error("unsupported pseudo: " + e);
						if (i[b]) {
							return i(t)
						}
						if (i.length > 1) {
							n = [e, e, "", t];
							return o.setFilters.hasOwnProperty(e.toLowerCase()) ? ut(function(e, n) {
								var r, o = i(e, t),
									s = o.length;
								while (s--) {
									r = F.call(e, o[s]);
									e[r] = !(n[r] = o[s])
								}
							}) : function(e) {
								return i(e, 0, n)
							}
						}
						return i
					}
				},
				pseudos: {
					not: ut(function(e) {
						var t = [],
							n = [],
							i = u(e.replace(z, "$1"));
						return i[b] ? ut(function(e, t, n, r) {
							var o, s = i(e, null, r, []),
								a = e.length;
							while (a--) {
								if (o = s[a]) {
									e[a] = !(t[a] = o)
								}
							}
						}) : function(e, r, o) {
							t[0] = e;
							i(t, null, o, n);
							return !n.pop()
						}
					}),
					has: ut(function(e) {
						return function(t) {
							return st(e, t).length > 0
						}
					}),
					contains: ut(function(e) {
						return function(t) {
							return (t.textContent || t.innerText || s(t)).indexOf(e) > -1
						}
					}),
					lang: ut(function(e) {
						if (!G.test(e || "")) {
							st.error("unsupported lang: " + e)
						}
						e = e.replace(it, rt).toLowerCase();
						return function(t) {
							var n;
							do {
								if (n = h ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) {
									n = n.toLowerCase();
									return n === e || n.indexOf(e + "-") === 0
								}
							} while ((t = t.parentNode) && t.nodeType === 1);
							return false
						}
					}),
					target: function(t) {
						var n = e.location && e.location.hash;
						return n && n.slice(1) === t.id
					},
					root: function(e) {
						return e === d
					},
					focus: function(e) {
						return e === p.activeElement && (!p.hasFocus || p.hasFocus()) && !!(e.type || e.href || ~e.tabIndex)
					},
					enabled: function(e) {
						return e.disabled === false
					},
					disabled: function(e) {
						return e.disabled === true
					},
					checked: function(e) {
						var t = e.nodeName.toLowerCase();
						return t === "input" && !!e.checked || t === "option" && !!e.selected
					},
					selected: function(e) {
						if (e.parentNode) {
							e.parentNode.selectedIndex
						}
						return e.selected === true
					},
					empty: function(e) {
						for (e = e.firstChild; e; e = e.nextSibling) {
							if (e.nodeName > "@" || e.nodeType === 3 || e.nodeType === 4) {
								return false
							}
						}
						return true
					},
					parent: function(e) {
						return !o.pseudos["empty"](e)
					},
					header: function(e) {
						return tt.test(e.nodeName)
					},
					input: function(e) {
						return et.test(e.nodeName)
					},
					button: function(e) {
						var t = e.nodeName.toLowerCase();
						return t === "input" && e.type === "button" || t === "button"
					},
					text: function(e) {
						var t;
						return e.nodeName.toLowerCase() === "input" && e.type === "text" && ((t = e.getAttribute("type")) == null || t.toLowerCase() === e.type)
					},
					first: ht(function() {
						return [0]
					}),
					last: ht(function(e, t) {
						return [t - 1]
					}),
					eq: ht(function(e, t, n) {
						return [n < 0 ? n + t : n]
					}),
					even: ht(function(e, t) {
						var n = 0;
						for (; n < t; n += 2) {
							e.push(n)
						}
						return e
					}),
					odd: ht(function(e, t) {
						var n = 1;
						for (; n < t; n += 2) {
							e.push(n)
						}
						return e
					}),
					lt: ht(function(e, t, n) {
						var i = n < 0 ? n + t : n;
						for (; --i >= 0;) {
							e.push(i)
						}
						return e
					}),
					gt: ht(function(e, t, n) {
						var i = n < 0 ? n + t : n;
						for (; ++i < t;) {
							e.push(i)
						}
						return e
					})
				}
			};
			o.pseudos["nth"] = o.pseudos["eq"];
			for (n in {
				radio: true,
				checkbox: true,
				file: true,
				password: true,
				image: true
			}) {
				o.pseudos[n] = pt(n)
			}
			for (n in {
				submit: true,
				reset: true
			}) {
				o.pseudos[n] = dt(n)
			}

			function gt() {}
			gt.prototype = o.filters = o.pseudos;
			o.setFilters = new gt;

			function mt(e, t) {
				var n, i, r, s, a, u, l, f = k[e + " "];
				if (f) {
					return t ? 0 : f.slice(0)
				}
				a = e;
				u = [];
				l = o.preFilter;
				while (a) {
					if (!n || (i = X.exec(a))) {
						if (i) {
							a = a.slice(i[0].length) || a
						}
						u.push(r = [])
					}
					n = false;
					if (i = U.exec(a)) {
						n = i.shift();
						r.push({
							value: n,
							type: i[0].replace(z, " ")
						});
						a = a.slice(n.length)
					}
					for (s in o.filter) {
						if ((i = Q[s].exec(a)) && (!l[s] || (i = l[s](i)))) {
							n = i.shift();
							r.push({
								value: n,
								type: s,
								matches: i
							});
							a = a.slice(n.length)
						}
					}
					if (!n) {
						break
					}
				}
				return t ? a.length : a ? st.error(e) : k(e, u).slice(0)
			}

			function yt(e) {
				var t = 0,
					n = e.length,
					i = "";
				for (; t < n; t++) {
					i += e[t].value
				}
				return i
			}

			function vt(e, t, n) {
				var i = t.dir,
					o = n && i === "parentNode",
					s = C++;
				return t.first ? function(t, n, r) {
					while (t = t[i]) {
						if (t.nodeType === 1 || o) {
							return e(t, n, r)
						}
					}
				} : function(t, n, a) {
					var u, l, f, c = T + " " + s;
					if (a) {
						while (t = t[i]) {
							if (t.nodeType === 1 || o) {
								if (e(t, n, a)) {
									return true
								}
							}
						}
					} else {
						while (t = t[i]) {
							if (t.nodeType === 1 || o) {
								f = t[b] || (t[b] = {});
								if ((l = f[i]) && l[0] === c) {
									if ((u = l[1]) === true || u === r) {
										return u === true
									}
								} else {
									l = f[i] = [c];
									l[1] = e(t, n, a) || r;
									if (l[1] === true) {
										return true
									}
								}
							}
						}
					}
				}
			}

			function bt(e) {
				return e.length > 1 ? function(t, n, i) {
					var r = e.length;
					while (r--) {
						if (!e[r](t, n, i)) {
							return false
						}
					}
					return true
				} : e[0]
			}

			function xt(e, t, n, i, r) {
				var o, s = [],
					a = 0,
					u = e.length,
					l = t != null;
				for (; a < u; a++) {
					if (o = e[a]) {
						if (!n || n(o, i, r)) {
							s.push(o);
							if (l) {
								t.push(a)
							}
						}
					}
				}
				return s
			}

			function wt(e, t, n, i, r, o) {
				if (i && !i[b]) {
					i = wt(i)
				}
				if (r && !r[b]) {
					r = wt(r, o)
				}
				return ut(function(o, s, a, u) {
					var l, f, c, p = [],
						d = [],
						h = s.length,
						g = o || Nt(t || "*", a.nodeType ? [a] : a, []),
						m = e && (o || !t) ? xt(g, p, e, a, u) : g,
						y = n ? r || (o ? e : h || i) ? [] : s : m;
					if (n) {
						n(m, y, a, u)
					}
					if (i) {
						l = xt(y, d);
						i(l, [], a, u);
						f = l.length;
						while (f--) {
							if (c = l[f]) {
								y[d[f]] = !(m[d[f]] = c)
							}
						}
					}
					if (o) {
						if (r || e) {
							if (r) {
								l = [];
								f = y.length;
								while (f--) {
									if (c = y[f]) {
										l.push(m[f] = c)
									}
								}
								r(null, y = [], l, u)
							}
							f = y.length;
							while (f--) {
								if ((c = y[f]) && (l = r ? F.call(o, c) : p[f]) > -1) {
									o[l] = !(s[l] = c)
								}
							}
						}
					} else {
						y = xt(y === s ? y.splice(h, y.length) : y);
						if (r) {
							r(null, s, y, u)
						} else {
							M.apply(s, y)
						}
					}
				})
			}

			function Tt(e) {
				var t, n, i, r = e.length,
					s = o.relative[e[0].type],
					a = s || o.relative[" "],
					u = s ? 1 : 0,
					f = vt(function(e) {
						return e === t
					}, a, true),
					c = vt(function(e) {
						return F.call(t, e) > -1
					}, a, true),
					p = [
						function(e, n, i) {
							return !s && (i || n !== l) || ((t = n).nodeType ? f(e, n, i) : c(e, n, i))
						}
					];
				for (; u < r; u++) {
					if (n = o.relative[e[u].type]) {
						p = [vt(bt(p), n)]
					} else {
						n = o.filter[e[u].type].apply(null, e[u].matches);
						if (n[b]) {
							i = ++u;
							for (; i < r; i++) {
								if (o.relative[e[i].type]) {
									break
								}
							}
							return wt(u > 1 && bt(p), u > 1 && yt(e.slice(0, u - 1).concat({
								value: e[u - 2].type === " " ? "*" : ""
							})).replace(z, "$1"), n, u < i && Tt(e.slice(u, i)), i < r && Tt(e = e.slice(i)), i < r && yt(e))
						}
						p.push(n)
					}
				}
				return bt(p)
			}

			function Ct(e, t) {
				var n = 0,
					i = t.length > 0,
					s = e.length > 0,
					a = function(a, u, f, c, d) {
						var h, g, m, y = [],
							v = 0,
							b = "0",
							x = a && [],
							w = d != null,
							C = l,
							N = a || s && o.find["TAG"]("*", d && u.parentNode || u),
							k = T += C == null ? 1 : Math.random() || .1;
						if (w) {
							l = u !== p && u;
							r = n
						}
						for (;
							(h = N[b]) != null; b++) {
							if (s && h) {
								g = 0;
								while (m = e[g++]) {
									if (m(h, u, f)) {
										c.push(h);
										break
									}
								}
								if (w) {
									T = k;
									r = ++n
								}
							}
							if (i) {
								if (h = !m && h) {
									v--
								}
								if (a) {
									x.push(h)
								}
							}
						}
						v += b;
						if (i && b !== v) {
							g = 0;
							while (m = t[g++]) {
								m(x, y, u, f)
							}
							if (a) {
								if (v > 0) {
									while (b--) {
										if (!(x[b] || y[b])) {
											y[b] = q.call(c)
										}
									}
								}
								y = xt(y)
							}
							M.apply(c, y);
							if (w && !a && y.length > 0 && v + t.length > 1) {
								st.uniqueSort(c)
							}
						}
						if (w) {
							T = k;
							l = C
						}
						return x
					};
				return i ? ut(a) : a
			}
			u = st.compile = function(e, t) {
				var n, i = [],
					r = [],
					o = E[e + " "];
				if (!o) {
					if (!t) {
						t = mt(e)
					}
					n = t.length;
					while (n--) {
						o = Tt(t[n]);
						if (o[b]) {
							i.push(o)
						} else {
							r.push(o)
						}
					}
					o = E(e, Ct(r, i))
				}
				return o
			};

			function Nt(e, t, n) {
				var i = 0,
					r = t.length;
				for (; i < r; i++) {
					st(e, t[i], n)
				}
				return n
			}

			function kt(e, t, n, r) {
				var s, a, l, f, c, p = mt(e);
				if (!r) {
					if (p.length === 1) {
						a = p[0] = p[0].slice(0);
						if (a.length > 2 && (l = a[0]).type === "ID" && i.getById && t.nodeType === 9 && h && o.relative[a[1].type]) {
							t = (o.find["ID"](l.matches[0].replace(it, rt), t) || [])[0];
							if (!t) {
								return n
							}
							e = e.slice(a.shift().value.length)
						}
						s = Q["needsContext"].test(e) ? 0 : a.length;
						while (s--) {
							l = a[s];
							if (o.relative[f = l.type]) {
								break
							}
							if (c = o.find[f]) {
								if (r = c(l.matches[0].replace(it, rt), V.test(a[0].type) && t.parentNode || t)) {
									a.splice(s, 1);
									e = r.length && yt(a);
									if (!e) {
										M.apply(n, r);
										return n
									}
									break
								}
							}
						}
					}
				}
				u(e, p)(r, t, !h, n, V.test(e));
				return n
			}
			i.sortStable = b.split("").sort(A).join("") === b;
			i.detectDuplicates = S;
			c();
			i.sortDetached = lt(function(e) {
				return e.compareDocumentPosition(p.createElement("div")) & 1
			});
			if (!lt(function(e) {
				e.innerHTML = "<a href='#'></a>";
				return e.firstChild.getAttribute("href") === "#"
			})) {
				ft("type|href|height|width", function(e, t, n) {
					if (!n) {
						return e.getAttribute(t, t.toLowerCase() === "type" ? 1 : 2)
					}
				})
			}
			if (!i.attributes || !lt(function(e) {
				e.innerHTML = "<input/>";
				e.firstChild.setAttribute("value", "");
				return e.firstChild.getAttribute("value") === ""
			})) {
				ft("value", function(e, t, n) {
					if (!n && e.nodeName.toLowerCase() === "input") {
						return e.defaultValue
					}
				})
			}
			if (!lt(function(e) {
				return e.getAttribute("disabled") == null
			})) {
				ft(B, function(e, t, n) {
					var i;
					if (!n) {
						return (i = e.getAttributeNode(t)) && i.specified ? i.value : e[t] === true ? t.toLowerCase() : null
					}
				})
			}
			x.find = st;
			x.expr = st.selectors;
			x.expr[":"] = x.expr.pseudos;
			x.unique = st.uniqueSort;
			x.text = st.getText;
			x.isXMLDoc = st.isXML;
			x.contains = st.contains
		})(e);
		var O = {};

		function F(e) {
			var t = O[e] = {};
			x.each(e.match(T) || [], function(e, n) {
				t[n] = true
			});
			return t
		}
		x.Callbacks = function(e) {
			e = typeof e === "string" ? O[e] || F(e) : x.extend({}, e);
			var n, i, r, o, s, a, u = [],
				l = !e.once && [],
				f = function(t) {
					i = e.memory && t;
					r = true;
					s = a || 0;
					a = 0;
					o = u.length;
					n = true;
					for (; u && s < o; s++) {
						if (u[s].apply(t[0], t[1]) === false && e.stopOnFalse) {
							i = false;
							break
						}
					}
					n = false;
					if (u) {
						if (l) {
							if (l.length) {
								f(l.shift())
							}
						} else if (i) {
							u = []
						} else {
							c.disable()
						}
					}
				},
				c = {
					add: function() {
						if (u) {
							var t = u.length;
							(function r(t) {
								x.each(t, function(t, n) {
									var i = x.type(n);
									if (i === "function") {
										if (!e.unique || !c.has(n)) {
											u.push(n)
										}
									} else if (n && n.length && i !== "string") {
										r(n)
									}
								})
							})(arguments);
							if (n) {
								o = u.length
							} else if (i) {
								a = t;
								f(i)
							}
						}
						return this
					},
					remove: function() {
						if (u) {
							x.each(arguments, function(e, t) {
								var i;
								while ((i = x.inArray(t, u, i)) > -1) {
									u.splice(i, 1);
									if (n) {
										if (i <= o) {
											o--
										}
										if (i <= s) {
											s--
										}
									}
								}
							})
						}
						return this
					},
					has: function(e) {
						return e ? x.inArray(e, u) > -1 : !!(u && u.length)
					},
					empty: function() {
						u = [];
						o = 0;
						return this
					},
					disable: function() {
						u = l = i = t;
						return this
					},
					disabled: function() {
						return !u
					},
					lock: function() {
						l = t;
						if (!i) {
							c.disable()
						}
						return this
					},
					locked: function() {
						return !l
					},
					fireWith: function(e, t) {
						if (u && (!r || l)) {
							t = t || [];
							t = [e, t.slice ? t.slice() : t];
							if (n) {
								l.push(t)
							} else {
								f(t)
							}
						}
						return this
					},
					fire: function() {
						c.fireWith(this, arguments);
						return this
					},
					fired: function() {
						return !!r
					}
				};
			return c
		};
		x.extend({
			Deferred: function(e) {
				var t = [
						["resolve", "done", x.Callbacks("once memory"), "resolved"],
						["reject", "fail", x.Callbacks("once memory"), "rejected"],
						["notify", "progress", x.Callbacks("memory")]
					],
					n = "pending",
					i = {
						state: function() {
							return n
						},
						always: function() {
							r.done(arguments).fail(arguments);
							return this
						},
						then: function() {
							var e = arguments;
							return x.Deferred(function(n) {
								x.each(t, function(t, o) {
									var s = o[0],
										a = x.isFunction(e[t]) && e[t];
									r[o[1]](function() {
										var e = a && a.apply(this, arguments);
										if (e && x.isFunction(e.promise)) {
											e.promise().done(n.resolve).fail(n.reject).progress(n.notify)
										} else {
											n[s + "With"](this === i ? n.promise() : this, a ? [e] : arguments)
										}
									})
								});
								e = null
							}).promise()
						},
						promise: function(e) {
							return e != null ? x.extend(e, i) : i
						}
					},
					r = {};
				i.pipe = i.then;
				x.each(t, function(e, o) {
					var s = o[2],
						a = o[3];
					i[o[1]] = s.add;
					if (a) {
						s.add(function() {
							n = a
						}, t[e ^ 1][2].disable, t[2][2].lock)
					}
					r[o[0]] = function() {
						r[o[0] + "With"](this === r ? i : this, arguments);
						return this
					};
					r[o[0] + "With"] = s.fireWith
				});
				i.promise(r);
				if (e) {
					e.call(r, r)
				}
				return r
			},
			when: function(e) {
				var t = 0,
					n = g.call(arguments),
					i = n.length,
					r = i !== 1 || e && x.isFunction(e.promise) ? i : 0,
					o = r === 1 ? e : x.Deferred(),
					s = function(e, t, n) {
						return function(i) {
							t[e] = this;
							n[e] = arguments.length > 1 ? g.call(arguments) : i;
							if (n === a) {
								o.notifyWith(t, n)
							} else if (!--r) {
								o.resolveWith(t, n)
							}
						}
					},
					a, u, l;
				if (i > 1) {
					a = new Array(i);
					u = new Array(i);
					l = new Array(i);
					for (; t < i; t++) {
						if (n[t] && x.isFunction(n[t].promise)) {
							n[t].promise().done(s(t, l, n)).fail(o.reject).progress(s(t, u, a))
						} else {
							--r
						}
					}
				}
				if (!r) {
					o.resolveWith(l, n)
				}
				return o.promise()
			}
		});
		x.support = function(t) {
			var n, i, o, a, u, l, f, c, p, d = s.createElement("div");
			d.setAttribute("className", "t");
			d.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>";
			n = d.getElementsByTagName("*") || [];
			i = d.getElementsByTagName("a")[0];
			if (!i || !i.style || !n.length) {
				return t
			}
			a = s.createElement("select");
			l = a.appendChild(s.createElement("option"));
			o = d.getElementsByTagName("input")[0];
			i.style.cssText = "top:1px;float:left;opacity:.5";
			t.getSetAttribute = d.className !== "t";
			t.leadingWhitespace = d.firstChild.nodeType === 3;
			t.tbody = !d.getElementsByTagName("tbody").length;
			t.htmlSerialize = !!d.getElementsByTagName("link").length;
			t.style = /top/.test(i.getAttribute("style"));
			t.hrefNormalized = i.getAttribute("href") === "/a";
			t.opacity = /^0.5/.test(i.style.opacity);
			t.cssFloat = !!i.style.cssFloat;
			t.checkOn = !!o.value;
			t.optSelected = l.selected;
			t.enctype = !!s.createElement("form").enctype;
			t.html5Clone = s.createElement("nav").cloneNode(true).outerHTML !== "<:nav></:nav>";
			t.inlineBlockNeedsLayout = false;
			t.shrinkWrapBlocks = false;
			t.pixelPosition = false;
			t.deleteExpando = true;
			t.noCloneEvent = true;
			t.reliableMarginRight = true;
			t.boxSizingReliable = true;
			o.checked = true;
			t.noCloneChecked = o.cloneNode(true).checked;
			a.disabled = true;
			t.optDisabled = !l.disabled;
			try {
				delete d.test
			} catch (h) {
				t.deleteExpando = false
			}
			o = s.createElement("input");
			o.setAttribute("value", "");
			t.input = o.getAttribute("value") === "";
			o.value = "t";
			o.setAttribute("type", "radio");
			t.radioValue = o.value === "t";
			o.setAttribute("checked", "t");
			o.setAttribute("name", "t");
			u = s.createDocumentFragment();
			u.appendChild(o);
			t.appendChecked = o.checked;
			t.checkClone = u.cloneNode(true).cloneNode(true).lastChild.checked;
			if (d.attachEvent) {
				d.attachEvent("onclick", function() {
					t.noCloneEvent = false
				});
				d.cloneNode(true).click()
			}
			for (p in {
				submit: true,
				change: true,
				focusin: true
			}) {
				d.setAttribute(f = "on" + p, "t");
				t[p + "Bubbles"] = f in e || d.attributes[f].expando === false
			}
			d.style.backgroundClip = "content-box";
			d.cloneNode(true).style.backgroundClip = "";
			t.clearCloneStyle = d.style.backgroundClip === "content-box";
			for (p in x(t)) {
				break
			}
			t.ownLast = p !== "0";
			x(function() {
				var n, i, o, a = "padding:0;margin:0;border:0;display:block;box-sizing:content-box;-moz-box-sizing:content-box;-webkit-box-sizing:content-box;",
					u = s.getElementsByTagName("body")[0];
				if (!u) {
					return
				}
				n = s.createElement("div");
				n.style.cssText = "border:0;width:0;height:0;position:absolute;top:0;left:-9999px;margin-top:1px";
				u.appendChild(n).appendChild(d);
				d.innerHTML = "<table><tr><td></td><td>t</td></tr></table>";
				o = d.getElementsByTagName("td");
				o[0].style.cssText = "padding:0;margin:0;border:0;display:none";
				c = o[0].offsetHeight === 0;
				o[0].style.display = "";
				o[1].style.display = "none";
				t.reliableHiddenOffsets = c && o[0].offsetHeight === 0;
				d.innerHTML = "";
				d.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;";
				x.swap(u, u.style.zoom != null ? {
					zoom: 1
				} : {}, function() {
					t.boxSizing = d.offsetWidth === 4
				});
				if (e.getComputedStyle) {
					t.pixelPosition = (e.getComputedStyle(d, null) || {}).top !== "1%";
					t.boxSizingReliable = (e.getComputedStyle(d, null) || {
						width: "4px"
					}).width === "4px";
					i = d.appendChild(s.createElement("div"));
					i.style.cssText = d.style.cssText = a;
					i.style.marginRight = i.style.width = "0";
					d.style.width = "1px";
					t.reliableMarginRight = !parseFloat((e.getComputedStyle(i, null) || {}).marginRight)
				}
				if (typeof d.style.zoom !== r) {
					d.innerHTML = "";
					d.style.cssText = a + "width:1px;padding:1px;display:inline;zoom:1";
					t.inlineBlockNeedsLayout = d.offsetWidth === 3;
					d.style.display = "block";
					d.innerHTML = "<div></div>";
					d.firstChild.style.width = "5px";
					t.shrinkWrapBlocks = d.offsetWidth !== 3;
					if (t.inlineBlockNeedsLayout) {
						u.style.zoom = 1
					}
				}
				u.removeChild(n);
				n = d = o = i = null
			});
			n = a = u = l = i = o = null;
			return t
		}({});
		var B = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/,
			P = /([A-Z])/g;

		function R(e, n, i, r) {
			if (!x.acceptData(e)) {
				return
			}
			var o, s, a = x.expando,
				u = e.nodeType,
				l = u ? x.cache : e,
				f = u ? e[a] : e[a] && a;
			if ((!f || !l[f] || !r && !l[f].data) && i === t && typeof n === "string") {
				return
			}
			if (!f) {
				if (u) {
					f = e[a] = c.pop() || x.guid++
				} else {
					f = a
				}
			}
			if (!l[f]) {
				l[f] = u ? {} : {
					toJSON: x.noop
				}
			}
			if (typeof n === "object" || typeof n === "function") {
				if (r) {
					l[f] = x.extend(l[f], n)
				} else {
					l[f].data = x.extend(l[f].data, n)
				}
			}
			s = l[f];
			if (!r) {
				if (!s.data) {
					s.data = {}
				}
				s = s.data
			}
			if (i !== t) {
				s[x.camelCase(n)] = i
			}
			if (typeof n === "string") {
				o = s[n];
				if (o == null) {
					o = s[x.camelCase(n)]
				}
			} else {
				o = s
			}
			return o
		}

		function W(e, t, n) {
			if (!x.acceptData(e)) {
				return
			}
			var i, r, o = e.nodeType,
				s = o ? x.cache : e,
				a = o ? e[x.expando] : x.expando;
			if (!s[a]) {
				return
			}
			if (t) {
				i = n ? s[a] : s[a].data;
				if (i) {
					if (!x.isArray(t)) {
						if (t in i) {
							t = [t]
						} else {
							t = x.camelCase(t);
							if (t in i) {
								t = [t]
							} else {
								t = t.split(" ")
							}
						}
					} else {
						t = t.concat(x.map(t, x.camelCase))
					}
					r = t.length;
					while (r--) {
						delete i[t[r]]
					}
					if (n ? !I(i) : !x.isEmptyObject(i)) {
						return
					}
				}
			}
			if (!n) {
				delete s[a].data;
				if (!I(s[a])) {
					return
				}
			}
			if (o) {
				x.cleanData([e], true)
			} else if (x.support.deleteExpando || s != s.window) {
				delete s[a]
			} else {
				s[a] = null
			}
		}
		x.extend({
			cache: {},
			noData: {
				applet: true,
				embed: true,
				object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
			},
			hasData: function(e) {
				e = e.nodeType ? x.cache[e[x.expando]] : e[x.expando];
				return !!e && !I(e)
			},
			data: function(e, t, n) {
				return R(e, t, n)
			},
			removeData: function(e, t) {
				return W(e, t)
			},
			_data: function(e, t, n) {
				return R(e, t, n, true)
			},
			_removeData: function(e, t) {
				return W(e, t, true)
			},
			acceptData: function(e) {
				if (e.nodeType && e.nodeType !== 1 && e.nodeType !== 9) {
					return false
				}
				var t = e.nodeName && x.noData[e.nodeName.toLowerCase()];
				return !t || t !== true && e.getAttribute("classid") === t
			}
		});
		x.fn.extend({
			data: function(e, n) {
				var i, r, o = null,
					s = 0,
					a = this[0];
				if (e === t) {
					if (this.length) {
						o = x.data(a);
						if (a.nodeType === 1 && !x._data(a, "parsedAttrs")) {
							i = a.attributes;
							for (; s < i.length; s++) {
								r = i[s].name;
								if (r.indexOf("data-") === 0) {
									r = x.camelCase(r.slice(5));
									$(a, r, o[r])
								}
							}
							x._data(a, "parsedAttrs", true)
						}
					}
					return o
				}
				if (typeof e === "object") {
					return this.each(function() {
						x.data(this, e)
					})
				}
				return arguments.length > 1 ? this.each(function() {
					x.data(this, e, n)
				}) : a ? $(a, e, x.data(a, e)) : null
			},
			removeData: function(e) {
				return this.each(function() {
					x.removeData(this, e)
				})
			}
		});

		function $(e, n, i) {
			if (i === t && e.nodeType === 1) {
				var r = "data-" + n.replace(P, "-$1").toLowerCase();
				i = e.getAttribute(r);
				if (typeof i === "string") {
					try {
						i = i === "true" ? true : i === "false" ? false : i === "null" ? null : +i + "" === i ? +i : B.test(i) ? x.parseJSON(i) : i
					} catch (o) {}
					x.data(e, n, i)
				} else {
					i = t
				}
			}
			return i
		}

		function I(e) {
			var t;
			for (t in e) {
				if (t === "data" && x.isEmptyObject(e[t])) {
					continue
				}
				if (t !== "toJSON") {
					return false
				}
			}
			return true
		}
		x.extend({
			queue: function(e, t, n) {
				var i;
				if (e) {
					t = (t || "fx") + "queue";
					i = x._data(e, t);
					if (n) {
						if (!i || x.isArray(n)) {
							i = x._data(e, t, x.makeArray(n))
						} else {
							i.push(n)
						}
					}
					return i || []
				}
			},
			dequeue: function(e, t) {
				t = t || "fx";
				var n = x.queue(e, t),
					i = n.length,
					r = n.shift(),
					o = x._queueHooks(e, t),
					s = function() {
						x.dequeue(e, t)
					};
				if (r === "inprogress") {
					r = n.shift();
					i--
				}
				if (r) {
					if (t === "fx") {
						n.unshift("inprogress")
					}
					delete o.stop;
					r.call(e, s, o)
				}
				if (!i && o) {
					o.empty.fire()
				}
			},
			_queueHooks: function(e, t) {
				var n = t + "queueHooks";
				return x._data(e, n) || x._data(e, n, {
					empty: x.Callbacks("once memory").add(function() {
						x._removeData(e, t + "queue");
						x._removeData(e, n)
					})
				})
			}
		});
		x.fn.extend({
			queue: function(e, n) {
				var i = 2;
				if (typeof e !== "string") {
					n = e;
					e = "fx";
					i--
				}
				if (arguments.length < i) {
					return x.queue(this[0], e)
				}
				return n === t ? this : this.each(function() {
					var t = x.queue(this, e, n);
					x._queueHooks(this, e);
					if (e === "fx" && t[0] !== "inprogress") {
						x.dequeue(this, e)
					}
				})
			},
			dequeue: function(e) {
				return this.each(function() {
					x.dequeue(this, e)
				})
			},
			delay: function(e, t) {
				e = x.fx ? x.fx.speeds[e] || e : e;
				t = t || "fx";
				return this.queue(t, function(t, n) {
					var i = setTimeout(t, e);
					n.stop = function() {
						clearTimeout(i)
					}
				})
			},
			clearQueue: function(e) {
				return this.queue(e || "fx", [])
			},
			promise: function(e, n) {
				var i, r = 1,
					o = x.Deferred(),
					s = this,
					a = this.length,
					u = function() {
						if (!--r) {
							o.resolveWith(s, [s])
						}
					};
				if (typeof e !== "string") {
					n = e;
					e = t
				}
				e = e || "fx";
				while (a--) {
					i = x._data(s[a], e + "queueHooks");
					if (i && i.empty) {
						r++;
						i.empty.add(u)
					}
				}
				u();
				return o.promise(n)
			}
		});
		var z, X, U = /[\t\r\n\f]/g,
			V = /\r/g,
			Y = /^(?:input|select|textarea|button|object)$/i,
			J = /^(?:a|area)$/i,
			G = /^(?:checked|selected)$/i,
			Q = x.support.getSetAttribute,
			K = x.support.input;
		x.fn.extend({
			attr: function(e, t) {
				return x.access(this, x.attr, e, t, arguments.length > 1)
			},
			removeAttr: function(e) {
				return this.each(function() {
					x.removeAttr(this, e)
				})
			},
			prop: function(e, t) {
				return x.access(this, x.prop, e, t, arguments.length > 1)
			},
			removeProp: function(e) {
				e = x.propFix[e] || e;
				return this.each(function() {
					try {
						this[e] = t;
						delete this[e]
					} catch (n) {}
				})
			},
			addClass: function(e) {
				var t, n, i, r, o, s = 0,
					a = this.length,
					u = typeof e === "string" && e;
				if (x.isFunction(e)) {
					return this.each(function(t) {
						x(this).addClass(e.call(this, t, this.className))
					})
				}
				if (u) {
					t = (e || "").match(T) || [];
					for (; s < a; s++) {
						n = this[s];
						i = n.nodeType === 1 && (n.className ? (" " + n.className + " ").replace(U, " ") : " ");
						if (i) {
							o = 0;
							while (r = t[o++]) {
								if (i.indexOf(" " + r + " ") < 0) {
									i += r + " "
								}
							}
							n.className = x.trim(i)
						}
					}
				}
				return this
			},
			removeClass: function(e) {
				var t, n, i, r, o, s = 0,
					a = this.length,
					u = arguments.length === 0 || typeof e === "string" && e;
				if (x.isFunction(e)) {
					return this.each(function(t) {
						x(this).removeClass(e.call(this, t, this.className))
					})
				}
				if (u) {
					t = (e || "").match(T) || [];
					for (; s < a; s++) {
						n = this[s];
						i = n.nodeType === 1 && (n.className ? (" " + n.className + " ").replace(U, " ") : "");
						if (i) {
							o = 0;
							while (r = t[o++]) {
								while (i.indexOf(" " + r + " ") >= 0) {
									i = i.replace(" " + r + " ", " ")
								}
							}
							n.className = e ? x.trim(i) : ""
						}
					}
				}
				return this
			},
			toggleClass: function(e, t) {
				var n = typeof e;
				if (typeof t === "boolean" && n === "string") {
					return t ? this.addClass(e) : this.removeClass(e)
				}
				if (x.isFunction(e)) {
					return this.each(function(n) {
						x(this).toggleClass(e.call(this, n, this.className, t), t)
					})
				}
				return this.each(function() {
					if (n === "string") {
						var t, i = 0,
							o = x(this),
							s = e.match(T) || [];
						while (t = s[i++]) {
							if (o.hasClass(t)) {
								o.removeClass(t)
							} else {
								o.addClass(t)
							}
						}
					} else if (n === r || n === "boolean") {
						if (this.className) {
							x._data(this, "__className__", this.className)
						}
						this.className = this.className || e === false ? "" : x._data(this, "__className__") || ""
					}
				})
			},
			hasClass: function(e) {
				var t = " " + e + " ",
					n = 0,
					i = this.length;
				for (; n < i; n++) {
					if (this[n].nodeType === 1 && (" " + this[n].className + " ").replace(U, " ").indexOf(t) >= 0) {
						return true
					}
				}
				return false
			},
			val: function(e) {
				var n, i, r, o = this[0];
				if (!arguments.length) {
					if (o) {
						i = x.valHooks[o.type] || x.valHooks[o.nodeName.toLowerCase()];
						if (i && "get" in i && (n = i.get(o, "value")) !== t) {
							return n
						}
						n = o.value;
						return typeof n === "string" ? n.replace(V, "") : n == null ? "" : n
					}
					return
				}
				r = x.isFunction(e);
				return this.each(function(n) {
					var o;
					if (this.nodeType !== 1) {
						return
					}
					if (r) {
						o = e.call(this, n, x(this).val())
					} else {
						o = e
					} if (o == null) {
						o = ""
					} else if (typeof o === "number") {
						o += ""
					} else if (x.isArray(o)) {
						o = x.map(o, function(e) {
							return e == null ? "" : e + ""
						})
					}
					i = x.valHooks[this.type] || x.valHooks[this.nodeName.toLowerCase()];
					if (!i || !("set" in i) || i.set(this, o, "value") === t) {
						this.value = o
					}
				})
			}
		});
		x.extend({
			valHooks: {
				option: {
					get: function(e) {
						var t = x.find.attr(e, "value");
						return t != null ? t : e.text
					}
				},
				select: {
					get: function(e) {
						var t, n, i = e.options,
							r = e.selectedIndex,
							o = e.type === "select-one" || r < 0,
							s = o ? null : [],
							a = o ? r + 1 : i.length,
							u = r < 0 ? a : o ? r : 0;
						for (; u < a; u++) {
							n = i[u];
							if ((n.selected || u === r) && (x.support.optDisabled ? !n.disabled : n.getAttribute("disabled") === null) && (!n.parentNode.disabled || !x.nodeName(n.parentNode, "optgroup"))) {
								t = x(n).val();
								if (o) {
									return t
								}
								s.push(t)
							}
						}
						return s
					},
					set: function(e, t) {
						var n, i, r = e.options,
							o = x.makeArray(t),
							s = r.length;
						while (s--) {
							i = r[s];
							if (i.selected = x.inArray(x(i).val(), o) >= 0) {
								n = true
							}
						}
						if (!n) {
							e.selectedIndex = -1
						}
						return o
					}
				}
			},
			attr: function(e, n, i) {
				var o, s, a = e.nodeType;
				if (!e || a === 3 || a === 8 || a === 2) {
					return
				}
				if (typeof e.getAttribute === r) {
					return x.prop(e, n, i)
				}
				if (a !== 1 || !x.isXMLDoc(e)) {
					n = n.toLowerCase();
					o = x.attrHooks[n] || (x.expr.match.bool.test(n) ? X : z)
				}
				if (i !== t) {
					if (i === null) {
						x.removeAttr(e, n)
					} else if (o && "set" in o && (s = o.set(e, i, n)) !== t) {
						return s
					} else {
						e.setAttribute(n, i + "");
						return i
					}
				} else if (o && "get" in o && (s = o.get(e, n)) !== null) {
					return s
				} else {
					s = x.find.attr(e, n);
					return s == null ? t : s
				}
			},
			removeAttr: function(e, t) {
				var n, i, r = 0,
					o = t && t.match(T);
				if (o && e.nodeType === 1) {
					while (n = o[r++]) {
						i = x.propFix[n] || n;
						if (x.expr.match.bool.test(n)) {
							if (K && Q || !G.test(n)) {
								e[i] = false
							} else {
								e[x.camelCase("default-" + n)] = e[i] = false
							}
						} else {
							x.attr(e, n, "")
						}
						e.removeAttribute(Q ? n : i)
					}
				}
			},
			attrHooks: {
				type: {
					set: function(e, t) {
						if (!x.support.radioValue && t === "radio" && x.nodeName(e, "input")) {
							var n = e.value;
							e.setAttribute("type", t);
							if (n) {
								e.value = n
							}
							return t
						}
					}
				}
			},
			propFix: {
				"for": "htmlFor",
				"class": "className"
			},
			prop: function(e, n, i) {
				var r, o, s, a = e.nodeType;
				if (!e || a === 3 || a === 8 || a === 2) {
					return
				}
				s = a !== 1 || !x.isXMLDoc(e);
				if (s) {
					n = x.propFix[n] || n;
					o = x.propHooks[n]
				}
				if (i !== t) {
					return o && "set" in o && (r = o.set(e, i, n)) !== t ? r : e[n] = i
				} else {
					return o && "get" in o && (r = o.get(e, n)) !== null ? r : e[n]
				}
			},
			propHooks: {
				tabIndex: {
					get: function(e) {
						var t = x.find.attr(e, "tabindex");
						return t ? parseInt(t, 10) : Y.test(e.nodeName) || J.test(e.nodeName) && e.href ? 0 : -1
					}
				}
			}
		});
		X = {
			set: function(e, t, n) {
				if (t === false) {
					x.removeAttr(e, n)
				} else if (K && Q || !G.test(n)) {
					e.setAttribute(!Q && x.propFix[n] || n, n)
				} else {
					e[x.camelCase("default-" + n)] = e[n] = true
				}
				return n
			}
		};
		x.each(x.expr.match.bool.source.match(/\w+/g), function(e, n) {
			var i = x.expr.attrHandle[n] || x.find.attr;
			x.expr.attrHandle[n] = K && Q || !G.test(n) ? function(e, n, r) {
				var o = x.expr.attrHandle[n],
					s = r ? t : (x.expr.attrHandle[n] = t) != i(e, n, r) ? n.toLowerCase() : null;
				x.expr.attrHandle[n] = o;
				return s
			} : function(e, n, i) {
				return i ? t : e[x.camelCase("default-" + n)] ? n.toLowerCase() : null
			}
		});
		if (!K || !Q) {
			x.attrHooks.value = {
				set: function(e, t, n) {
					if (x.nodeName(e, "input")) {
						e.defaultValue = t
					} else {
						return z && z.set(e, t, n)
					}
				}
			}
		}
		if (!Q) {
			z = {
				set: function(e, n, i) {
					var r = e.getAttributeNode(i);
					if (!r) {
						e.setAttributeNode(r = e.ownerDocument.createAttribute(i))
					}
					r.value = n += "";
					return i === "value" || n === e.getAttribute(i) ? n : t
				}
			};
			x.expr.attrHandle.id = x.expr.attrHandle.name = x.expr.attrHandle.coords = function(e, n, i) {
				var r;
				return i ? t : (r = e.getAttributeNode(n)) && r.value !== "" ? r.value : null
			};
			x.valHooks.button = {
				get: function(e, n) {
					var i = e.getAttributeNode(n);
					return i && i.specified ? i.value : t
				},
				set: z.set
			};
			x.attrHooks.contenteditable = {
				set: function(e, t, n) {
					z.set(e, t === "" ? false : t, n)
				}
			};
			x.each(["width", "height"], function(e, t) {
				x.attrHooks[t] = {
					set: function(e, n) {
						if (n === "") {
							e.setAttribute(t, "auto");
							return n
						}
					}
				}
			})
		}
		if (!x.support.hrefNormalized) {
			x.each(["href", "src"], function(e, t) {
				x.propHooks[t] = {
					get: function(e) {
						return e.getAttribute(t, 4)
					}
				}
			})
		}
		if (!x.support.style) {
			x.attrHooks.style = {
				get: function(e) {
					return e.style.cssText || t
				},
				set: function(e, t) {
					return e.style.cssText = t + ""
				}
			}
		}
		if (!x.support.optSelected) {
			x.propHooks.selected = {
				get: function(e) {
					var t = e.parentNode;
					if (t) {
						t.selectedIndex;
						if (t.parentNode) {
							t.parentNode.selectedIndex
						}
					}
					return null
				}
			}
		}
		x.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function() {
			x.propFix[this.toLowerCase()] = this
		});
		if (!x.support.enctype) {
			x.propFix.enctype = "encoding"
		}
		x.each(["radio", "checkbox"], function() {
			x.valHooks[this] = {
				set: function(e, t) {
					if (x.isArray(t)) {
						return e.checked = x.inArray(x(e).val(), t) >= 0
					}
				}
			};
			if (!x.support.checkOn) {
				x.valHooks[this].get = function(e) {
					return e.getAttribute("value") === null ? "on" : e.value
				}
			}
		});
		var Z = /^(?:input|select|textarea)$/i,
			et = /^key/,
			tt = /^(?:mouse|contextmenu)|click/,
			nt = /^(?:focusinfocus|focusoutblur)$/,
			it = /^([^.]*)(?:\.(.+)|)$/;

		function rt() {
			return true
		}

		function ot() {
			return false
		}

		function st() {
			try {
				return s.activeElement
			} catch (e) {}
		}
		x.event = {
			global: {},
			add: function(e, n, i, o, s) {
				var a, u, l, f, c, p, d, h, g, m, y, v = x._data(e);
				if (!v) {
					return
				}
				if (i.handler) {
					f = i;
					i = f.handler;
					s = f.selector
				}
				if (!i.guid) {
					i.guid = x.guid++
				}
				if (!(u = v.events)) {
					u = v.events = {}
				}
				if (!(p = v.handle)) {
					p = v.handle = function(e) {
						return typeof x !== r && (!e || x.event.triggered !== e.type) ? x.event.dispatch.apply(p.elem, arguments) : t
					};
					p.elem = e
				}
				n = (n || "").match(T) || [""];
				l = n.length;
				while (l--) {
					a = it.exec(n[l]) || [];
					g = y = a[1];
					m = (a[2] || "").split(".").sort();
					if (!g) {
						continue
					}
					c = x.event.special[g] || {};
					g = (s ? c.delegateType : c.bindType) || g;
					c = x.event.special[g] || {};
					d = x.extend({
						type: g,
						origType: y,
						data: o,
						handler: i,
						guid: i.guid,
						selector: s,
						needsContext: s && x.expr.match.needsContext.test(s),
						namespace: m.join(".")
					}, f);
					if (!(h = u[g])) {
						h = u[g] = [];
						h.delegateCount = 0;
						if (!c.setup || c.setup.call(e, o, m, p) === false) {
							if (e.addEventListener) {
								e.addEventListener(g, p, false)
							} else if (e.attachEvent) {
								e.attachEvent("on" + g, p)
							}
						}
					}
					if (c.add) {
						c.add.call(e, d);
						if (!d.handler.guid) {
							d.handler.guid = i.guid
						}
					}
					if (s) {
						h.splice(h.delegateCount++, 0, d)
					} else {
						h.push(d)
					}
					x.event.global[g] = true
				}
				e = null
			},
			remove: function(e, t, n, i, r) {
				var o, s, a, u, l, f, c, p, d, h, g, m = x.hasData(e) && x._data(e);
				if (!m || !(f = m.events)) {
					return
				}
				t = (t || "").match(T) || [""];
				l = t.length;
				while (l--) {
					a = it.exec(t[l]) || [];
					d = g = a[1];
					h = (a[2] || "").split(".").sort();
					if (!d) {
						for (d in f) {
							x.event.remove(e, d + t[l], n, i, true)
						}
						continue
					}
					c = x.event.special[d] || {};
					d = (i ? c.delegateType : c.bindType) || d;
					p = f[d] || [];
					a = a[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)");
					u = o = p.length;
					while (o--) {
						s = p[o];
						if ((r || g === s.origType) && (!n || n.guid === s.guid) && (!a || a.test(s.namespace)) && (!i || i === s.selector || i === "**" && s.selector)) {
							p.splice(o, 1);
							if (s.selector) {
								p.delegateCount--
							}
							if (c.remove) {
								c.remove.call(e, s)
							}
						}
					}
					if (u && !p.length) {
						if (!c.teardown || c.teardown.call(e, h, m.handle) === false) {
							x.removeEvent(e, d, m.handle)
						}
						delete f[d]
					}
				}
				if (x.isEmptyObject(f)) {
					delete m.handle;
					x._removeData(e, "events")
				}
			},
			trigger: function(n, i, r, o) {
				var a, u, l, f, c, p, d, h = [r || s],
					g = v.call(n, "type") ? n.type : n,
					m = v.call(n, "namespace") ? n.namespace.split(".") : [];
				l = p = r = r || s;
				if (r.nodeType === 3 || r.nodeType === 8) {
					return
				}
				if (nt.test(g + x.event.triggered)) {
					return
				}
				if (g.indexOf(".") >= 0) {
					m = g.split(".");
					g = m.shift();
					m.sort()
				}
				u = g.indexOf(":") < 0 && "on" + g;
				n = n[x.expando] ? n : new x.Event(g, typeof n === "object" && n);
				n.isTrigger = o ? 2 : 3;
				n.namespace = m.join(".");
				n.namespace_re = n.namespace ? new RegExp("(^|\\.)" + m.join("\\.(?:.*\\.|)") + "(\\.|$)") : null;
				n.result = t;
				if (!n.target) {
					n.target = r
				}
				i = i == null ? [n] : x.makeArray(i, [n]);
				c = x.event.special[g] || {};
				if (!o && c.trigger && c.trigger.apply(r, i) === false) {
					return
				}
				if (!o && !c.noBubble && !x.isWindow(r)) {
					f = c.delegateType || g;
					if (!nt.test(f + g)) {
						l = l.parentNode
					}
					for (; l; l = l.parentNode) {
						h.push(l);
						p = l
					}
					if (p === (r.ownerDocument || s)) {
						h.push(p.defaultView || p.parentWindow || e)
					}
				}
				d = 0;
				while ((l = h[d++]) && !n.isPropagationStopped()) {
					n.type = d > 1 ? f : c.bindType || g;
					a = (x._data(l, "events") || {})[n.type] && x._data(l, "handle");
					if (a) {
						a.apply(l, i)
					}
					a = u && l[u];
					if (a && x.acceptData(l) && a.apply && a.apply(l, i) === false) {
						n.preventDefault()
					}
				}
				n.type = g;
				if (!o && !n.isDefaultPrevented()) {
					if ((!c._default || c._default.apply(h.pop(), i) === false) && x.acceptData(r)) {
						if (u && r[g] && !x.isWindow(r)) {
							p = r[u];
							if (p) {
								r[u] = null
							}
							x.event.triggered = g;
							try {
								r[g]()
							} catch (y) {}
							x.event.triggered = t;
							if (p) {
								r[u] = p
							}
						}
					}
				}
				return n.result
			},
			dispatch: function(e) {
				e = x.event.fix(e);
				var n, i, r, o, s, a = [],
					u = g.call(arguments),
					l = (x._data(this, "events") || {})[e.type] || [],
					f = x.event.special[e.type] || {};
				u[0] = e;
				e.delegateTarget = this;
				if (f.preDispatch && f.preDispatch.call(this, e) === false) {
					return
				}
				a = x.event.handlers.call(this, e, l);
				n = 0;
				while ((o = a[n++]) && !e.isPropagationStopped()) {
					e.currentTarget = o.elem;
					s = 0;
					while ((r = o.handlers[s++]) && !e.isImmediatePropagationStopped()) {
						if (!e.namespace_re || e.namespace_re.test(r.namespace)) {
							e.handleObj = r;
							e.data = r.data;
							i = ((x.event.special[r.origType] || {}).handle || r.handler).apply(o.elem, u);
							if (i !== t) {
								if ((e.result = i) === false) {
									e.preventDefault();
									e.stopPropagation()
								}
							}
						}
					}
				}
				if (f.postDispatch) {
					f.postDispatch.call(this, e)
				}
				return e.result
			},
			handlers: function(e, n) {
				var i, r, o, s, a = [],
					u = n.delegateCount,
					l = e.target;
				if (u && l.nodeType && (!e.button || e.type !== "click")) {
					for (; l != this; l = l.parentNode || this) {
						if (l.nodeType === 1 && (l.disabled !== true || e.type !== "click")) {
							o = [];
							for (s = 0; s < u; s++) {
								r = n[s];
								i = r.selector + " ";
								if (o[i] === t) {
									o[i] = r.needsContext ? x(i, this).index(l) >= 0 : x.find(i, this, null, [l]).length
								}
								if (o[i]) {
									o.push(r)
								}
							}
							if (o.length) {
								a.push({
									elem: l,
									handlers: o
								})
							}
						}
					}
				}
				if (u < n.length) {
					a.push({
						elem: this,
						handlers: n.slice(u)
					})
				}
				return a
			},
			fix: function(e) {
				if (e[x.expando]) {
					return e
				}
				var t, n, i, r = e.type,
					o = e,
					a = this.fixHooks[r];
				if (!a) {
					this.fixHooks[r] = a = tt.test(r) ? this.mouseHooks : et.test(r) ? this.keyHooks : {}
				}
				i = a.props ? this.props.concat(a.props) : this.props;
				e = new x.Event(o);
				t = i.length;
				while (t--) {
					n = i[t];
					e[n] = o[n]
				}
				if (!e.target) {
					e.target = o.srcElement || s
				}
				if (e.target.nodeType === 3) {
					e.target = e.target.parentNode
				}
				e.metaKey = !!e.metaKey;
				return a.filter ? a.filter(e, o) : e
			},
			props: "altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
			fixHooks: {},
			keyHooks: {
				props: "char charCode key keyCode".split(" "),
				filter: function(e, t) {
					if (e.which == null) {
						e.which = t.charCode != null ? t.charCode : t.keyCode
					}
					return e
				}
			},
			mouseHooks: {
				props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
				filter: function(e, n) {
					var i, r, o, a = n.button,
						u = n.fromElement;
					if (e.pageX == null && n.clientX != null) {
						r = e.target.ownerDocument || s;
						o = r.documentElement;
						i = r.body;
						e.pageX = n.clientX + (o && o.scrollLeft || i && i.scrollLeft || 0) - (o && o.clientLeft || i && i.clientLeft || 0);
						e.pageY = n.clientY + (o && o.scrollTop || i && i.scrollTop || 0) - (o && o.clientTop || i && i.clientTop || 0)
					}
					if (!e.relatedTarget && u) {
						e.relatedTarget = u === e.target ? n.toElement : u
					}
					if (!e.which && a !== t) {
						e.which = a & 1 ? 1 : a & 2 ? 3 : a & 4 ? 2 : 0
					}
					return e
				}
			},
			special: {
				load: {
					noBubble: true
				},
				focus: {
					trigger: function() {
						if (this !== st() && this.focus) {
							try {
								this.focus();
								return false
							} catch (e) {}
						}
					},
					delegateType: "focusin"
				},
				blur: {
					trigger: function() {
						if (this === st() && this.blur) {
							this.blur();
							return false
						}
					},
					delegateType: "focusout"
				},
				click: {
					trigger: function() {
						if (x.nodeName(this, "input") && this.type === "checkbox" && this.click) {
							this.click();
							return false
						}
					},
					_default: function(e) {
						return x.nodeName(e.target, "a")
					}
				},
				beforeunload: {
					postDispatch: function(e) {
						if (e.result !== t) {
							e.originalEvent.returnValue = e.result
						}
					}
				}
			},
			simulate: function(e, t, n, i) {
				var r = x.extend(new x.Event, n, {
					type: e,
					isSimulated: true,
					originalEvent: {}
				});
				if (i) {
					x.event.trigger(r, null, t)
				} else {
					x.event.dispatch.call(t, r)
				} if (r.isDefaultPrevented()) {
					n.preventDefault()
				}
			}
		};
		x.removeEvent = s.removeEventListener ? function(e, t, n) {
			if (e.removeEventListener) {
				e.removeEventListener(t, n, false)
			}
		} : function(e, t, n) {
			var i = "on" + t;
			if (e.detachEvent) {
				if (typeof e[i] === r) {
					e[i] = null
				}
				e.detachEvent(i, n)
			}
		};
		x.Event = function(e, t) {
			if (!(this instanceof x.Event)) {
				return new x.Event(e, t)
			}
			if (e && e.type) {
				this.originalEvent = e;
				this.type = e.type;
				this.isDefaultPrevented = e.defaultPrevented || e.returnValue === false || e.getPreventDefault && e.getPreventDefault() ? rt : ot
			} else {
				this.type = e
			} if (t) {
				x.extend(this, t)
			}
			this.timeStamp = e && e.timeStamp || x.now();
			this[x.expando] = true
		};
		x.Event.prototype = {
			isDefaultPrevented: ot,
			isPropagationStopped: ot,
			isImmediatePropagationStopped: ot,
			preventDefault: function() {
				var e = this.originalEvent;
				this.isDefaultPrevented = rt;
				if (!e) {
					return
				}
				if (e.preventDefault) {
					e.preventDefault()
				} else {
					e.returnValue = false
				}
			},
			stopPropagation: function() {
				var e = this.originalEvent;
				this.isPropagationStopped = rt;
				if (!e) {
					return
				}
				if (e.stopPropagation) {
					e.stopPropagation()
				}
				e.cancelBubble = true
			},
			stopImmediatePropagation: function() {
				this.isImmediatePropagationStopped = rt;
				this.stopPropagation()
			}
		};
		x.each({
			mouseenter: "mouseover",
			mouseleave: "mouseout"
		}, function(e, t) {
			x.event.special[e] = {
				delegateType: t,
				bindType: t,
				handle: function(e) {
					var n, i = this,
						r = e.relatedTarget,
						o = e.handleObj;
					if (!r || r !== i && !x.contains(i, r)) {
						e.type = o.origType;
						n = o.handler.apply(this, arguments);
						e.type = t
					}
					return n
				}
			}
		});
		if (!x.support.submitBubbles) {
			x.event.special.submit = {
				setup: function() {
					if (x.nodeName(this, "form")) {
						return false
					}
					x.event.add(this, "click._submit keypress._submit", function(e) {
						var n = e.target,
							i = x.nodeName(n, "input") || x.nodeName(n, "button") ? n.form : t;
						if (i && !x._data(i, "submitBubbles")) {
							x.event.add(i, "submit._submit", function(e) {
								e._submit_bubble = true
							});
							x._data(i, "submitBubbles", true)
						}
					})
				},
				postDispatch: function(e) {
					if (e._submit_bubble) {
						delete e._submit_bubble;
						if (this.parentNode && !e.isTrigger) {
							x.event.simulate("submit", this.parentNode, e, true)
						}
					}
				},
				teardown: function() {
					if (x.nodeName(this, "form")) {
						return false
					}
					x.event.remove(this, "._submit")
				}
			}
		}
		if (!x.support.changeBubbles) {
			x.event.special.change = {
				setup: function() {
					if (Z.test(this.nodeName)) {
						if (this.type === "checkbox" || this.type === "radio") {
							x.event.add(this, "propertychange._change", function(e) {
								if (e.originalEvent.propertyName === "checked") {
									this._just_changed = true
								}
							});
							x.event.add(this, "click._change", function(e) {
								if (this._just_changed && !e.isTrigger) {
									this._just_changed = false
								}
								x.event.simulate("change", this, e, true)
							})
						}
						return false
					}
					x.event.add(this, "beforeactivate._change", function(e) {
						var t = e.target;
						if (Z.test(t.nodeName) && !x._data(t, "changeBubbles")) {
							x.event.add(t, "change._change", function(e) {
								if (this.parentNode && !e.isSimulated && !e.isTrigger) {
									x.event.simulate("change", this.parentNode, e, true)
								}
							});
							x._data(t, "changeBubbles", true)
						}
					})
				},
				handle: function(e) {
					var t = e.target;
					if (this !== t || e.isSimulated || e.isTrigger || t.type !== "radio" && t.type !== "checkbox") {
						return e.handleObj.handler.apply(this, arguments)
					}
				},
				teardown: function() {
					x.event.remove(this, "._change");
					return !Z.test(this.nodeName)
				}
			}
		}
		if (!x.support.focusinBubbles) {
			x.each({
				focus: "focusin",
				blur: "focusout"
			}, function(e, t) {
				var n = 0,
					i = function(e) {
						x.event.simulate(t, e.target, x.event.fix(e), true)
					};
				x.event.special[t] = {
					setup: function() {
						if (n++ === 0) {
							s.addEventListener(e, i, true)
						}
					},
					teardown: function() {
						if (--n === 0) {
							s.removeEventListener(e, i, true)
						}
					}
				}
			})
		}
		x.fn.extend({
			on: function(e, n, i, r, o) {
				var s, a;
				if (typeof e === "object") {
					if (typeof n !== "string") {
						i = i || n;
						n = t
					}
					for (s in e) {
						this.on(s, n, i, e[s], o)
					}
					return this
				}
				if (i == null && r == null) {
					r = n;
					i = n = t
				} else if (r == null) {
					if (typeof n === "string") {
						r = i;
						i = t
					} else {
						r = i;
						i = n;
						n = t
					}
				}
				if (r === false) {
					r = ot
				} else if (!r) {
					return this
				}
				if (o === 1) {
					a = r;
					r = function(e) {
						x().off(e);
						return a.apply(this, arguments)
					};
					r.guid = a.guid || (a.guid = x.guid++)
				}
				return this.each(function() {
					x.event.add(this, e, r, i, n)
				})
			},
			one: function(e, t, n, i) {
				return this.on(e, t, n, i, 1)
			},
			off: function(e, n, i) {
				var r, o;
				if (e && e.preventDefault && e.handleObj) {
					r = e.handleObj;
					x(e.delegateTarget).off(r.namespace ? r.origType + "." + r.namespace : r.origType, r.selector, r.handler);
					return this
				}
				if (typeof e === "object") {
					for (o in e) {
						this.off(o, n, e[o])
					}
					return this
				}
				if (n === false || typeof n === "function") {
					i = n;
					n = t
				}
				if (i === false) {
					i = ot
				}
				return this.each(function() {
					x.event.remove(this, e, i, n)
				})
			},
			trigger: function(e, t) {
				return this.each(function() {
					x.event.trigger(e, t, this)
				})
			},
			triggerHandler: function(e, t) {
				var n = this[0];
				if (n) {
					return x.event.trigger(e, t, n, true)
				}
			}
		});
		var at = /^.[^:#\[\.,]*$/,
			ut = /^(?:parents|prev(?:Until|All))/,
			lt = x.expr.match.needsContext,
			ft = {
				children: true,
				contents: true,
				next: true,
				prev: true
			};
		x.fn.extend({
			find: function(e) {
				var t, n = [],
					i = this,
					r = i.length;
				if (typeof e !== "string") {
					return this.pushStack(x(e).filter(function() {
						for (t = 0; t < r; t++) {
							if (x.contains(i[t], this)) {
								return true
							}
						}
					}))
				}
				for (t = 0; t < r; t++) {
					x.find(e, i[t], n)
				}
				n = this.pushStack(r > 1 ? x.unique(n) : n);
				n.selector = this.selector ? this.selector + " " + e : e;
				return n
			},
			has: function(e) {
				var t, n = x(e, this),
					i = n.length;
				return this.filter(function() {
					for (t = 0; t < i; t++) {
						if (x.contains(this, n[t])) {
							return true
						}
					}
				})
			},
			not: function(e) {
				return this.pushStack(pt(this, e || [], true))
			},
			filter: function(e) {
				return this.pushStack(pt(this, e || [], false))
			},
			is: function(e) {
				return !!pt(this, typeof e === "string" && lt.test(e) ? x(e) : e || [], false).length
			},
			closest: function(e, t) {
				var n, i = 0,
					r = this.length,
					o = [],
					s = lt.test(e) || typeof e !== "string" ? x(e, t || this.context) : 0;
				for (; i < r; i++) {
					for (n = this[i]; n && n !== t; n = n.parentNode) {
						if (n.nodeType < 11 && (s ? s.index(n) > -1 : n.nodeType === 1 && x.find.matchesSelector(n, e))) {
							n = o.push(n);
							break
						}
					}
				}
				return this.pushStack(o.length > 1 ? x.unique(o) : o)
			},
			index: function(e) {
				if (!e) {
					return this[0] && this[0].parentNode ? this.first().prevAll().length : -1
				}
				if (typeof e === "string") {
					return x.inArray(this[0], x(e))
				}
				return x.inArray(e.jquery ? e[0] : e, this)
			},
			add: function(e, t) {
				var n = typeof e === "string" ? x(e, t) : x.makeArray(e && e.nodeType ? [e] : e),
					i = x.merge(this.get(), n);
				return this.pushStack(x.unique(i))
			},
			addBack: function(e) {
				return this.add(e == null ? this.prevObject : this.prevObject.filter(e))
			}
		});

		function ct(e, t) {
			do {
				e = e[t]
			} while (e && e.nodeType !== 1);
			return e
		}
		x.each({
			parent: function(e) {
				var t = e.parentNode;
				return t && t.nodeType !== 11 ? t : null
			},
			parents: function(e) {
				return x.dir(e, "parentNode")
			},
			parentsUntil: function(e, t, n) {
				return x.dir(e, "parentNode", n)
			},
			next: function(e) {
				return ct(e, "nextSibling")
			},
			prev: function(e) {
				return ct(e, "previousSibling")
			},
			nextAll: function(e) {
				return x.dir(e, "nextSibling")
			},
			prevAll: function(e) {
				return x.dir(e, "previousSibling")
			},
			nextUntil: function(e, t, n) {
				return x.dir(e, "nextSibling", n)
			},
			prevUntil: function(e, t, n) {
				return x.dir(e, "previousSibling", n)
			},
			siblings: function(e) {
				return x.sibling((e.parentNode || {}).firstChild, e)
			},
			children: function(e) {
				return x.sibling(e.firstChild)
			},
			contents: function(e) {
				return x.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : x.merge([], e.childNodes)
			}
		}, function(e, t) {
			x.fn[e] = function(n, i) {
				var r = x.map(this, t, n);
				if (e.slice(-5) !== "Until") {
					i = n
				}
				if (i && typeof i === "string") {
					r = x.filter(i, r)
				}
				if (this.length > 1) {
					if (!ft[e]) {
						r = x.unique(r)
					}
					if (ut.test(e)) {
						r = r.reverse()
					}
				}
				return this.pushStack(r)
			}
		});
		x.extend({
			filter: function(e, t, n) {
				var i = t[0];
				if (n) {
					e = ":not(" + e + ")"
				}
				return t.length === 1 && i.nodeType === 1 ? x.find.matchesSelector(i, e) ? [i] : [] : x.find.matches(e, x.grep(t, function(e) {
					return e.nodeType === 1
				}))
			},
			dir: function(e, n, i) {
				var r = [],
					o = e[n];
				while (o && o.nodeType !== 9 && (i === t || o.nodeType !== 1 || !x(o).is(i))) {
					if (o.nodeType === 1) {
						r.push(o)
					}
					o = o[n]
				}
				return r
			},
			sibling: function(e, t) {
				var n = [];
				for (; e; e = e.nextSibling) {
					if (e.nodeType === 1 && e !== t) {
						n.push(e)
					}
				}
				return n
			}
		});

		function pt(e, t, n) {
			if (x.isFunction(t)) {
				return x.grep(e, function(e, i) {
					return !!t.call(e, i, e) !== n
				})
			}
			if (t.nodeType) {
				return x.grep(e, function(e) {
					return e === t !== n
				})
			}
			if (typeof t === "string") {
				if (at.test(t)) {
					return x.filter(t, e, n)
				}
				t = x.filter(t, e)
			}
			return x.grep(e, function(e) {
				return x.inArray(e, t) >= 0 !== n
			})
		}

		function dt(e) {
			var t = ht.split("|"),
				n = e.createDocumentFragment();
			if (n.createElement) {
				while (t.length) {
					n.createElement(t.pop())
				}
			}
			return n
		}
		var ht = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|" + "header|hgroup|mark|meter|nav|output|progress|section|summary|time|video",
			gt = / jQuery\d+="(?:null|\d+)"/g,
			mt = new RegExp("<(?:" + ht + ")[\\s/>]", "i"),
			yt = /^\s+/,
			vt = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi,
			bt = /<([\w:]+)/,
			xt = /<tbody/i,
			wt = /<|&#?\w+;/,
			Tt = /<(?:script|style|link)/i,
			Ct = /^(?:checkbox|radio)$/i,
			Nt = /checked\s*(?:[^=]|=\s*.checked.)/i,
			kt = /^$|\/(?:java|ecma)script/i,
			Et = /^true\/(.*)/,
			St = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
			At = {
				option: [1, "<select multiple='multiple'>", "</select>"],
				legend: [1, "<fieldset>", "</fieldset>"],
				area: [1, "<map>", "</map>"],
				param: [1, "<object>", "</object>"],
				thead: [1, "<table>", "</table>"],
				tr: [2, "<table><tbody>", "</tbody></table>"],
				col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
				td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
				_default: x.support.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
			},
			jt = dt(s),
			Dt = jt.appendChild(s.createElement("div"));
		At.optgroup = At.option;
		At.tbody = At.tfoot = At.colgroup = At.caption = At.thead;
		At.th = At.td;
		x.fn.extend({
			text: function(e) {
				return x.access(this, function(e) {
					return e === t ? x.text(this) : this.empty().append((this[0] && this[0].ownerDocument || s).createTextNode(e))
				}, null, e, arguments.length)
			},
			append: function() {
				return this.domManip(arguments, function(e) {
					if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
						var t = Lt(this, e);
						t.appendChild(e)
					}
				})
			},
			prepend: function() {
				return this.domManip(arguments, function(e) {
					if (this.nodeType === 1 || this.nodeType === 11 || this.nodeType === 9) {
						var t = Lt(this, e);
						t.insertBefore(e, t.firstChild)
					}
				})
			},
			before: function() {
				return this.domManip(arguments, function(e) {
					if (this.parentNode) {
						this.parentNode.insertBefore(e, this)
					}
				})
			},
			after: function() {
				return this.domManip(arguments, function(e) {
					if (this.parentNode) {
						this.parentNode.insertBefore(e, this.nextSibling)
					}
				})
			},
			remove: function(e, t) {
				var n, i = e ? x.filter(e, this) : this,
					r = 0;
				for (;
					(n = i[r]) != null; r++) {
					if (!t && n.nodeType === 1) {
						x.cleanData(Ft(n))
					}
					if (n.parentNode) {
						if (t && x.contains(n.ownerDocument, n)) {
							_t(Ft(n, "script"))
						}
						n.parentNode.removeChild(n)
					}
				}
				return this
			},
			empty: function() {
				var e, t = 0;
				for (;
					(e = this[t]) != null; t++) {
					if (e.nodeType === 1) {
						x.cleanData(Ft(e, false))
					}
					while (e.firstChild) {
						e.removeChild(e.firstChild)
					}
					if (e.options && x.nodeName(e, "select")) {
						e.options.length = 0
					}
				}
				return this
			},
			clone: function(e, t) {
				e = e == null ? false : e;
				t = t == null ? e : t;
				return this.map(function() {
					return x.clone(this, e, t)
				})
			},
			html: function(e) {
				return x.access(this, function(e) {
					var n = this[0] || {},
						i = 0,
						r = this.length;
					if (e === t) {
						return n.nodeType === 1 ? n.innerHTML.replace(gt, "") : t
					}
					if (typeof e === "string" && !Tt.test(e) && (x.support.htmlSerialize || !mt.test(e)) && (x.support.leadingWhitespace || !yt.test(e)) && !At[(bt.exec(e) || ["", ""])[1].toLowerCase()]) {
						e = e.replace(vt, "<$1></$2>");
						try {
							for (; i < r; i++) {
								n = this[i] || {};
								if (n.nodeType === 1) {
									x.cleanData(Ft(n, false));
									n.innerHTML = e
								}
							}
							n = 0
						} catch (o) {}
					}
					if (n) {
						this.empty().append(e)
					}
				}, null, e, arguments.length)
			},
			replaceWith: function() {
				var e = x.map(this, function(e) {
						return [e.nextSibling, e.parentNode]
					}),
					t = 0;
				this.domManip(arguments, function(n) {
					var i = e[t++],
						r = e[t++];
					if (r) {
						if (i && i.parentNode !== r) {
							i = this.nextSibling
						}
						x(this).remove();
						r.insertBefore(n, i)
					}
				}, true);
				return t ? this : this.remove()
			},
			detach: function(e) {
				return this.remove(e, true)
			},
			domManip: function(e, t, n) {
				e = d.apply([], e);
				var i, r, o, s, a, u, l = 0,
					f = this.length,
					c = this,
					p = f - 1,
					h = e[0],
					g = x.isFunction(h);
				if (g || !(f <= 1 || typeof h !== "string" || x.support.checkClone || !Nt.test(h))) {
					return this.each(function(i) {
						var r = c.eq(i);
						if (g) {
							e[0] = h.call(this, i, r.html())
						}
						r.domManip(e, t, n)
					})
				}
				if (f) {
					u = x.buildFragment(e, this[0].ownerDocument, false, !n && this);
					i = u.firstChild;
					if (u.childNodes.length === 1) {
						u = i
					}
					if (i) {
						s = x.map(Ft(u, "script"), Ht);
						o = s.length;
						for (; l < f; l++) {
							r = u;
							if (l !== p) {
								r = x.clone(r, true, true);
								if (o) {
									x.merge(s, Ft(r, "script"))
								}
							}
							t.call(this[l], r, l)
						}
						if (o) {
							a = s[s.length - 1].ownerDocument;
							x.map(s, qt);
							for (l = 0; l < o; l++) {
								r = s[l];
								if (kt.test(r.type || "") && !x._data(r, "globalEval") && x.contains(a, r)) {
									if (r.src) {
										x._evalUrl(r.src)
									} else {
										x.globalEval((r.text || r.textContent || r.innerHTML || "").replace(St, ""))
									}
								}
							}
						}
						u = i = null
					}
				}
				return this
			}
		});

		function Lt(e, t) {
			return x.nodeName(e, "table") && x.nodeName(t.nodeType === 1 ? t : t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
		}

		function Ht(e) {
			e.type = (x.find.attr(e, "type") !== null) + "/" + e.type;
			return e
		}

		function qt(e) {
			var t = Et.exec(e.type);
			if (t) {
				e.type = t[1]
			} else {
				e.removeAttribute("type")
			}
			return e
		}

		function _t(e, t) {
			var n, i = 0;
			for (;
				(n = e[i]) != null; i++) {
				x._data(n, "globalEval", !t || x._data(t[i], "globalEval"))
			}
		}

		function Mt(e, t) {
			if (t.nodeType !== 1 || !x.hasData(e)) {
				return
			}
			var n, i, r, o = x._data(e),
				s = x._data(t, o),
				a = o.events;
			if (a) {
				delete s.handle;
				s.events = {};
				for (n in a) {
					for (i = 0, r = a[n].length; i < r; i++) {
						x.event.add(t, n, a[n][i])
					}
				}
			}
			if (s.data) {
				s.data = x.extend({}, s.data)
			}
		}

		function Ot(e, t) {
			var n, i, r;
			if (t.nodeType !== 1) {
				return
			}
			n = t.nodeName.toLowerCase();
			if (!x.support.noCloneEvent && t[x.expando]) {
				r = x._data(t);
				for (i in r.events) {
					x.removeEvent(t, i, r.handle)
				}
				t.removeAttribute(x.expando)
			}
			if (n === "script" && t.text !== e.text) {
				Ht(t).text = e.text;
				qt(t)
			} else if (n === "object") {
				if (t.parentNode) {
					t.outerHTML = e.outerHTML
				}
				if (x.support.html5Clone && (e.innerHTML && !x.trim(t.innerHTML))) {
					t.innerHTML = e.innerHTML
				}
			} else if (n === "input" && Ct.test(e.type)) {
				t.defaultChecked = t.checked = e.checked;
				if (t.value !== e.value) {
					t.value = e.value
				}
			} else if (n === "option") {
				t.defaultSelected = t.selected = e.defaultSelected
			} else if (n === "input" || n === "textarea") {
				t.defaultValue = e.defaultValue
			}
		}
		x.each({
			appendTo: "append",
			prependTo: "prepend",
			insertBefore: "before",
			insertAfter: "after",
			replaceAll: "replaceWith"
		}, function(e, t) {
			x.fn[e] = function(e) {
				var n, i = 0,
					r = [],
					o = x(e),
					s = o.length - 1;
				for (; i <= s; i++) {
					n = i === s ? this : this.clone(true);
					x(o[i])[t](n);
					h.apply(r, n.get())
				}
				return this.pushStack(r)
			}
		});

		function Ft(e, n) {
			var i, o, s = 0,
				a = typeof e.getElementsByTagName !== r ? e.getElementsByTagName(n || "*") : typeof e.querySelectorAll !== r ? e.querySelectorAll(n || "*") : t;
			if (!a) {
				for (a = [], i = e.childNodes || e;
					(o = i[s]) != null; s++) {
					if (!n || x.nodeName(o, n)) {
						a.push(o)
					} else {
						x.merge(a, Ft(o, n))
					}
				}
			}
			return n === t || n && x.nodeName(e, n) ? x.merge([e], a) : a
		}

		function Bt(e) {
			if (Ct.test(e.type)) {
				e.defaultChecked = e.checked
			}
		}
		x.extend({
			clone: function(e, t, n) {
				var i, r, o, s, a, u = x.contains(e.ownerDocument, e);
				if (x.support.html5Clone || x.isXMLDoc(e) || !mt.test("<" + e.nodeName + ">")) {
					o = e.cloneNode(true)
				} else {
					Dt.innerHTML = e.outerHTML;
					Dt.removeChild(o = Dt.firstChild)
				} if ((!x.support.noCloneEvent || !x.support.noCloneChecked) && (e.nodeType === 1 || e.nodeType === 11) && !x.isXMLDoc(e)) {
					i = Ft(o);
					a = Ft(e);
					for (s = 0;
						(r = a[s]) != null; ++s) {
						if (i[s]) {
							Ot(r, i[s])
						}
					}
				}
				if (t) {
					if (n) {
						a = a || Ft(e);
						i = i || Ft(o);
						for (s = 0;
							(r = a[s]) != null; s++) {
							Mt(r, i[s])
						}
					} else {
						Mt(e, o)
					}
				}
				i = Ft(o, "script");
				if (i.length > 0) {
					_t(i, !u && Ft(e, "script"))
				}
				i = a = r = null;
				return o
			},
			buildFragment: function(e, t, n, i) {
				var r, o, s, a, u, l, f, c = e.length,
					p = dt(t),
					d = [],
					h = 0;
				for (; h < c; h++) {
					o = e[h];
					if (o || o === 0) {
						if (x.type(o) === "object") {
							x.merge(d, o.nodeType ? [o] : o)
						} else if (!wt.test(o)) {
							d.push(t.createTextNode(o))
						} else {
							a = a || p.appendChild(t.createElement("div"));
							u = (bt.exec(o) || ["", ""])[1].toLowerCase();
							f = At[u] || At._default;
							a.innerHTML = f[1] + o.replace(vt, "<$1></$2>") + f[2];
							r = f[0];
							while (r--) {
								a = a.lastChild
							}
							if (!x.support.leadingWhitespace && yt.test(o)) {
								d.push(t.createTextNode(yt.exec(o)[0]))
							}
							if (!x.support.tbody) {
								o = u === "table" && !xt.test(o) ? a.firstChild : f[1] === "<table>" && !xt.test(o) ? a : 0;
								r = o && o.childNodes.length;
								while (r--) {
									if (x.nodeName(l = o.childNodes[r], "tbody") && !l.childNodes.length) {
										o.removeChild(l)
									}
								}
							}
							x.merge(d, a.childNodes);
							a.textContent = "";
							while (a.firstChild) {
								a.removeChild(a.firstChild)
							}
							a = p.lastChild
						}
					}
				}
				if (a) {
					p.removeChild(a)
				}
				if (!x.support.appendChecked) {
					x.grep(Ft(d, "input"), Bt)
				}
				h = 0;
				while (o = d[h++]) {
					if (i && x.inArray(o, i) !== -1) {
						continue
					}
					s = x.contains(o.ownerDocument, o);
					a = Ft(p.appendChild(o), "script");
					if (s) {
						_t(a)
					}
					if (n) {
						r = 0;
						while (o = a[r++]) {
							if (kt.test(o.type || "")) {
								n.push(o)
							}
						}
					}
				}
				a = null;
				return p
			},
			cleanData: function(e, t) {
				var n, i, o, s, a = 0,
					u = x.expando,
					l = x.cache,
					f = x.support.deleteExpando,
					p = x.event.special;
				for (;
					(n = e[a]) != null; a++) {
					if (t || x.acceptData(n)) {
						o = n[u];
						s = o && l[o];
						if (s) {
							if (s.events) {
								for (i in s.events) {
									if (p[i]) {
										x.event.remove(n, i)
									} else {
										x.removeEvent(n, i, s.handle)
									}
								}
							}
							if (l[o]) {
								delete l[o];
								if (f) {
									delete n[u]
								} else if (typeof n.removeAttribute !== r) {
									n.removeAttribute(u)
								} else {
									n[u] = null
								}
								c.push(o)
							}
						}
					}
				}
			},
			_evalUrl: function(e) {
				return x.ajax({
					url: e,
					type: "GET",
					dataType: "script",
					async: false,
					global: false,
					"throws": true
				})
			}
		});
		x.fn.extend({
			wrapAll: function(e) {
				if (x.isFunction(e)) {
					return this.each(function(t) {
						x(this).wrapAll(e.call(this, t))
					})
				}
				if (this[0]) {
					var t = x(e, this[0].ownerDocument).eq(0).clone(true);
					if (this[0].parentNode) {
						t.insertBefore(this[0])
					}
					t.map(function() {
						var e = this;
						while (e.firstChild && e.firstChild.nodeType === 1) {
							e = e.firstChild
						}
						return e
					}).append(this)
				}
				return this
			},
			wrapInner: function(e) {
				if (x.isFunction(e)) {
					return this.each(function(t) {
						x(this).wrapInner(e.call(this, t))
					})
				}
				return this.each(function() {
					var t = x(this),
						n = t.contents();
					if (n.length) {
						n.wrapAll(e)
					} else {
						t.append(e)
					}
				})
			},
			wrap: function(e) {
				var t = x.isFunction(e);
				return this.each(function(n) {
					x(this).wrapAll(t ? e.call(this, n) : e)
				})
			},
			unwrap: function() {
				return this.parent().each(function() {
					if (!x.nodeName(this, "body")) {
						x(this).replaceWith(this.childNodes)
					}
				}).end()
			}
		});
		var Pt, Rt, Wt, $t = /alpha\([^)]*\)/i,
			It = /opacity\s*=\s*([^)]*)/,
			zt = /^(top|right|bottom|left)$/,
			Xt = /^(none|table(?!-c[ea]).+)/,
			Ut = /^margin/,
			Vt = new RegExp("^(" + w + ")(.*)$", "i"),
			Yt = new RegExp("^(" + w + ")(?!px)[a-z%]+$", "i"),
			Jt = new RegExp("^([+-])=(" + w + ")", "i"),
			Gt = {
				BODY: "block"
			},
			Qt = {
				position: "absolute",
				visibility: "hidden",
				display: "block"
			},
			Kt = {
				letterSpacing: 0,
				fontWeight: 400
			},
			Zt = ["Top", "Right", "Bottom", "Left"],
			en = ["Webkit", "O", "Moz", "ms"];

		function tn(e, t) {
			if (t in e) {
				return t
			}
			var n = t.charAt(0).toUpperCase() + t.slice(1),
				i = t,
				r = en.length;
			while (r--) {
				t = en[r] + n;
				if (t in e) {
					return t
				}
			}
			return i
		}

		function nn(e, t) {
			e = t || e;
			return x.css(e, "display") === "none" || !x.contains(e.ownerDocument, e)
		}

		function rn(e, t) {
			var n, i, r, o = [],
				s = 0,
				a = e.length;
			for (; s < a; s++) {
				i = e[s];
				if (!i.style) {
					continue
				}
				o[s] = x._data(i, "olddisplay");
				n = i.style.display;
				if (t) {
					if (!o[s] && n === "none") {
						i.style.display = ""
					}
					if (i.style.display === "" && nn(i)) {
						o[s] = x._data(i, "olddisplay", un(i.nodeName))
					}
				} else {
					if (!o[s]) {
						r = nn(i);
						if (n && n !== "none" || !r) {
							x._data(i, "olddisplay", r ? n : x.css(i, "display"))
						}
					}
				}
			}
			for (s = 0; s < a; s++) {
				i = e[s];
				if (!i.style) {
					continue
				}
				if (!t || i.style.display === "none" || i.style.display === "") {
					i.style.display = t ? o[s] || "" : "none"
				}
			}
			return e
		}
		x.fn.extend({
			css: function(e, n) {
				return x.access(this, function(e, n, i) {
					var r, o, s = {},
						a = 0;
					if (x.isArray(n)) {
						o = Rt(e);
						r = n.length;
						for (; a < r; a++) {
							s[n[a]] = x.css(e, n[a], false, o)
						}
						return s
					}
					return i !== t ? x.style(e, n, i) : x.css(e, n)
				}, e, n, arguments.length > 1)
			},
			show: function() {
				return rn(this, true)
			},
			hide: function() {
				return rn(this)
			},
			toggle: function(e) {
				if (typeof e === "boolean") {
					return e ? this.show() : this.hide()
				}
				return this.each(function() {
					if (nn(this)) {
						x(this).show()
					} else {
						x(this).hide()
					}
				})
			}
		});
		x.extend({
			cssHooks: {
				opacity: {
					get: function(e, t) {
						if (t) {
							var n = Wt(e, "opacity");
							return n === "" ? "1" : n
						}
					}
				}
			},
			cssNumber: {
				columnCount: true,
				fillOpacity: true,
				fontWeight: true,
				lineHeight: true,
				opacity: true,
				order: true,
				orphans: true,
				widows: true,
				zIndex: true,
				zoom: true
			},
			cssProps: {
				"float": x.support.cssFloat ? "cssFloat" : "styleFloat"
			},
			style: function(e, n, i, r) {
				if (!e || e.nodeType === 3 || e.nodeType === 8 || !e.style) {
					return
				}
				var o, s, a, u = x.camelCase(n),
					l = e.style;
				n = x.cssProps[u] || (x.cssProps[u] = tn(l, u));
				a = x.cssHooks[n] || x.cssHooks[u];
				if (i !== t) {
					s = typeof i;
					if (s === "string" && (o = Jt.exec(i))) {
						i = (o[1] + 1) * o[2] + parseFloat(x.css(e, n));
						s = "number"
					}
					if (i == null || s === "number" && isNaN(i)) {
						return
					}
					if (s === "number" && !x.cssNumber[u]) {
						i += "px"
					}
					if (!x.support.clearCloneStyle && i === "" && n.indexOf("background") === 0) {
						l[n] = "inherit"
					}
					if (!a || !("set" in a) || (i = a.set(e, i, r)) !== t) {
						try {
							l[n] = i
						} catch (f) {}
					}
				} else {
					if (a && "get" in a && (o = a.get(e, false, r)) !== t) {
						return o
					}
					return l[n]
				}
			},
			css: function(e, n, i, r) {
				var o, s, a, u = x.camelCase(n);
				n = x.cssProps[u] || (x.cssProps[u] = tn(e.style, u));
				a = x.cssHooks[n] || x.cssHooks[u];
				if (a && "get" in a) {
					s = a.get(e, true, i)
				}
				if (s === t) {
					s = Wt(e, n, r)
				}
				if (s === "normal" && n in Kt) {
					s = Kt[n]
				}
				if (i === "" || i) {
					o = parseFloat(s);
					return i === true || x.isNumeric(o) ? o || 0 : s
				}
				return s
			}
		});
		if (e.getComputedStyle) {
			Rt = function(t) {
				return e.getComputedStyle(t, null)
			};
			Wt = function(e, n, i) {
				var r, o, s, a = i || Rt(e),
					u = a ? a.getPropertyValue(n) || a[n] : t,
					l = e.style;
				if (a) {
					if (u === "" && !x.contains(e.ownerDocument, e)) {
						u = x.style(e, n)
					}
					if (Yt.test(u) && Ut.test(n)) {
						r = l.width;
						o = l.minWidth;
						s = l.maxWidth;
						l.minWidth = l.maxWidth = l.width = u;
						u = a.width;
						l.width = r;
						l.minWidth = o;
						l.maxWidth = s
					}
				}
				return u
			}
		} else if (s.documentElement.currentStyle) {
			Rt = function(e) {
				return e.currentStyle
			};
			Wt = function(e, n, i) {
				var r, o, s, a = i || Rt(e),
					u = a ? a[n] : t,
					l = e.style;
				if (u == null && l && l[n]) {
					u = l[n]
				}
				if (Yt.test(u) && !zt.test(n)) {
					r = l.left;
					o = e.runtimeStyle;
					s = o && o.left;
					if (s) {
						o.left = e.currentStyle.left
					}
					l.left = n === "fontSize" ? "1em" : u;
					u = l.pixelLeft + "px";
					l.left = r;
					if (s) {
						o.left = s
					}
				}
				return u === "" ? "auto" : u
			}
		}

		function on(e, t, n) {
			var i = Vt.exec(t);
			return i ? Math.max(0, i[1] - (n || 0)) + (i[2] || "px") : t
		}

		function sn(e, t, n, i, r) {
			var o = n === (i ? "border" : "content") ? 4 : t === "width" ? 1 : 0,
				s = 0;
			for (; o < 4; o += 2) {
				if (n === "margin") {
					s += x.css(e, n + Zt[o], true, r)
				}
				if (i) {
					if (n === "content") {
						s -= x.css(e, "padding" + Zt[o], true, r)
					}
					if (n !== "margin") {
						s -= x.css(e, "border" + Zt[o] + "Width", true, r)
					}
				} else {
					s += x.css(e, "padding" + Zt[o], true, r);
					if (n !== "padding") {
						s += x.css(e, "border" + Zt[o] + "Width", true, r)
					}
				}
			}
			return s
		}

		function an(e, t, n) {
			var i = true,
				r = t === "width" ? e.offsetWidth : e.offsetHeight,
				o = Rt(e),
				s = x.support.boxSizing && x.css(e, "boxSizing", false, o) === "border-box";
			if (r <= 0 || r == null) {
				r = Wt(e, t, o);
				if (r < 0 || r == null) {
					r = e.style[t]
				}
				if (Yt.test(r)) {
					return r
				}
				i = s && (x.support.boxSizingReliable || r === e.style[t]);
				r = parseFloat(r) || 0
			}
			return r + sn(e, t, n || (s ? "border" : "content"), i, o) + "px"
		}

		function un(e) {
			var t = s,
				n = Gt[e];
			if (!n) {
				n = ln(e, t);
				if (n === "none" || !n) {
					Pt = (Pt || x("<iframe frameborder='0' width='0' height='0'/>").css("cssText", "display:block !important")).appendTo(t.documentElement);
					t = (Pt[0].contentWindow || Pt[0].contentDocument).document;
					t.write("<!doctype html><html><body>");
					t.close();
					n = ln(e, t);
					Pt.detach()
				}
				Gt[e] = n
			}
			return n
		}

		function ln(e, t) {
			var n = x(t.createElement(e)).appendTo(t.body),
				i = x.css(n[0], "display");
			n.remove();
			return i
		}
		x.each(["height", "width"], function(e, t) {
			x.cssHooks[t] = {
				get: function(e, n, i) {
					if (n) {
						return e.offsetWidth === 0 && Xt.test(x.css(e, "display")) ? x.swap(e, Qt, function() {
							return an(e, t, i)
						}) : an(e, t, i)
					}
				},
				set: function(e, n, i) {
					var r = i && Rt(e);
					return on(e, n, i ? sn(e, t, i, x.support.boxSizing && x.css(e, "boxSizing", false, r) === "border-box", r) : 0)
				}
			}
		});
		if (!x.support.opacity) {
			x.cssHooks.opacity = {
				get: function(e, t) {
					return It.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
				},
				set: function(e, t) {
					var n = e.style,
						i = e.currentStyle,
						r = x.isNumeric(t) ? "alpha(opacity=" + t * 100 + ")" : "",
						o = i && i.filter || n.filter || "";
					n.zoom = 1;
					if ((t >= 1 || t === "") && x.trim(o.replace($t, "")) === "" && n.removeAttribute) {
						n.removeAttribute("filter");
						if (t === "" || i && !i.filter) {
							return
						}
					}
					n.filter = $t.test(o) ? o.replace($t, r) : o + " " + r
				}
			}
		}
		x(function() {
			if (!x.support.reliableMarginRight) {
				x.cssHooks.marginRight = {
					get: function(e, t) {
						if (t) {
							return x.swap(e, {
								display: "inline-block"
							}, Wt, [e, "marginRight"])
						}
					}
				}
			}
			if (!x.support.pixelPosition && x.fn.position) {
				x.each(["top", "left"], function(e, t) {
					x.cssHooks[t] = {
						get: function(e, n) {
							if (n) {
								n = Wt(e, t);
								return Yt.test(n) ? x(e).position()[t] + "px" : n
							}
						}
					}
				})
			}
		});
		if (x.expr && x.expr.filters) {
			x.expr.filters.hidden = function(e) {
				return e.offsetWidth <= 0 && e.offsetHeight <= 0 || !x.support.reliableHiddenOffsets && (e.style && e.style.display || x.css(e, "display")) === "none"
			};
			x.expr.filters.visible = function(e) {
				return !x.expr.filters.hidden(e)
			}
		}
		x.each({
			margin: "",
			padding: "",
			border: "Width"
		}, function(e, t) {
			x.cssHooks[e + t] = {
				expand: function(n) {
					var i = 0,
						r = {},
						o = typeof n === "string" ? n.split(" ") : [n];
					for (; i < 4; i++) {
						r[e + Zt[i] + t] = o[i] || o[i - 2] || o[0]
					}
					return r
				}
			};
			if (!Ut.test(e)) {
				x.cssHooks[e + t].set = on
			}
		});
		var fn = /%20/g,
			cn = /\[\]$/,
			pn = /\r?\n/g,
			dn = /^(?:submit|button|image|reset|file)$/i,
			hn = /^(?:input|select|textarea|keygen)/i;
		x.fn.extend({
			serialize: function() {
				return x.param(this.serializeArray())
			},
			serializeArray: function() {
				return this.map(function() {
					var e = x.prop(this, "elements");
					return e ? x.makeArray(e) : this
				}).filter(function() {
					var e = this.type;
					return this.name && !x(this).is(":disabled") && hn.test(this.nodeName) && !dn.test(e) && (this.checked || !Ct.test(e))
				}).map(function(e, t) {
					var n = x(this).val();
					return n == null ? null : x.isArray(n) ? x.map(n, function(e) {
						return {
							name: t.name,
							value: e.replace(pn, "\r\n")
						}
					}) : {
						name: t.name,
						value: n.replace(pn, "\r\n")
					}
				}).get()
			}
		});
		x.param = function(e, n) {
			var i, r = [],
				o = function(e, t) {
					t = x.isFunction(t) ? t() : t == null ? "" : t;
					r[r.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
				};
			if (n === t) {
				n = x.ajaxSettings && x.ajaxSettings.traditional
			}
			if (x.isArray(e) || e.jquery && !x.isPlainObject(e)) {
				x.each(e, function() {
					o(this.name, this.value)
				})
			} else {
				for (i in e) {
					gn(i, e[i], n, o)
				}
			}
			return r.join("&").replace(fn, "+")
		};

		function gn(e, t, n, i) {
			var r;
			if (x.isArray(t)) {
				x.each(t, function(t, r) {
					if (n || cn.test(e)) {
						i(e, r)
					} else {
						gn(e + "[" + (typeof r === "object" ? t : "") + "]", r, n, i)
					}
				})
			} else if (!n && x.type(t) === "object") {
				for (r in t) {
					gn(e + "[" + r + "]", t[r], n, i)
				}
			} else {
				i(e, t)
			}
		}
		x.each(("blur focus focusin focusout load resize scroll unload click dblclick " + "mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave " + "change select submit keydown keypress keyup error contextmenu").split(" "), function(e, t) {
			x.fn[t] = function(e, n) {
				return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
			}
		});
		x.fn.extend({
			hover: function(e, t) {
				return this.mouseenter(e).mouseleave(t || e)
			},
			bind: function(e, t, n) {
				return this.on(e, null, t, n)
			},
			unbind: function(e, t) {
				return this.off(e, null, t)
			},
			delegate: function(e, t, n, i) {
				return this.on(t, e, n, i)
			},
			undelegate: function(e, t, n) {
				return arguments.length === 1 ? this.off(e, "**") : this.off(t, e || "**", n)
			}
		});
		var mn, yn, vn = x.now(),
			bn = /\?/,
			xn = /#.*$/,
			wn = /([?&])_=[^&]*/,
			Tn = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
			Cn = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
			Nn = /^(?:GET|HEAD)$/,
			kn = /^\/\//,
			En = /^([\w.+-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/,
			Sn = x.fn.load,
			An = {},
			jn = {},
			Dn = "*/".concat("*");
		try {
			yn = o.href
		} catch (Ln) {
			yn = s.createElement("a");
			yn.href = "";
			yn = yn.href
		}
		mn = En.exec(yn.toLowerCase()) || [];

		function Hn(e) {
			return function(t, n) {
				if (typeof t !== "string") {
					n = t;
					t = "*"
				}
				var i, r = 0,
					o = t.toLowerCase().match(T) || [];
				if (x.isFunction(n)) {
					while (i = o[r++]) {
						if (i[0] === "+") {
							i = i.slice(1) || "*";
							(e[i] = e[i] || []).unshift(n)
						} else {
							(e[i] = e[i] || []).push(n)
						}
					}
				}
			}
		}

		function qn(e, t, n, i) {
			var r = {},
				o = e === jn;

			function s(a) {
				var u;
				r[a] = true;
				x.each(e[a] || [], function(e, a) {
					var l = a(t, n, i);
					if (typeof l === "string" && !o && !r[l]) {
						t.dataTypes.unshift(l);
						s(l);
						return false
					} else if (o) {
						return !(u = l)
					}
				});
				return u
			}
			return s(t.dataTypes[0]) || !r["*"] && s("*")
		}

		function _n(e, n) {
			var i, r, o = x.ajaxSettings.flatOptions || {};
			for (r in n) {
				if (n[r] !== t) {
					(o[r] ? e : i || (i = {}))[r] = n[r]
				}
			}
			if (i) {
				x.extend(true, e, i)
			}
			return e
		}
		x.fn.load = function(e, n, i) {
			if (typeof e !== "string" && Sn) {
				return Sn.apply(this, arguments)
			}
			var r, o, s, a = this,
				u = e.indexOf(" ");
			if (u >= 0) {
				r = e.slice(u, e.length);
				e = e.slice(0, u)
			}
			if (x.isFunction(n)) {
				i = n;
				n = t
			} else if (n && typeof n === "object") {
				s = "POST"
			}
			if (a.length > 0) {
				x.ajax({
					url: e,
					type: s,
					dataType: "html",
					data: n
				}).done(function(e) {
					o = arguments;
					a.html(r ? x("<div>").append(x.parseHTML(e)).find(r) : e)
				}).complete(i && function(e, t) {
					a.each(i, o || [e.responseText, t, e])
				})
			}
			return this
		};
		x.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function(e, t) {
			x.fn[t] = function(e) {
				return this.on(t, e)
			}
		});
		x.extend({
			active: 0,
			lastModified: {},
			etag: {},
			ajaxSettings: {
				url: yn,
				type: "GET",
				isLocal: Cn.test(mn[1]),
				global: true,
				processData: true,
				async: true,
				contentType: "application/x-www-form-urlencoded; charset=UTF-8",
				accepts: {
					"*": Dn,
					text: "text/plain",
					html: "text/html",
					xml: "application/xml, text/xml",
					json: "application/json, text/javascript"
				},
				contents: {
					xml: /xml/,
					html: /html/,
					json: /json/
				},
				responseFields: {
					xml: "responseXML",
					text: "responseText",
					json: "responseJSON"
				},
				converters: {
					"* text": String,
					"text html": true,
					"text json": x.parseJSON,
					"text xml": x.parseXML
				},
				flatOptions: {
					url: true,
					context: true
				}
			},
			ajaxSetup: function(e, t) {
				return t ? _n(_n(e, x.ajaxSettings), t) : _n(x.ajaxSettings, e)
			},
			ajaxPrefilter: Hn(An),
			ajaxTransport: Hn(jn),
			ajax: function(e, n) {
				if (typeof e === "object") {
					n = e;
					e = t
				}
				n = n || {};
				var i, r, o, s, a, u, l, f, c = x.ajaxSetup({}, n),
					p = c.context || c,
					d = c.context && (p.nodeType || p.jquery) ? x(p) : x.event,
					h = x.Deferred(),
					g = x.Callbacks("once memory"),
					m = c.statusCode || {},
					y = {},
					v = {},
					b = 0,
					w = "canceled",
					C = {
						readyState: 0,
						getResponseHeader: function(e) {
							var t;
							if (b === 2) {
								if (!f) {
									f = {};
									while (t = Tn.exec(s)) {
										f[t[1].toLowerCase()] = t[2]
									}
								}
								t = f[e.toLowerCase()]
							}
							return t == null ? null : t
						},
						getAllResponseHeaders: function() {
							return b === 2 ? s : null
						},
						setRequestHeader: function(e, t) {
							var n = e.toLowerCase();
							if (!b) {
								e = v[n] = v[n] || e;
								y[e] = t
							}
							return this
						},
						overrideMimeType: function(e) {
							if (!b) {
								c.mimeType = e
							}
							return this
						},
						statusCode: function(e) {
							var t;
							if (e) {
								if (b < 2) {
									for (t in e) {
										m[t] = [m[t], e[t]]
									}
								} else {
									C.always(e[C.status])
								}
							}
							return this
						},
						abort: function(e) {
							var t = e || w;
							if (l) {
								l.abort(t)
							}
							k(0, t);
							return this
						}
					};
				h.promise(C).complete = g.add;
				C.success = C.done;
				C.error = C.fail;
				c.url = ((e || c.url || yn) + "").replace(xn, "").replace(kn, mn[1] + "//");
				c.type = n.method || n.type || c.method || c.type;
				c.dataTypes = x.trim(c.dataType || "*").toLowerCase().match(T) || [""];
				if (c.crossDomain == null) {
					i = En.exec(c.url.toLowerCase());
					c.crossDomain = !!(i && (i[1] !== mn[1] || i[2] !== mn[2] || (i[3] || (i[1] === "http:" ? "80" : "443")) !== (mn[3] || (mn[1] === "http:" ? "80" : "443"))))
				}
				if (c.data && c.processData && typeof c.data !== "string") {
					c.data = x.param(c.data, c.traditional)
				}
				qn(An, c, n, C);
				if (b === 2) {
					return C
				}
				u = c.global;
				if (u && x.active++ === 0) {
					x.event.trigger("ajaxStart")
				}
				c.type = c.type.toUpperCase();
				c.hasContent = !Nn.test(c.type);
				o = c.url;
				if (!c.hasContent) {
					if (c.data) {
						o = c.url += (bn.test(o) ? "&" : "?") + c.data;
						delete c.data
					}
					if (c.cache === false) {
						c.url = wn.test(o) ? o.replace(wn, "$1_=" + vn++) : o + (bn.test(o) ? "&" : "?") + "_=" + vn++
					}
				}
				if (c.ifModified) {
					if (x.lastModified[o]) {
						C.setRequestHeader("If-Modified-Since", x.lastModified[o])
					}
					if (x.etag[o]) {
						C.setRequestHeader("If-None-Match", x.etag[o])
					}
				}
				if (c.data && c.hasContent && c.contentType !== false || n.contentType) {
					C.setRequestHeader("Content-Type", c.contentType)
				}
				C.setRequestHeader("Accept", c.dataTypes[0] && c.accepts[c.dataTypes[0]] ? c.accepts[c.dataTypes[0]] + (c.dataTypes[0] !== "*" ? ", " + Dn + "; q=0.01" : "") : c.accepts["*"]);
				for (r in c.headers) {
					C.setRequestHeader(r, c.headers[r])
				}
				if (c.beforeSend && (c.beforeSend.call(p, C, c) === false || b === 2)) {
					return C.abort()
				}
				w = "abort";
				for (r in {
					success: 1,
					error: 1,
					complete: 1
				}) {
					C[r](c[r])
				}
				l = qn(jn, c, n, C);
				if (!l) {
					k(-1, "No Transport")
				} else {
					C.readyState = 1;
					if (u) {
						d.trigger("ajaxSend", [C, c])
					}
					if (c.async && c.timeout > 0) {
						a = setTimeout(function() {
							C.abort("timeout")
						}, c.timeout)
					}
					try {
						b = 1;
						l.send(y, k)
					} catch (N) {
						if (b < 2) {
							k(-1, N)
						} else {
							throw N
						}
					}
				}

				function k(e, n, i, r) {
					var f, y, v, w, T, N = n;
					if (b === 2) {
						return
					}
					b = 2;
					if (a) {
						clearTimeout(a)
					}
					l = t;
					s = r || "";
					C.readyState = e > 0 ? 4 : 0;
					f = e >= 200 && e < 300 || e === 304;
					if (i) {
						w = Mn(c, C, i)
					}
					w = On(c, w, C, f);
					if (f) {
						if (c.ifModified) {
							T = C.getResponseHeader("Last-Modified");
							if (T) {
								x.lastModified[o] = T
							}
							T = C.getResponseHeader("etag");
							if (T) {
								x.etag[o] = T
							}
						}
						if (e === 204 || c.type === "HEAD") {
							N = "nocontent"
						} else if (e === 304) {
							N = "notmodified"
						} else {
							N = w.state;
							y = w.data;
							v = w.error;
							f = !v
						}
					} else {
						v = N;
						if (e || !N) {
							N = "error";
							if (e < 0) {
								e = 0
							}
						}
					}
					C.status = e;
					C.statusText = (n || N) + "";
					if (f) {
						h.resolveWith(p, [y, N, C])
					} else {
						h.rejectWith(p, [C, N, v])
					}
					C.statusCode(m);
					m = t;
					if (u) {
						d.trigger(f ? "ajaxSuccess" : "ajaxError", [C, c, f ? y : v])
					}
					g.fireWith(p, [C, N]);
					if (u) {
						d.trigger("ajaxComplete", [C, c]);
						if (!--x.active) {
							x.event.trigger("ajaxStop")
						}
					}
				}
				return C
			},
			getJSON: function(e, t, n) {
				return x.get(e, t, n, "json")
			},
			getScript: function(e, n) {
				return x.get(e, t, n, "script")
			}
		});
		x.each(["get", "post"], function(e, n) {
			x[n] = function(e, i, r, o) {
				if (x.isFunction(i)) {
					o = o || r;
					r = i;
					i = t
				}
				return x.ajax({
					url: e,
					type: n,
					dataType: o,
					data: i,
					success: r
				})
			}
		});

		function Mn(e, n, i) {
			var r, o, s, a, u = e.contents,
				l = e.dataTypes;
			while (l[0] === "*") {
				l.shift();
				if (o === t) {
					o = e.mimeType || n.getResponseHeader("Content-Type")
				}
			}
			if (o) {
				for (a in u) {
					if (u[a] && u[a].test(o)) {
						l.unshift(a);
						break
					}
				}
			}
			if (l[0] in i) {
				s = l[0]
			} else {
				for (a in i) {
					if (!l[0] || e.converters[a + " " + l[0]]) {
						s = a;
						break
					}
					if (!r) {
						r = a
					}
				}
				s = s || r
			} if (s) {
				if (s !== l[0]) {
					l.unshift(s)
				}
				return i[s]
			}
		}

		function On(e, t, n, i) {
			var r, o, s, a, u, l = {},
				f = e.dataTypes.slice();
			if (f[1]) {
				for (s in e.converters) {
					l[s.toLowerCase()] = e.converters[s]
				}
			}
			o = f.shift();
			while (o) {
				if (e.responseFields[o]) {
					n[e.responseFields[o]] = t
				}
				if (!u && i && e.dataFilter) {
					t = e.dataFilter(t, e.dataType)
				}
				u = o;
				o = f.shift();
				if (o) {
					if (o === "*") {
						o = u
					} else if (u !== "*" && u !== o) {
						s = l[u + " " + o] || l["* " + o];
						if (!s) {
							for (r in l) {
								a = r.split(" ");
								if (a[1] === o) {
									s = l[u + " " + a[0]] || l["* " + a[0]];
									if (s) {
										if (s === true) {
											s = l[r]
										} else if (l[r] !== true) {
											o = a[0];
											f.unshift(a[1])
										}
										break
									}
								}
							}
						}
						if (s !== true) {
							if (s && e["throws"]) {
								t = s(t)
							} else {
								try {
									t = s(t)
								} catch (c) {
									return {
										state: "parsererror",
										error: s ? c : "No conversion from " + u + " to " + o
									}
								}
							}
						}
					}
				}
			}
			return {
				state: "success",
				data: t
			}
		}
		x.ajaxSetup({
			accepts: {
				script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
			},
			contents: {
				script: /(?:java|ecma)script/
			},
			converters: {
				"text script": function(e) {
					x.globalEval(e);
					return e
				}
			}
		});
		x.ajaxPrefilter("script", function(e) {
			if (e.cache === t) {
				e.cache = false
			}
			if (e.crossDomain) {
				e.type = "GET";
				e.global = false
			}
		});
		x.ajaxTransport("script", function(e) {
			if (e.crossDomain) {
				var n, i = s.head || x("head")[0] || s.documentElement;
				return {
					send: function(t, r) {
						n = s.createElement("script");
						n.async = true;
						if (e.scriptCharset) {
							n.charset = e.scriptCharset
						}
						n.src = e.url;
						n.onload = n.onreadystatechange = function(e, t) {
							if (t || !n.readyState || /loaded|complete/.test(n.readyState)) {
								n.onload = n.onreadystatechange = null;
								if (n.parentNode) {
									n.parentNode.removeChild(n)
								}
								n = null;
								if (!t) {
									r(200, "success")
								}
							}
						};
						i.insertBefore(n, i.firstChild)
					},
					abort: function() {
						if (n) {
							n.onload(t, true)
						}
					}
				}
			}
		});
		var Fn = [],
			Bn = /(=)\?(?=&|$)|\?\?/;
		x.ajaxSetup({
			jsonp: "callback",
			jsonpCallback: function() {
				var e = Fn.pop() || x.expando + "_" + vn++;
				this[e] = true;
				return e
			}
		});
		x.ajaxPrefilter("json jsonp", function(n, i, r) {
			var o, s, a, u = n.jsonp !== false && (Bn.test(n.url) ? "url" : typeof n.data === "string" && !(n.contentType || "").indexOf("application/x-www-form-urlencoded") && Bn.test(n.data) && "data");
			if (u || n.dataTypes[0] === "jsonp") {
				o = n.jsonpCallback = x.isFunction(n.jsonpCallback) ? n.jsonpCallback() : n.jsonpCallback;
				if (u) {
					n[u] = n[u].replace(Bn, "$1" + o)
				} else if (n.jsonp !== false) {
					n.url += (bn.test(n.url) ? "&" : "?") + n.jsonp + "=" + o
				}
				n.converters["script json"] = function() {
					if (!a) {
						x.error(o + " was not called")
					}
					return a[0]
				};
				n.dataTypes[0] = "json";
				s = e[o];
				e[o] = function() {
					a = arguments
				};
				r.always(function() {
					e[o] = s;
					if (n[o]) {
						n.jsonpCallback = i.jsonpCallback;
						Fn.push(o)
					}
					if (a && x.isFunction(s)) {
						s(a[0])
					}
					a = s = t
				});
				return "script"
			}
		});
		var Pn, Rn, Wn = 0,
			$n = e.ActiveXObject && function() {
				var e;
				for (e in Pn) {
					Pn[e](t, true)
				}
			};

		function In() {
			try {
				return new e.XMLHttpRequest
			} catch (t) {}
		}

		function zn() {
			try {
				return new e.ActiveXObject("Microsoft.XMLHTTP")
			} catch (t) {}
		}
		x.ajaxSettings.xhr = e.ActiveXObject ? function() {
			return !this.isLocal && In() || zn()
		} : In;
		Rn = x.ajaxSettings.xhr();
		x.support.cors = !!Rn && "withCredentials" in Rn;
		Rn = x.support.ajax = !!Rn;
		if (Rn) {
			x.ajaxTransport(function(n) {
				if (!n.crossDomain || x.support.cors) {
					var i;
					return {
						send: function(r, o) {
							var s, a, u = n.xhr();
							if (n.username) {
								u.open(n.type, n.url, n.async, n.username, n.password)
							} else {
								u.open(n.type, n.url, n.async)
							} if (n.xhrFields) {
								for (a in n.xhrFields) {
									u[a] = n.xhrFields[a]
								}
							}
							if (n.mimeType && u.overrideMimeType) {
								u.overrideMimeType(n.mimeType)
							}
							if (!n.crossDomain && !r["X-Requested-With"]) {
								r["X-Requested-With"] = "XMLHttpRequest"
							}
							try {
								for (a in r) {
									u.setRequestHeader(a, r[a])
								}
							} catch (l) {}
							u.send(n.hasContent && n.data || null);
							i = function(e, r) {
								var a, l, f, c;
								try {
									if (i && (r || u.readyState === 4)) {
										i = t;
										if (s) {
											u.onreadystatechange = x.noop;
											if ($n) {
												delete Pn[s]
											}
										}
										if (r) {
											if (u.readyState !== 4) {
												u.abort()
											}
										} else {
											c = {};
											a = u.status;
											l = u.getAllResponseHeaders();
											if (typeof u.responseText === "string") {
												c.text = u.responseText
											}
											try {
												f = u.statusText
											} catch (p) {
												f = ""
											}
											if (!a && n.isLocal && !n.crossDomain) {
												a = c.text ? 200 : 404
											} else if (a === 1223) {
												a = 204
											}
										}
									}
								} catch (d) {
									if (!r) {
										o(-1, d)
									}
								}
								if (c) {
									o(a, f, c, l)
								}
							};
							if (!n.async) {
								i()
							} else if (u.readyState === 4) {
								setTimeout(i)
							} else {
								s = ++Wn;
								if ($n) {
									if (!Pn) {
										Pn = {};
										x(e).unload($n)
									}
									Pn[s] = i
								}
								u.onreadystatechange = i
							}
						},
						abort: function() {
							if (i) {
								i(t, true)
							}
						}
					}
				}
			})
		}
		var Xn, Un, Vn = /^(?:toggle|show|hide)$/,
			Yn = new RegExp("^(?:([+-])=|)(" + w + ")([a-z%]*)$", "i"),
			Jn = /queueHooks$/,
			Gn = [ni],
			Qn = {
				"*": [
					function(e, t) {
						var n = this.createTween(e, t),
							i = n.cur(),
							r = Yn.exec(t),
							o = r && r[3] || (x.cssNumber[e] ? "" : "px"),
							s = (x.cssNumber[e] || o !== "px" && +i) && Yn.exec(x.css(n.elem, e)),
							a = 1,
							u = 20;
						if (s && s[3] !== o) {
							o = o || s[3];
							r = r || [];
							s = +i || 1;
							do {
								a = a || ".5";
								s = s / a;
								x.style(n.elem, e, s + o)
							} while (a !== (a = n.cur() / i) && a !== 1 && --u)
						}
						if (r) {
							s = n.start = +s || +i || 0;
							n.unit = o;
							n.end = r[1] ? s + (r[1] + 1) * r[2] : +r[2]
						}
						return n
					}
				]
			};

		function Kn() {
			setTimeout(function() {
				Xn = t
			});
			return Xn = x.now()
		}

		function Zn(e, t, n) {
			var i, r = (Qn[t] || []).concat(Qn["*"]),
				o = 0,
				s = r.length;
			for (; o < s; o++) {
				if (i = r[o].call(n, t, e)) {
					return i
				}
			}
		}

		function ei(e, t, n) {
			var i, r, o = 0,
				s = Gn.length,
				a = x.Deferred().always(function() {
					delete u.elem
				}),
				u = function() {
					if (r) {
						return false
					}
					var t = Xn || Kn(),
						n = Math.max(0, l.startTime + l.duration - t),
						i = n / l.duration || 0,
						o = 1 - i,
						s = 0,
						u = l.tweens.length;
					for (; s < u; s++) {
						l.tweens[s].run(o)
					}
					a.notifyWith(e, [l, o, n]);
					if (o < 1 && u) {
						return n
					} else {
						a.resolveWith(e, [l]);
						return false
					}
				},
				l = a.promise({
					elem: e,
					props: x.extend({}, t),
					opts: x.extend(true, {
						specialEasing: {}
					}, n),
					originalProperties: t,
					originalOptions: n,
					startTime: Xn || Kn(),
					duration: n.duration,
					tweens: [],
					createTween: function(t, n) {
						var i = x.Tween(e, l.opts, t, n, l.opts.specialEasing[t] || l.opts.easing);
						l.tweens.push(i);
						return i
					},
					stop: function(t) {
						var n = 0,
							i = t ? l.tweens.length : 0;
						if (r) {
							return this
						}
						r = true;
						for (; n < i; n++) {
							l.tweens[n].run(1)
						}
						if (t) {
							a.resolveWith(e, [l, t])
						} else {
							a.rejectWith(e, [l, t])
						}
						return this
					}
				}),
				f = l.props;
			ti(f, l.opts.specialEasing);
			for (; o < s; o++) {
				i = Gn[o].call(l, e, f, l.opts);
				if (i) {
					return i
				}
			}
			x.map(f, Zn, l);
			if (x.isFunction(l.opts.start)) {
				l.opts.start.call(e, l)
			}
			x.fx.timer(x.extend(u, {
				elem: e,
				anim: l,
				queue: l.opts.queue
			}));
			return l.progress(l.opts.progress).done(l.opts.done, l.opts.complete).fail(l.opts.fail).always(l.opts.always)
		}

		function ti(e, t) {
			var n, i, r, o, s;
			for (n in e) {
				i = x.camelCase(n);
				r = t[i];
				o = e[n];
				if (x.isArray(o)) {
					r = o[1];
					o = e[n] = o[0]
				}
				if (n !== i) {
					e[i] = o;
					delete e[n]
				}
				s = x.cssHooks[i];
				if (s && "expand" in s) {
					o = s.expand(o);
					delete e[i];
					for (n in o) {
						if (!(n in e)) {
							e[n] = o[n];
							t[n] = r
						}
					}
				} else {
					t[i] = r
				}
			}
		}
		x.Animation = x.extend(ei, {
			tweener: function(e, t) {
				if (x.isFunction(e)) {
					t = e;
					e = ["*"]
				} else {
					e = e.split(" ")
				}
				var n, i = 0,
					r = e.length;
				for (; i < r; i++) {
					n = e[i];
					Qn[n] = Qn[n] || [];
					Qn[n].unshift(t)
				}
			},
			prefilter: function(e, t) {
				if (t) {
					Gn.unshift(e)
				} else {
					Gn.push(e)
				}
			}
		});

		function ni(e, t, n) {
			var i, r, o, s, a, u, l = this,
				f = {},
				c = e.style,
				p = e.nodeType && nn(e),
				d = x._data(e, "fxshow");
			if (!n.queue) {
				a = x._queueHooks(e, "fx");
				if (a.unqueued == null) {
					a.unqueued = 0;
					u = a.empty.fire;
					a.empty.fire = function() {
						if (!a.unqueued) {
							u()
						}
					}
				}
				a.unqueued++;
				l.always(function() {
					l.always(function() {
						a.unqueued--;
						if (!x.queue(e, "fx").length) {
							a.empty.fire()
						}
					})
				})
			}
			if (e.nodeType === 1 && ("height" in t || "width" in t)) {
				n.overflow = [c.overflow, c.overflowX, c.overflowY];
				if (x.css(e, "display") === "inline" && x.css(e, "float") === "none") {
					if (!x.support.inlineBlockNeedsLayout || un(e.nodeName) === "inline") {
						c.display = "inline-block"
					} else {
						c.zoom = 1
					}
				}
			}
			if (n.overflow) {
				c.overflow = "hidden";
				if (!x.support.shrinkWrapBlocks) {
					l.always(function() {
						c.overflow = n.overflow[0];
						c.overflowX = n.overflow[1];
						c.overflowY = n.overflow[2]
					})
				}
			}
			for (i in t) {
				r = t[i];
				if (Vn.exec(r)) {
					delete t[i];
					o = o || r === "toggle";
					if (r === (p ? "hide" : "show")) {
						continue
					}
					f[i] = d && d[i] || x.style(e, i)
				}
			}
			if (!x.isEmptyObject(f)) {
				if (d) {
					if ("hidden" in d) {
						p = d.hidden
					}
				} else {
					d = x._data(e, "fxshow", {})
				} if (o) {
					d.hidden = !p
				}
				if (p) {
					x(e).show()
				} else {
					l.done(function() {
						x(e).hide()
					})
				}
				l.done(function() {
					var t;
					x._removeData(e, "fxshow");
					for (t in f) {
						x.style(e, t, f[t])
					}
				});
				for (i in f) {
					s = Zn(p ? d[i] : 0, i, l);
					if (!(i in d)) {
						d[i] = s.start;
						if (p) {
							s.end = s.start;
							s.start = i === "width" || i === "height" ? 1 : 0
						}
					}
				}
			}
		}

		function ii(e, t, n, i, r) {
			return new ii.prototype.init(e, t, n, i, r)
		}
		x.Tween = ii;
		ii.prototype = {
			constructor: ii,
			init: function(e, t, n, i, r, o) {
				this.elem = e;
				this.prop = n;
				this.easing = r || "swing";
				this.options = t;
				this.start = this.now = this.cur();
				this.end = i;
				this.unit = o || (x.cssNumber[n] ? "" : "px")
			},
			cur: function() {
				var e = ii.propHooks[this.prop];
				return e && e.get ? e.get(this) : ii.propHooks._default.get(this)
			},
			run: function(e) {
				var t, n = ii.propHooks[this.prop];
				if (this.options.duration) {
					this.pos = t = x.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration)
				} else {
					this.pos = t = e
				}
				this.now = (this.end - this.start) * t + this.start;
				if (this.options.step) {
					this.options.step.call(this.elem, this.now, this)
				}
				if (n && n.set) {
					n.set(this)
				} else {
					ii.propHooks._default.set(this)
				}
				return this
			}
		};
		ii.prototype.init.prototype = ii.prototype;
		ii.propHooks = {
			_default: {
				get: function(e) {
					var t;
					if (e.elem[e.prop] != null && (!e.elem.style || e.elem.style[e.prop] == null)) {
						return e.elem[e.prop]
					}
					t = x.css(e.elem, e.prop, "");
					return !t || t === "auto" ? 0 : t
				},
				set: function(e) {
					if (x.fx.step[e.prop]) {
						x.fx.step[e.prop](e)
					} else if (e.elem.style && (e.elem.style[x.cssProps[e.prop]] != null || x.cssHooks[e.prop])) {
						x.style(e.elem, e.prop, e.now + e.unit)
					} else {
						e.elem[e.prop] = e.now
					}
				}
			}
		};
		ii.propHooks.scrollTop = ii.propHooks.scrollLeft = {
			set: function(e) {
				if (e.elem.nodeType && e.elem.parentNode) {
					e.elem[e.prop] = e.now
				}
			}
		};
		x.each(["toggle", "show", "hide"], function(e, t) {
			var n = x.fn[t];
			x.fn[t] = function(e, i, r) {
				return e == null || typeof e === "boolean" ? n.apply(this, arguments) : this.animate(ri(t, true), e, i, r)
			}
		});
		x.fn.extend({
			fadeTo: function(e, t, n, i) {
				return this.filter(nn).css("opacity", 0).show().end().animate({
					opacity: t
				}, e, n, i)
			},
			animate: function(e, t, n, i) {
				var r = x.isEmptyObject(e),
					o = x.speed(t, n, i),
					s = function() {
						var t = ei(this, x.extend({}, e), o);
						if (r || x._data(this, "finish")) {
							t.stop(true)
						}
					};
				s.finish = s;
				return r || o.queue === false ? this.each(s) : this.queue(o.queue, s)
			},
			stop: function(e, n, i) {
				var r = function(e) {
					var t = e.stop;
					delete e.stop;
					t(i)
				};
				if (typeof e !== "string") {
					i = n;
					n = e;
					e = t
				}
				if (n && e !== false) {
					this.queue(e || "fx", [])
				}
				return this.each(function() {
					var t = true,
						n = e != null && e + "queueHooks",
						o = x.timers,
						s = x._data(this);
					if (n) {
						if (s[n] && s[n].stop) {
							r(s[n])
						}
					} else {
						for (n in s) {
							if (s[n] && s[n].stop && Jn.test(n)) {
								r(s[n])
							}
						}
					}
					for (n = o.length; n--;) {
						if (o[n].elem === this && (e == null || o[n].queue === e)) {
							o[n].anim.stop(i);
							t = false;
							o.splice(n, 1)
						}
					}
					if (t || !i) {
						x.dequeue(this, e)
					}
				})
			},
			finish: function(e) {
				if (e !== false) {
					e = e || "fx"
				}
				return this.each(function() {
					var t, n = x._data(this),
						i = n[e + "queue"],
						r = n[e + "queueHooks"],
						o = x.timers,
						s = i ? i.length : 0;
					n.finish = true;
					x.queue(this, e, []);
					if (r && r.stop) {
						r.stop.call(this, true)
					}
					for (t = o.length; t--;) {
						if (o[t].elem === this && o[t].queue === e) {
							o[t].anim.stop(true);
							o.splice(t, 1)
						}
					}
					for (t = 0; t < s; t++) {
						if (i[t] && i[t].finish) {
							i[t].finish.call(this)
						}
					}
					delete n.finish
				})
			}
		});

		function ri(e, t) {
			var n, i = {
					height: e
				},
				r = 0;
			t = t ? 1 : 0;
			for (; r < 4; r += 2 - t) {
				n = Zt[r];
				i["margin" + n] = i["padding" + n] = e
			}
			if (t) {
				i.opacity = i.width = e
			}
			return i
		}
		x.each({
			slideDown: ri("show"),
			slideUp: ri("hide"),
			slideToggle: ri("toggle"),
			fadeIn: {
				opacity: "show"
			},
			fadeOut: {
				opacity: "hide"
			},
			fadeToggle: {
				opacity: "toggle"
			}
		}, function(e, t) {
			x.fn[e] = function(e, n, i) {
				return this.animate(t, e, n, i)
			}
		});
		x.speed = function(e, t, n) {
			var i = e && typeof e === "object" ? x.extend({}, e) : {
				complete: n || !n && t || x.isFunction(e) && e,
				duration: e,
				easing: n && t || t && !x.isFunction(t) && t
			};
			i.duration = x.fx.off ? 0 : typeof i.duration === "number" ? i.duration : i.duration in x.fx.speeds ? x.fx.speeds[i.duration] : x.fx.speeds._default;
			if (i.queue == null || i.queue === true) {
				i.queue = "fx"
			}
			i.old = i.complete;
			i.complete = function() {
				if (x.isFunction(i.old)) {
					i.old.call(this)
				}
				if (i.queue) {
					x.dequeue(this, i.queue)
				}
			};
			return i
		};
		x.easing = {
			linear: function(e) {
				return e
			},
			swing: function(e) {
				return .5 - Math.cos(e * Math.PI) / 2
			}
		};
		x.timers = [];
		x.fx = ii.prototype.init;
		x.fx.tick = function() {
			var e, n = x.timers,
				i = 0;
			Xn = x.now();
			for (; i < n.length; i++) {
				e = n[i];
				if (!e() && n[i] === e) {
					n.splice(i--, 1)
				}
			}
			if (!n.length) {
				x.fx.stop()
			}
			Xn = t
		};
		x.fx.timer = function(e) {
			if (e() && x.timers.push(e)) {
				x.fx.start()
			}
		};
		x.fx.interval = 13;
		x.fx.start = function() {
			if (!Un) {
				Un = setInterval(x.fx.tick, x.fx.interval)
			}
		};
		x.fx.stop = function() {
			clearInterval(Un);
			Un = null
		};
		x.fx.speeds = {
			slow: 600,
			fast: 200,
			_default: 400
		};
		x.fx.step = {};
		if (x.expr && x.expr.filters) {
			x.expr.filters.animated = function(e) {
				return x.grep(x.timers, function(t) {
					return e === t.elem
				}).length
			}
		}
		x.fn.offset = function(e) {
			if (arguments.length) {
				return e === t ? this : this.each(function(t) {
					x.offset.setOffset(this, e, t)
				})
			}
			var n, i, o = {
					top: 0,
					left: 0
				},
				s = this[0],
				a = s && s.ownerDocument;
			if (!a) {
				return
			}
			n = a.documentElement;
			if (!x.contains(n, s)) {
				return o
			}
			if (typeof s.getBoundingClientRect !== r) {
				o = s.getBoundingClientRect()
			}
			i = oi(a);
			return {
				top: o.top + (i.pageYOffset || n.scrollTop) - (n.clientTop || 0),
				left: o.left + (i.pageXOffset || n.scrollLeft) - (n.clientLeft || 0)
			}
		};
		x.offset = {
			setOffset: function(e, t, n) {
				var i = x.css(e, "position");
				if (i === "static") {
					e.style.position = "relative"
				}
				var r = x(e),
					o = r.offset(),
					s = x.css(e, "top"),
					a = x.css(e, "left"),
					u = (i === "absolute" || i === "fixed") && x.inArray("auto", [s, a]) > -1,
					l = {},
					f = {},
					c, p;
				if (u) {
					f = r.position();
					c = f.top;
					p = f.left
				} else {
					c = parseFloat(s) || 0;
					p = parseFloat(a) || 0
				} if (x.isFunction(t)) {
					t = t.call(e, n, o)
				}
				if (t.top != null) {
					l.top = t.top - o.top + c
				}
				if (t.left != null) {
					l.left = t.left - o.left + p
				}
				if ("using" in t) {
					t.using.call(e, l)
				} else {
					r.css(l)
				}
			}
		};
		x.fn.extend({
			position: function() {
				if (!this[0]) {
					return
				}
				var e, t, n = {
						top: 0,
						left: 0
					},
					i = this[0];
				if (x.css(i, "position") === "fixed") {
					t = i.getBoundingClientRect()
				} else {
					e = this.offsetParent();
					t = this.offset();
					if (!x.nodeName(e[0], "html")) {
						n = e.offset()
					}
					n.top += x.css(e[0], "borderTopWidth", true);
					n.left += x.css(e[0], "borderLeftWidth", true)
				}
				return {
					top: t.top - n.top - x.css(i, "marginTop", true),
					left: t.left - n.left - x.css(i, "marginLeft", true)
				}
			},
			offsetParent: function() {
				return this.map(function() {
					var e = this.offsetParent || a;
					while (e && (!x.nodeName(e, "html") && x.css(e, "position") === "static")) {
						e = e.offsetParent
					}
					return e || a
				})
			}
		});
		x.each({
			scrollLeft: "pageXOffset",
			scrollTop: "pageYOffset"
		}, function(e, n) {
			var i = /Y/.test(n);
			x.fn[e] = function(r) {
				return x.access(this, function(e, r, o) {
					var s = oi(e);
					if (o === t) {
						return s ? n in s ? s[n] : s.document.documentElement[r] : e[r]
					}
					if (s) {
						s.scrollTo(!i ? o : x(s).scrollLeft(), i ? o : x(s).scrollTop())
					} else {
						e[r] = o
					}
				}, e, r, arguments.length, null)
			}
		});

		function oi(e) {
			return x.isWindow(e) ? e : e.nodeType === 9 ? e.defaultView || e.parentWindow : false
		}
		x.each({
			Height: "height",
			Width: "width"
		}, function(e, n) {
			x.each({
				padding: "inner" + e,
				content: n,
				"": "outer" + e
			}, function(i, r) {
				x.fn[r] = function(r, o) {
					var s = arguments.length && (i || typeof r !== "boolean"),
						a = i || (r === true || o === true ? "margin" : "border");
					return x.access(this, function(n, i, r) {
						var o;
						if (x.isWindow(n)) {
							return n.document.documentElement["client" + e]
						}
						if (n.nodeType === 9) {
							o = n.documentElement;
							return Math.max(n.body["scroll" + e], o["scroll" + e], n.body["offset" + e], o["offset" + e], o["client" + e])
						}
						return r === t ? x.css(n, i, a) : x.style(n, i, r, a)
					}, n, s ? r : t, s, null)
				}
			})
		});
		x.fn.size = function() {
			return this.length
		};
		x.fn.andSelf = x.fn.addBack;
		if (typeof module === "object" && module && typeof module.exports === "object") {
			module.exports = x
		} else {
			e.jQuery = e.$ = x;
			if (typeof define === "function" && define.amd) {
				define("jquery", [], function() {
					return x
				})
			}
		}
	})(window)
})();;
(function() {
	(function(e) {
		"use strict";
		if (e.browser) {
			return
		}
		var i = navigator.userAgent.toLowerCase(),
			t = function(e) {
				var i = /(chrome)[ \/]([\w.]+)/.exec(e) || /(safari)[ \/]([\w.]+)/.exec(e) || /(webkit)[ \/]([\w.]+)/.exec(e) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(e) || /(msie) ([\w.]+)/.exec(e) || e.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(e) || [];
				return i[2] || "0"
			};
		e.browser = {
			mozilla: /mozilla/.test(i) && !/webkit/.test(i),
			webkit: /webkit/.test(i),
			opera: /opera/.test(i),
			msie: /msie/.test(i),
			chrome: /chrome/.test(i),
			safari: /safari/.test(i) && !/chrome/.test(i),
			android: i.indexOf("mozilla/5.0") > -1 && i.indexOf("android ") > -1 && i.indexOf("applewebkit") > -1,
			wpie: i.indexOf("mozilla/5.0") > -1 && i.indexOf("msie") > -1 && i.indexOf("iemobile") > -1,
			isTouchDevice: "ontouchstart" in window ? true : false,
			version: t(i)
		}
	})(jQuery)
})();;
(function() {
	(function(e, t) {
		function a(t, a) {
			var s, n, r, o = t.nodeName.toLowerCase();
			return "area" === o ? (s = t.parentNode, n = s.name, t.href && n && "map" === s.nodeName.toLowerCase() ? (r = e("img[usemap=#" + n + "]")[0], !!r && i(r)) : !1) : (/input|select|textarea|button|object/.test(o) ? !t.disabled : "a" === o ? t.href || a : a) && i(t)
		}

		function i(t) {
			return e.expr.filters.visible(t) && !e(t).parents().addBack().filter(function() {
				return "hidden" === e.css(this, "visibility")
			}).length
		}
		var s = 0,
			n = /^ui-id-\d+$/;
		e.ui = e.ui || {}, e.extend(e.ui, {
			version: "1.10.3",
			keyCode: {
				BACKSPACE: 8,
				COMMA: 188,
				DELETE: 46,
				DOWN: 40,
				END: 35,
				ENTER: 13,
				ESCAPE: 27,
				HOME: 36,
				LEFT: 37,
				NUMPAD_ADD: 107,
				NUMPAD_DECIMAL: 110,
				NUMPAD_DIVIDE: 111,
				NUMPAD_ENTER: 108,
				NUMPAD_MULTIPLY: 106,
				NUMPAD_SUBTRACT: 109,
				PAGE_DOWN: 34,
				PAGE_UP: 33,
				PERIOD: 190,
				RIGHT: 39,
				SPACE: 32,
				TAB: 9,
				UP: 38
			}
		}), e.fn.extend({
			focus: function(t) {
				return function(a, i) {
					return "number" == typeof a ? this.each(function() {
						var t = this;
						setTimeout(function() {
							e(t).focus(), i && i.call(t)
						}, a)
					}) : t.apply(this, arguments)
				}
			}(e.fn.focus),
			scrollParent: function() {
				var t;
				return t = e.ui.ie && /(static|relative)/.test(this.css("position")) || /absolute/.test(this.css("position")) ? this.parents().filter(function() {
					return /(relative|absolute|fixed)/.test(e.css(this, "position")) && /(auto|scroll)/.test(e.css(this, "overflow") + e.css(this, "overflow-y") + e.css(this, "overflow-x"))
				}).eq(0) : this.parents().filter(function() {
					return /(auto|scroll)/.test(e.css(this, "overflow") + e.css(this, "overflow-y") + e.css(this, "overflow-x"))
				}).eq(0), /fixed/.test(this.css("position")) || !t.length ? e(document) : t
			},
			zIndex: function(a) {
				if (a !== t) return this.css("zIndex", a);
				if (this.length)
					for (var i, s, n = e(this[0]); n.length && n[0] !== document;) {
						if (i = n.css("position"), ("absolute" === i || "relative" === i || "fixed" === i) && (s = parseInt(n.css("zIndex"), 10), !isNaN(s) && 0 !== s)) return s;
						n = n.parent()
					}
				return 0
			},
			uniqueId: function() {
				return this.each(function() {
					this.id || (this.id = "ui-id-" + ++s)
				})
			},
			removeUniqueId: function() {
				return this.each(function() {
					n.test(this.id) && e(this).removeAttr("id")
				})
			}
		}), e.extend(e.expr[":"], {
			data: e.expr.createPseudo ? e.expr.createPseudo(function(t) {
				return function(a) {
					return !!e.data(a, t)
				}
			}) : function(t, a, i) {
				return !!e.data(t, i[3])
			},
			focusable: function(t) {
				return a(t, !isNaN(e.attr(t, "tabindex")))
			},
			tabbable: function(t) {
				var i = e.attr(t, "tabindex"),
					s = isNaN(i);
				return (s || i >= 0) && a(t, !s)
			}
		}), e("<a>").outerWidth(1).jquery || e.each(["Width", "Height"], function(a, i) {
			function s(t, a, i, s) {
				return e.each(n, function() {
					a -= parseFloat(e.css(t, "padding" + this)) || 0, i && (a -= parseFloat(e.css(t, "border" + this + "Width")) || 0), s && (a -= parseFloat(e.css(t, "margin" + this)) || 0)
				}), a
			}
			var n = "Width" === i ? ["Left", "Right"] : ["Top", "Bottom"],
				r = i.toLowerCase(),
				o = {
					innerWidth: e.fn.innerWidth,
					innerHeight: e.fn.innerHeight,
					outerWidth: e.fn.outerWidth,
					outerHeight: e.fn.outerHeight
				};
			e.fn["inner" + i] = function(a) {
				return a === t ? o["inner" + i].call(this) : this.each(function() {
					e(this).css(r, s(this, a) + "px")
				})
			}, e.fn["outer" + i] = function(t, a) {
				return "number" != typeof t ? o["outer" + i].call(this, t) : this.each(function() {
					e(this).css(r, s(this, t, !0, a) + "px")
				})
			}
		}), e.fn.addBack || (e.fn.addBack = function(e) {
			return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
		}), e("<a>").data("a-b", "a").removeData("a-b").data("a-b") && (e.fn.removeData = function(t) {
			return function(a) {
				return arguments.length ? t.call(this, e.camelCase(a)) : t.call(this)
			}
		}(e.fn.removeData)), e.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase()), e.support.selectstart = "onselectstart" in document.createElement("div"), e.fn.extend({
			disableSelection: function() {
				return this.bind((e.support.selectstart ? "selectstart" : "mousedown") + ".ui-disableSelection", function(e) {
					e.preventDefault()
				})
			},
			enableSelection: function() {
				return this.unbind(".ui-disableSelection")
			}
		}), e.extend(e.ui, {
			plugin: {
				add: function(t, a, i) {
					var s, n = e.ui[t].prototype;
					for (s in i) n.plugins[s] = n.plugins[s] || [], n.plugins[s].push([a, i[s]])
				},
				call: function(e, t, a) {
					var i, s = e.plugins[t];
					if (s && e.element[0].parentNode && 11 !== e.element[0].parentNode.nodeType)
						for (i = 0; s.length > i; i++) e.options[s[i][0]] && s[i][1].apply(e.element, a)
				}
			},
			hasScroll: function(t, a) {
				if ("hidden" === e(t).css("overflow")) return !1;
				var i = a && "left" === a ? "scrollLeft" : "scrollTop",
					s = !1;
				return t[i] > 0 ? !0 : (t[i] = 1, s = t[i] > 0, t[i] = 0, s)
			}
		})
	})(jQuery);
	(function(e, t) {
		function a() {
			this._curInst = null, this._keyEvent = !1, this._disabledInputs = [], this._datepickerShowing = !1, this._inDialog = !1, this._mainDivId = "ui-datepicker-div", this._inlineClass = "ui-datepicker-inline", this._appendClass = "ui-datepicker-append", this._triggerClass = "ui-datepicker-trigger", this._dialogClass = "ui-datepicker-dialog", this._disableClass = "ui-datepicker-disabled", this._unselectableClass = "ui-datepicker-unselectable", this._currentClass = "ui-datepicker-current-day", this._dayOverClass = "ui-datepicker-days-cell-over", this.regional = [], this.regional[""] = {
				closeText: "Done",
				prevText: "Prev",
				nextText: "Next",
				currentText: "Today",
				monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
				monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
				dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
				dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
				weekHeader: "Wk",
				dateFormat: "mm/dd/yy",
				firstDay: 0,
				isRTL: !1,
				showMonthAfterYear: !1,
				yearSuffix: ""
			}, this._defaults = {
				showOn: "focus",
				showAnim: "fadeIn",
				showOptions: {},
				defaultDate: null,
				appendText: "",
				buttonText: "...",
				buttonImage: "",
				buttonImageOnly: !1,
				hideIfNoPrevNext: !1,
				navigationAsDateFormat: !1,
				gotoCurrent: !1,
				changeMonth: !1,
				changeYear: !1,
				yearRange: "c-10:c+10",
				showOtherMonths: !1,
				selectOtherMonths: !1,
				showWeek: !1,
				calculateWeek: this.iso8601Week,
				shortYearCutoff: "+10",
				minDate: null,
				maxDate: null,
				duration: "fast",
				beforeShowDay: null,
				beforeShow: null,
				onSelect: null,
				onChangeMonthYear: null,
				onClose: null,
				numberOfMonths: 1,
				showCurrentAtPos: 0,
				stepMonths: 1,
				stepBigMonths: 12,
				altField: "",
				altFormat: "",
				constrainInput: !0,
				showButtonPanel: !1,
				autoSize: !1,
				disabled: !1
			}, e.extend(this._defaults, this.regional[""]), this.dpDiv = i(e("<div id='" + this._mainDivId + "' class='ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>"))
		}

		function i(t) {
			var a = "button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";
			return t.delegate(a, "mouseout", function() {
				e(this).removeClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && e(this).removeClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && e(this).removeClass("ui-datepicker-next-hover")
			}).delegate(a, "mouseover", function() {
				e.datepicker._isDisabledDatepicker(n.inline ? t.parent()[0] : n.input[0]) || (e(this).parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"), e(this).addClass("ui-state-hover"), -1 !== this.className.indexOf("ui-datepicker-prev") && e(this).addClass("ui-datepicker-prev-hover"), -1 !== this.className.indexOf("ui-datepicker-next") && e(this).addClass("ui-datepicker-next-hover"))
			})
		}

		function s(t, a) {
			e.extend(t, a);
			for (var i in a) null == a[i] && (t[i] = a[i]);
			return t
		}
		e.extend(e.ui, {
			datepicker: {
				version: "1.10.3"
			}
		});
		var n, r = "datepicker";
		e.extend(a.prototype, {
			markerClassName: "hasDatepicker",
			maxRows: 4,
			_widgetDatepicker: function() {
				return this.dpDiv
			},
			setDefaults: function(e) {
				return s(this._defaults, e || {}), this
			},
			_attachDatepicker: function(t, a) {
				var i, s, n;
				i = t.nodeName.toLowerCase(), s = "div" === i || "span" === i, t.id || (this.uuid += 1, t.id = "dp" + this.uuid), n = this._newInst(e(t), s), n.settings = e.extend({}, a || {}), "input" === i ? this._connectDatepicker(t, n) : s && this._inlineDatepicker(t, n)
			},
			_newInst: function(t, a) {
				var s = t[0].id.replace(/([^A-Za-z0-9_\-])/g, "\\\\$1");
				return {
					id: s,
					input: t,
					selectedDay: 0,
					selectedMonth: 0,
					selectedYear: 0,
					drawMonth: 0,
					drawYear: 0,
					inline: a,
					dpDiv: a ? i(e("<div class='" + this._inlineClass + " ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all'></div>")) : this.dpDiv
				}
			},
			_connectDatepicker: function(t, a) {
				var i = e(t);
				a.append = e([]), a.trigger = e([]), i.hasClass(this.markerClassName) || (this._attachments(i, a), i.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress).keyup(this._doKeyUp), this._autoSize(a), e.data(t, r, a), a.settings.disabled && this._disableDatepicker(t))
			},
			_attachments: function(t, a) {
				var i, s, n, r = this._get(a, "appendText"),
					o = this._get(a, "isRTL");
				a.append && a.append.remove(), r && (a.append = e("<span class='" + this._appendClass + "'>" + r + "</span>"), t[o ? "before" : "after"](a.append)), t.unbind("focus", this._showDatepicker), a.trigger && a.trigger.remove(), i = this._get(a, "showOn"), ("focus" === i || "both" === i) && t.focus(this._showDatepicker), ("button" === i || "both" === i) && (s = this._get(a, "buttonText"), n = this._get(a, "buttonImage"), a.trigger = e(this._get(a, "buttonImageOnly") ? e("<img/>").addClass(this._triggerClass).attr({
					src: n,
					alt: s,
					title: s
				}) : e("<button type='button'></button>").addClass(this._triggerClass).html(n ? e("<img/>").attr({
					src: n,
					alt: s,
					title: s
				}) : s)), t[o ? "before" : "after"](a.trigger), a.trigger.click(function() {
					return e.datepicker._datepickerShowing && e.datepicker._lastInput === t[0] ? e.datepicker._hideDatepicker() : e.datepicker._datepickerShowing && e.datepicker._lastInput !== t[0] ? (e.datepicker._hideDatepicker(), e.datepicker._showDatepicker(t[0])) : e.datepicker._showDatepicker(t[0]), !1
				}))
			},
			_autoSize: function(e) {
				if (this._get(e, "autoSize") && !e.inline) {
					var t, a, i, s, n = new Date(2009, 11, 20),
						r = this._get(e, "dateFormat");
					r.match(/[DM]/) && (t = function(e) {
						for (a = 0, i = 0, s = 0; e.length > s; s++) e[s].length > a && (a = e[s].length, i = s);
						return i
					}, n.setMonth(t(this._get(e, r.match(/MM/) ? "monthNames" : "monthNamesShort"))), n.setDate(t(this._get(e, r.match(/DD/) ? "dayNames" : "dayNamesShort")) + 20 - n.getDay())), e.input.attr("size", this._formatDate(e, n).length)
				}
			},
			_inlineDatepicker: function(t, a) {
				var i = e(t);
				i.hasClass(this.markerClassName) || (i.addClass(this.markerClassName).append(a.dpDiv), e.data(t, r, a), this._setDate(a, this._getDefaultDate(a), !0), this._updateDatepicker(a), this._updateAlternate(a), a.settings.disabled && this._disableDatepicker(t), a.dpDiv.css("display", "block"))
			},
			_dialogDatepicker: function(t, a, i, n, o) {
				var c, d, l, u, h, p = this._dialogInst;
				return p || (this.uuid += 1, c = "dp" + this.uuid, this._dialogInput = e("<input type='text' id='" + c + "' style='position: absolute; top: -100px; width: 0px;'/>"), this._dialogInput.keydown(this._doKeyDown), e("body").append(this._dialogInput), p = this._dialogInst = this._newInst(this._dialogInput, !1), p.settings = {}, e.data(this._dialogInput[0], r, p)), s(p.settings, n || {}), a = a && a.constructor === Date ? this._formatDate(p, a) : a, this._dialogInput.val(a), this._pos = o ? o.length ? o : [o.pageX, o.pageY] : null, this._pos || (d = document.documentElement.clientWidth, l = document.documentElement.clientHeight, u = document.documentElement.scrollLeft || document.body.scrollLeft, h = document.documentElement.scrollTop || document.body.scrollTop, this._pos = [d / 2 - 100 + u, l / 2 - 150 + h]), this._dialogInput.css("left", this._pos[0] + 20 + "px").css("top", this._pos[1] + "px"), p.settings.onSelect = i, this._inDialog = !0, this.dpDiv.addClass(this._dialogClass), this._showDatepicker(this._dialogInput[0]), e.blockUI && e.blockUI(this.dpDiv), e.data(this._dialogInput[0], r, p), this
			},
			_destroyDatepicker: function(t) {
				var a, i = e(t),
					s = e.data(t, r);
				i.hasClass(this.markerClassName) && (a = t.nodeName.toLowerCase(), e.removeData(t, r), "input" === a ? (s.append.remove(), s.trigger.remove(), i.removeClass(this.markerClassName).unbind("focus", this._showDatepicker).unbind("keydown", this._doKeyDown).unbind("keypress", this._doKeyPress).unbind("keyup", this._doKeyUp)) : ("div" === a || "span" === a) && i.removeClass(this.markerClassName).empty())
			},
			_enableDatepicker: function(t) {
				var a, i, s = e(t),
					n = e.data(t, r);
				s.hasClass(this.markerClassName) && (a = t.nodeName.toLowerCase(), "input" === a ? (t.disabled = !1, n.trigger.filter("button").each(function() {
					this.disabled = !1
				}).end().filter("img").css({
					opacity: "1.0",
					cursor: ""
				})) : ("div" === a || "span" === a) && (i = s.children("." + this._inlineClass), i.children().removeClass("ui-state-disabled"), i.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !1)), this._disabledInputs = e.map(this._disabledInputs, function(e) {
					return e === t ? null : e
				}))
			},
			_disableDatepicker: function(t) {
				var a, i, s = e(t),
					n = e.data(t, r);
				s.hasClass(this.markerClassName) && (a = t.nodeName.toLowerCase(), "input" === a ? (t.disabled = !0, n.trigger.filter("button").each(function() {
					this.disabled = !0
				}).end().filter("img").css({
					opacity: "0.5",
					cursor: "default"
				})) : ("div" === a || "span" === a) && (i = s.children("." + this._inlineClass), i.children().addClass("ui-state-disabled"), i.find("select.ui-datepicker-month, select.ui-datepicker-year").prop("disabled", !0)), this._disabledInputs = e.map(this._disabledInputs, function(e) {
					return e === t ? null : e
				}), this._disabledInputs[this._disabledInputs.length] = t)
			},
			_isDisabledDatepicker: function(e) {
				if (!e) return !1;
				for (var t = 0; this._disabledInputs.length > t; t++)
					if (this._disabledInputs[t] === e) return !0;
				return !1
			},
			_getInst: function(t) {
				try {
					return e.data(t, r)
				} catch (a) {
					throw "Missing instance data for this datepicker"
				}
			},
			_optionDatepicker: function(a, i, n) {
				var r, o, c, d, l = this._getInst(a);
				return 2 === arguments.length && "string" == typeof i ? "defaults" === i ? e.extend({}, e.datepicker._defaults) : l ? "all" === i ? e.extend({}, l.settings) : this._get(l, i) : null : (r = i || {}, "string" == typeof i && (r = {}, r[i] = n), l && (this._curInst === l && this._hideDatepicker(), o = this._getDateDatepicker(a, !0), c = this._getMinMaxDate(l, "min"), d = this._getMinMaxDate(l, "max"), s(l.settings, r), null !== c && r.dateFormat !== t && r.minDate === t && (l.settings.minDate = this._formatDate(l, c)), null !== d && r.dateFormat !== t && r.maxDate === t && (l.settings.maxDate = this._formatDate(l, d)), "disabled" in r && (r.disabled ? this._disableDatepicker(a) : this._enableDatepicker(a)), this._attachments(e(a), l), this._autoSize(l), this._setDate(l, o), this._updateAlternate(l), this._updateDatepicker(l)), t)
			},
			_changeDatepicker: function(e, t, a) {
				this._optionDatepicker(e, t, a)
			},
			_refreshDatepicker: function(e) {
				var t = this._getInst(e);
				t && this._updateDatepicker(t)
			},
			_setDateDatepicker: function(e, t) {
				var a = this._getInst(e);
				a && (this._setDate(a, t), this._updateDatepicker(a), this._updateAlternate(a))
			},
			_getDateDatepicker: function(e, t) {
				var a = this._getInst(e);
				return a && !a.inline && this._setDateFromField(a, t), a ? this._getDate(a) : null
			},
			_doKeyDown: function(t) {
				var a, i, s, n = e.datepicker._getInst(t.target),
					r = !0,
					o = n.dpDiv.is(".ui-datepicker-rtl");
				if (n._keyEvent = !0, e.datepicker._datepickerShowing) switch (t.keyCode) {
					case 9:
						e.datepicker._hideDatepicker(), r = !1;
						break;
					case 13:
						return s = e("td." + e.datepicker._dayOverClass + ":not(." + e.datepicker._currentClass + ")", n.dpDiv), s[0] && e.datepicker._selectDay(t.target, n.selectedMonth, n.selectedYear, s[0]), a = e.datepicker._get(n, "onSelect"), a ? (i = e.datepicker._formatDate(n), a.apply(n.input ? n.input[0] : null, [i, n])) : e.datepicker._hideDatepicker(), !1;
					case 27:
						e.datepicker._hideDatepicker();
						break;
					case 33:
						e.datepicker._adjustDate(t.target, t.ctrlKey ? -e.datepicker._get(n, "stepBigMonths") : -e.datepicker._get(n, "stepMonths"), "M");
						break;
					case 34:
						e.datepicker._adjustDate(t.target, t.ctrlKey ? +e.datepicker._get(n, "stepBigMonths") : +e.datepicker._get(n, "stepMonths"), "M");
						break;
					case 35:
						(t.ctrlKey || t.metaKey) && e.datepicker._clearDate(t.target), r = t.ctrlKey || t.metaKey;
						break;
					case 36:
						(t.ctrlKey || t.metaKey) && e.datepicker._gotoToday(t.target), r = t.ctrlKey || t.metaKey;
						break;
					case 37:
						(t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, o ? 1 : -1, "D"), r = t.ctrlKey || t.metaKey, t.originalEvent.altKey && e.datepicker._adjustDate(t.target, t.ctrlKey ? -e.datepicker._get(n, "stepBigMonths") : -e.datepicker._get(n, "stepMonths"), "M");
						break;
					case 38:
						(t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, -7, "D"), r = t.ctrlKey || t.metaKey;
						break;
					case 39:
						(t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, o ? -1 : 1, "D"), r = t.ctrlKey || t.metaKey, t.originalEvent.altKey && e.datepicker._adjustDate(t.target, t.ctrlKey ? +e.datepicker._get(n, "stepBigMonths") : +e.datepicker._get(n, "stepMonths"), "M");
						break;
					case 40:
						(t.ctrlKey || t.metaKey) && e.datepicker._adjustDate(t.target, 7, "D"), r = t.ctrlKey || t.metaKey;
						break;
					default:
						r = !1
				} else 36 === t.keyCode && t.ctrlKey ? e.datepicker._showDatepicker(this) : r = !1;
				r && (t.preventDefault(), t.stopPropagation())
			},
			_doKeyPress: function(a) {
				var i, s, n = e.datepicker._getInst(a.target);
				return e.datepicker._get(n, "constrainInput") ? (i = e.datepicker._possibleChars(e.datepicker._get(n, "dateFormat")), s = String.fromCharCode(null == a.charCode ? a.keyCode : a.charCode), a.ctrlKey || a.metaKey || " " > s || !i || i.indexOf(s) > -1) : t
			},
			_doKeyUp: function(t) {
				var a, i = e.datepicker._getInst(t.target);
				if (i.input.val() !== i.lastVal) try {
					a = e.datepicker.parseDate(e.datepicker._get(i, "dateFormat"), i.input ? i.input.val() : null, e.datepicker._getFormatConfig(i)), a && (e.datepicker._setDateFromField(i), e.datepicker._updateAlternate(i), e.datepicker._updateDatepicker(i))
				} catch (s) {}
				return !0
			},
			_showDatepicker: function(t) {
				if (t = t.target || t, "input" !== t.nodeName.toLowerCase() && (t = e("input", t.parentNode)[0]), !e.datepicker._isDisabledDatepicker(t) && e.datepicker._lastInput !== t) {
					var a, i, n, r, o, c, d;
					a = e.datepicker._getInst(t), e.datepicker._curInst && e.datepicker._curInst !== a && (e.datepicker._curInst.dpDiv.stop(!0, !0), a && e.datepicker._datepickerShowing && e.datepicker._hideDatepicker(e.datepicker._curInst.input[0])), i = e.datepicker._get(a, "beforeShow"), n = i ? i.apply(t, [t, a]) : {}, n !== !1 && (s(a.settings, n), a.lastVal = null, e.datepicker._lastInput = t, e.datepicker._setDateFromField(a), e.datepicker._inDialog && (t.value = ""), e.datepicker._pos || (e.datepicker._pos = e.datepicker._findPos(t), e.datepicker._pos[1] += t.offsetHeight), r = !1, e(t).parents().each(function() {
						return r |= "fixed" === e(this).css("position"), !r
					}), o = {
						left: e.datepicker._pos[0],
						top: e.datepicker._pos[1]
					}, e.datepicker._pos = null, a.dpDiv.empty(), a.dpDiv.css({
						position: "absolute",
						display: "block",
						top: "-1000px"
					}), e.datepicker._updateDatepicker(a), o = e.datepicker._checkOffset(a, o, r), a.dpDiv.css({
						position: e.datepicker._inDialog && e.blockUI ? "static" : r ? "fixed" : "absolute",
						display: "none",
						left: o.left + "px",
						top: o.top + "px"
					}), a.inline || (c = e.datepicker._get(a, "showAnim"), d = e.datepicker._get(a, "duration"), a.dpDiv.zIndex(e(t).zIndex() + 1), e.datepicker._datepickerShowing = !0, e.effects && e.effects.effect[c] ? a.dpDiv.show(c, e.datepicker._get(a, "showOptions"), d) : a.dpDiv[c || "show"](c ? d : null), e.datepicker._shouldFocusInput(a) && a.input.focus(), e.datepicker._curInst = a))
				}
			},
			_updateDatepicker: function(t) {
				this.maxRows = 4, n = t, t.dpDiv.empty().append(this._generateHTML(t)), this._attachHandlers(t), t.dpDiv.find("." + this._dayOverClass + " a").mouseover();
				var a, i = this._getNumberOfMonths(t),
					s = i[1],
					r = 17;
				t.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""), s > 1 && t.dpDiv.addClass("ui-datepicker-multi-" + s).css("width", r * s + "em"), t.dpDiv[(1 !== i[0] || 1 !== i[1] ? "add" : "remove") + "Class"]("ui-datepicker-multi"), t.dpDiv[(this._get(t, "isRTL") ? "add" : "remove") + "Class"]("ui-datepicker-rtl"), t === e.datepicker._curInst && e.datepicker._datepickerShowing && e.datepicker._shouldFocusInput(t) && t.input.focus(), t.yearshtml && (a = t.yearshtml, setTimeout(function() {
					a === t.yearshtml && t.yearshtml && t.dpDiv.find("select.ui-datepicker-year:first").replaceWith(t.yearshtml), a = t.yearshtml = null
				}, 0))
			},
			_shouldFocusInput: function(e) {
				return e.input && e.input.is(":visible") && !e.input.is(":disabled") && !e.input.is(":focus")
			},
			_checkOffset: function(t, a, i) {
				var s = t.dpDiv.outerWidth(),
					n = t.dpDiv.outerHeight(),
					r = t.input ? t.input.outerWidth() : 0,
					o = t.input ? t.input.outerHeight() : 0,
					c = document.documentElement.clientWidth + (i ? 0 : e(document).scrollLeft()),
					d = document.documentElement.clientHeight + (i ? 0 : e(document).scrollTop());
				return a.left -= this._get(t, "isRTL") ? s - r : 0, a.left -= i && a.left === t.input.offset().left ? e(document).scrollLeft() : 0, a.top -= i && a.top === t.input.offset().top + o ? e(document).scrollTop() : 0, a.left -= Math.min(a.left, a.left + s > c && c > s ? Math.abs(a.left + s - c) : 0), a.top -= Math.min(a.top, a.top + n > d && d > n ? Math.abs(n + o) : 0), a
			},
			_findPos: function(t) {
				for (var a, i = this._getInst(t), s = this._get(i, "isRTL"); t && ("hidden" === t.type || 1 !== t.nodeType || e.expr.filters.hidden(t));) t = t[s ? "previousSibling" : "nextSibling"];
				return a = e(t).offset(), [a.left, a.top]
			},
			_hideDatepicker: function(t) {
				var a, i, s, n, o = this._curInst;
				!o || t && o !== e.data(t, r) || this._datepickerShowing && (a = this._get(o, "showAnim"), i = this._get(o, "duration"), s = function() {
					e.datepicker._tidyDialog(o)
				}, e.effects && (e.effects.effect[a] || e.effects[a]) ? o.dpDiv.hide(a, e.datepicker._get(o, "showOptions"), i, s) : o.dpDiv["slideDown" === a ? "slideUp" : "fadeIn" === a ? "fadeOut" : "hide"](a ? i : null, s), a || s(), this._datepickerShowing = !1, n = this._get(o, "onClose"), n && n.apply(o.input ? o.input[0] : null, [o.input ? o.input.val() : "", o]), this._lastInput = null, this._inDialog && (this._dialogInput.css({
					position: "absolute",
					left: "0",
					top: "-100px"
				}), e.blockUI && (e.unblockUI(), e("body").append(this.dpDiv))), this._inDialog = !1)
			},
			_tidyDialog: function(e) {
				e.dpDiv.removeClass(this._dialogClass).unbind(".ui-datepicker-calendar")
			},
			_checkExternalClick: function(t) {
				if (e.datepicker._curInst) {
					var a = e(t.target),
						i = e.datepicker._getInst(a[0]);
					(a[0].id !== e.datepicker._mainDivId && 0 === a.parents("#" + e.datepicker._mainDivId).length && !a.hasClass(e.datepicker.markerClassName) && !a.closest("." + e.datepicker._triggerClass).length && e.datepicker._datepickerShowing && (!e.datepicker._inDialog || !e.blockUI) || a.hasClass(e.datepicker.markerClassName) && e.datepicker._curInst !== i) && e.datepicker._hideDatepicker()
				}
			},
			_adjustDate: function(t, a, i) {
				var s = e(t),
					n = this._getInst(s[0]);
				this._isDisabledDatepicker(s[0]) || (this._adjustInstDate(n, a + ("M" === i ? this._get(n, "showCurrentAtPos") : 0), i), this._updateDatepicker(n))
			},
			_gotoToday: function(t) {
				var a, i = e(t),
					s = this._getInst(i[0]);
				this._get(s, "gotoCurrent") && s.currentDay ? (s.selectedDay = s.currentDay, s.drawMonth = s.selectedMonth = s.currentMonth, s.drawYear = s.selectedYear = s.currentYear) : (a = new Date, s.selectedDay = a.getDate(), s.drawMonth = s.selectedMonth = a.getMonth(), s.drawYear = s.selectedYear = a.getFullYear()), this._notifyChange(s), this._adjustDate(i)
			},
			_selectMonthYear: function(t, a, i) {
				var s = e(t),
					n = this._getInst(s[0]);
				n["selected" + ("M" === i ? "Month" : "Year")] = n["draw" + ("M" === i ? "Month" : "Year")] = parseInt(a.options[a.selectedIndex].value, 10), this._notifyChange(n), this._adjustDate(s)
			},
			_selectDay: function(t, a, i, s) {
				var n, r = e(t);
				e(s).hasClass(this._unselectableClass) || this._isDisabledDatepicker(r[0]) || (n = this._getInst(r[0]), n.selectedDay = n.currentDay = e("a", s).html(), n.selectedMonth = n.currentMonth = a, n.selectedYear = n.currentYear = i, this._selectDate(t, this._formatDate(n, n.currentDay, n.currentMonth, n.currentYear)))
			},
			_clearDate: function(t) {
				var a = e(t);
				this._selectDate(a, "")
			},
			_selectDate: function(t, a) {
				var i, s = e(t),
					n = this._getInst(s[0]);
				a = null != a ? a : this._formatDate(n), n.input && n.input.val(a), this._updateAlternate(n), i = this._get(n, "onSelect"), i ? i.apply(n.input ? n.input[0] : null, [a, n]) : n.input && n.input.trigger("change"), n.inline ? this._updateDatepicker(n) : (this._hideDatepicker(), this._lastInput = n.input[0], "object" != typeof n.input[0] && n.input.focus(), this._lastInput = null)
			},
			_updateAlternate: function(t) {
				var a, i, s, n = this._get(t, "altField");
				n && (a = this._get(t, "altFormat") || this._get(t, "dateFormat"), i = this._getDate(t), s = this.formatDate(a, i, this._getFormatConfig(t)), e(n).each(function() {
					e(this).val(s)
				}))
			},
			noWeekends: function(e) {
				var t = e.getDay();
				return [t > 0 && 6 > t, ""]
			},
			iso8601Week: function(e) {
				var t, a = new Date(e.getTime());
				return a.setDate(a.getDate() + 4 - (a.getDay() || 7)), t = a.getTime(), a.setMonth(0), a.setDate(1), Math.floor(Math.round((t - a) / 864e5) / 7) + 1
			},
			parseDate: function(a, i, s) {
				if (null == a || null == i) throw "Invalid arguments";
				if (i = "object" == typeof i ? "" + i : i + "", "" === i) return null;
				var n, r, o, c, d = 0,
					l = (s ? s.shortYearCutoff : null) || this._defaults.shortYearCutoff,
					u = "string" != typeof l ? l : (new Date).getFullYear() % 100 + parseInt(l, 10),
					h = (s ? s.dayNamesShort : null) || this._defaults.dayNamesShort,
					p = (s ? s.dayNames : null) || this._defaults.dayNames,
					g = (s ? s.monthNamesShort : null) || this._defaults.monthNamesShort,
					_ = (s ? s.monthNames : null) || this._defaults.monthNames,
					f = -1,
					m = -1,
					D = -1,
					k = -1,
					y = !1,
					v = function(e) {
						var t = a.length > n + 1 && a.charAt(n + 1) === e;
						return t && n++, t
					},
					M = function(e) {
						var t = v(e),
							a = "@" === e ? 14 : "!" === e ? 20 : "y" === e && t ? 4 : "o" === e ? 3 : 2,
							s = RegExp("^\\d{1," + a + "}"),
							n = i.substring(d).match(s);
						if (!n) throw "Missing number at position " + d;
						return d += n[0].length, parseInt(n[0], 10)
					},
					b = function(a, s, n) {
						var r = -1,
							o = e.map(v(a) ? n : s, function(e, t) {
								return [
									[t, e]
								]
							}).sort(function(e, t) {
								return -(e[1].length - t[1].length)
							});
						if (e.each(o, function(e, a) {
							var s = a[1];
							return i.substr(d, s.length).toLowerCase() === s.toLowerCase() ? (r = a[0], d += s.length, !1) : t
						}), -1 !== r) return r + 1;
						throw "Unknown name at position " + d
					},
					w = function() {
						if (i.charAt(d) !== a.charAt(n)) throw "Unexpected literal at position " + d;
						d++
					};
				for (n = 0; a.length > n; n++)
					if (y) "'" !== a.charAt(n) || v("'") ? w() : y = !1;
					else switch (a.charAt(n)) {
						case "d":
							D = M("d");
							break;
						case "D":
							b("D", h, p);
							break;
						case "o":
							k = M("o");
							break;
						case "m":
							m = M("m");
							break;
						case "M":
							m = b("M", g, _);
							break;
						case "y":
							f = M("y");
							break;
						case "@":
							c = new Date(M("@")), f = c.getFullYear(), m = c.getMonth() + 1, D = c.getDate();
							break;
						case "!":
							c = new Date((M("!") - this._ticksTo1970) / 1e4), f = c.getFullYear(), m = c.getMonth() + 1, D = c.getDate();
							break;
						case "'":
							v("'") ? w() : y = !0;
							break;
						default:
							w()
					}
					if (i.length > d && (o = i.substr(d), !/^\s+/.test(o))) throw "Extra/unparsed characters found in date: " + o;
				if (-1 === f ? f = (new Date).getFullYear() : 100 > f && (f += (new Date).getFullYear() - (new Date).getFullYear() % 100 + (u >= f ? 0 : -100)), k > -1)
					for (m = 1, D = k;;) {
						if (r = this._getDaysInMonth(f, m - 1), r >= D) break;
						m++, D -= r
					}
				if (c = this._daylightSavingAdjust(new Date(f, m - 1, D)), c.getFullYear() !== f || c.getMonth() + 1 !== m || c.getDate() !== D) throw "Invalid date";
				return c
			},
			ATOM: "yy-mm-dd",
			COOKIE: "D, dd M yy",
			ISO_8601: "yy-mm-dd",
			RFC_822: "D, d M y",
			RFC_850: "DD, dd-M-y",
			RFC_1036: "D, d M y",
			RFC_1123: "D, d M yy",
			RFC_2822: "D, d M yy",
			RSS: "D, d M y",
			TICKS: "!",
			TIMESTAMP: "@",
			W3C: "yy-mm-dd",
			_ticksTo1970: 1e7 * 60 * 60 * 24 * (718685 + Math.floor(492.5) - Math.floor(19.7) + Math.floor(4.925)),
			formatDate: function(e, t, a) {
				if (!t) return "";
				var i, s = (a ? a.dayNamesShort : null) || this._defaults.dayNamesShort,
					n = (a ? a.dayNames : null) || this._defaults.dayNames,
					r = (a ? a.monthNamesShort : null) || this._defaults.monthNamesShort,
					o = (a ? a.monthNames : null) || this._defaults.monthNames,
					c = function(t) {
						var a = e.length > i + 1 && e.charAt(i + 1) === t;
						return a && i++, a
					},
					d = function(e, t, a) {
						var i = "" + t;
						if (c(e))
							for (; a > i.length;) i = "0" + i;
						return i
					},
					l = function(e, t, a, i) {
						return c(e) ? i[t] : a[t]
					},
					u = "",
					h = !1;
				if (t)
					for (i = 0; e.length > i; i++)
						if (h) "'" !== e.charAt(i) || c("'") ? u += e.charAt(i) : h = !1;
						else switch (e.charAt(i)) {
							case "d":
								u += d("d", t.getDate(), 2);
								break;
							case "D":
								u += l("D", t.getDay(), s, n);
								break;
							case "o":
								u += d("o", Math.round((new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime() - new Date(t.getFullYear(), 0, 0).getTime()) / 864e5), 3);
								break;
							case "m":
								u += d("m", t.getMonth() + 1, 2);
								break;
							case "M":
								u += l("M", t.getMonth(), r, o);
								break;
							case "y":
								u += c("y") ? t.getFullYear() : (10 > t.getYear() % 100 ? "0" : "") + t.getYear() % 100;
								break;
							case "@":
								u += t.getTime();
								break;
							case "!":
								u += 1e4 * t.getTime() + this._ticksTo1970;
								break;
							case "'":
								c("'") ? u += "'" : h = !0;
								break;
							default:
								u += e.charAt(i)
						}
						return u
			},
			_possibleChars: function(e) {
				var t, a = "",
					i = !1,
					s = function(a) {
						var i = e.length > t + 1 && e.charAt(t + 1) === a;
						return i && t++, i
					};
				for (t = 0; e.length > t; t++)
					if (i) "'" !== e.charAt(t) || s("'") ? a += e.charAt(t) : i = !1;
					else switch (e.charAt(t)) {
						case "d":
						case "m":
						case "y":
						case "@":
							a += "0123456789";
							break;
						case "D":
						case "M":
							return null;
						case "'":
							s("'") ? a += "'" : i = !0;
							break;
						default:
							a += e.charAt(t)
					}
					return a
			},
			_get: function(e, a) {
				return e.settings[a] !== t ? e.settings[a] : this._defaults[a]
			},
			_setDateFromField: function(e, t) {
				if (e.input.val() !== e.lastVal) {
					var a = this._get(e, "dateFormat"),
						i = e.lastVal = e.input ? e.input.val() : null,
						s = this._getDefaultDate(e),
						n = s,
						r = this._getFormatConfig(e);
					try {
						n = this.parseDate(a, i, r) || s
					} catch (o) {
						i = t ? "" : i
					}
					e.selectedDay = n.getDate(), e.drawMonth = e.selectedMonth = n.getMonth(), e.drawYear = e.selectedYear = n.getFullYear(), e.currentDay = i ? n.getDate() : 0, e.currentMonth = i ? n.getMonth() : 0, e.currentYear = i ? n.getFullYear() : 0, this._adjustInstDate(e)
				}
			},
			_getDefaultDate: function(e) {
				return this._restrictMinMax(e, this._determineDate(e, this._get(e, "defaultDate"), new Date))
			},
			_determineDate: function(t, a, i) {
				var s = function(e) {
						var t = new Date;
						return t.setDate(t.getDate() + e), t
					},
					n = function(a) {
						try {
							return e.datepicker.parseDate(e.datepicker._get(t, "dateFormat"), a, e.datepicker._getFormatConfig(t))
						} catch (i) {}
						for (var s = (a.toLowerCase().match(/^c/) ? e.datepicker._getDate(t) : null) || new Date, n = s.getFullYear(), r = s.getMonth(), o = s.getDate(), c = /([+\-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g, d = c.exec(a); d;) {
							switch (d[2] || "d") {
								case "d":
								case "D":
									o += parseInt(d[1], 10);
									break;
								case "w":
								case "W":
									o += 7 * parseInt(d[1], 10);
									break;
								case "m":
								case "M":
									r += parseInt(d[1], 10), o = Math.min(o, e.datepicker._getDaysInMonth(n, r));
									break;
								case "y":
								case "Y":
									n += parseInt(d[1], 10), o = Math.min(o, e.datepicker._getDaysInMonth(n, r))
							}
							d = c.exec(a)
						}
						return new Date(n, r, o)
					},
					r = null == a || "" === a ? i : "string" == typeof a ? n(a) : "number" == typeof a ? isNaN(a) ? i : s(a) : new Date(a.getTime());
				return r = r && "Invalid Date" == "" + r ? i : r, r && (r.setHours(0), r.setMinutes(0), r.setSeconds(0), r.setMilliseconds(0)), this._daylightSavingAdjust(r)
			},
			_daylightSavingAdjust: function(e) {
				return e ? (e.setHours(e.getHours() > 12 ? e.getHours() + 2 : 0), e) : null
			},
			_setDate: function(e, t, a) {
				var i = !t,
					s = e.selectedMonth,
					n = e.selectedYear,
					r = this._restrictMinMax(e, this._determineDate(e, t, new Date));
				e.selectedDay = e.currentDay = r.getDate(), e.drawMonth = e.selectedMonth = e.currentMonth = r.getMonth(), e.drawYear = e.selectedYear = e.currentYear = r.getFullYear(), s === e.selectedMonth && n === e.selectedYear || a || this._notifyChange(e), this._adjustInstDate(e), e.input && e.input.val(i ? "" : this._formatDate(e))
			},
			_getDate: function(e) {
				var t = !e.currentYear || e.input && "" === e.input.val() ? null : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
				return t
			},
			_attachHandlers: function(t) {
				var a = this._get(t, "stepMonths"),
					i = "#" + t.id.replace(/\\\\/g, "\\");
				t.dpDiv.find("[data-handler]").map(function() {
					var t = {
						prev: function() {
							e.datepicker._adjustDate(i, -a, "M")
						},
						next: function() {
							e.datepicker._adjustDate(i, +a, "M")
						},
						hide: function() {
							e.datepicker._hideDatepicker()
						},
						today: function() {
							e.datepicker._gotoToday(i)
						},
						selectDay: function() {
							return e.datepicker._selectDay(i, +this.getAttribute("data-month"), +this.getAttribute("data-year"), this), !1
						},
						selectMonth: function() {
							return e.datepicker._selectMonthYear(i, this, "M"), !1
						},
						selectYear: function() {
							return e.datepicker._selectMonthYear(i, this, "Y"), !1
						}
					};
					e(this).bind(this.getAttribute("data-event"), t[this.getAttribute("data-handler")])
				})
			},
			_generateHTML: function(e) {
				var t, a, i, s, n, r, o, c, d, l, u, h, p, g, _, f, m, D, k, y, v, M, b, w, C, I, x, N, Y, S, A, T, F, j, K, O, E, P, L, R = new Date,
					W = this._daylightSavingAdjust(new Date(R.getFullYear(), R.getMonth(), R.getDate())),
					H = this._get(e, "isRTL"),
					U = this._get(e, "showButtonPanel"),
					z = this._get(e, "hideIfNoPrevNext"),
					B = this._get(e, "navigationAsDateFormat"),
					J = this._getNumberOfMonths(e),
					q = this._get(e, "showCurrentAtPos"),
					V = this._get(e, "stepMonths"),
					G = 1 !== J[0] || 1 !== J[1],
					Q = this._daylightSavingAdjust(e.currentDay ? new Date(e.currentYear, e.currentMonth, e.currentDay) : new Date(9999, 9, 9)),
					$ = this._getMinMaxDate(e, "min"),
					X = this._getMinMaxDate(e, "max"),
					Z = e.drawMonth - q,
					et = e.drawYear;
				if (0 > Z && (Z += 12, et--), X)
					for (t = this._daylightSavingAdjust(new Date(X.getFullYear(), X.getMonth() - J[0] * J[1] + 1, X.getDate())), t = $ && $ > t ? $ : t; this._daylightSavingAdjust(new Date(et, Z, 1)) > t;) Z--, 0 > Z && (Z = 11, et--);
				for (e.drawMonth = Z, e.drawYear = et, a = this._get(e, "prevText"), a = B ? this.formatDate(a, this._daylightSavingAdjust(new Date(et, Z - V, 1)), this._getFormatConfig(e)) : a, i = this._canAdjustMonth(e, -1, et, Z) ? "<a class='ui-datepicker-prev ui-corner-all' data-handler='prev' data-event='click' title='" + a + "'><span class='ui-icon ui-icon-circle-triangle-" + (H ? "e" : "w") + "'>" + a + "</span></a>" : z ? "" : "<a class='ui-datepicker-prev ui-corner-all ui-state-disabled' title='" + a + "'><span class='ui-icon ui-icon-circle-triangle-" + (H ? "e" : "w") + "'>" + a + "</span></a>", s = this._get(e, "nextText"), s = B ? this.formatDate(s, this._daylightSavingAdjust(new Date(et, Z + V, 1)), this._getFormatConfig(e)) : s, n = this._canAdjustMonth(e, 1, et, Z) ? "<a class='ui-datepicker-next ui-corner-all' data-handler='next' data-event='click' title='" + s + "'><span class='ui-icon ui-icon-circle-triangle-" + (H ? "w" : "e") + "'>" + s + "</span></a>" : z ? "" : "<a class='ui-datepicker-next ui-corner-all ui-state-disabled' title='" + s + "'><span class='ui-icon ui-icon-circle-triangle-" + (H ? "w" : "e") + "'>" + s + "</span></a>", r = this._get(e, "currentText"), o = this._get(e, "gotoCurrent") && e.currentDay ? Q : W, r = B ? this.formatDate(r, o, this._getFormatConfig(e)) : r, c = e.inline ? "" : "<button type='button' class='ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all' data-handler='hide' data-event='click'>" + this._get(e, "closeText") + "</button>", d = U ? "<div class='ui-datepicker-buttonpane ui-widget-content'>" + (H ? c : "") + (this._isInRange(e, o) ? "<button type='button' class='ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all' data-handler='today' data-event='click'>" + r + "</button>" : "") + (H ? "" : c) + "</div>" : "", l = parseInt(this._get(e, "firstDay"), 10), l = isNaN(l) ? 0 : l, u = this._get(e, "showWeek"), h = this._get(e, "dayNames"), p = this._get(e, "dayNamesMin"), g = this._get(e, "monthNames"), _ = this._get(e, "monthNamesShort"), f = this._get(e, "beforeShowDay"), m = this._get(e, "showOtherMonths"), D = this._get(e, "selectOtherMonths"), k = this._getDefaultDate(e), y = "", M = 0; J[0] > M; M++) {
					for (b = "", this.maxRows = 4, w = 0; J[1] > w; w++) {
						if (C = this._daylightSavingAdjust(new Date(et, Z, e.selectedDay)), I = " ui-corner-all", x = "", G) {
							if (x += "<div class='ui-datepicker-group", J[1] > 1) switch (w) {
								case 0:
									x += " ui-datepicker-group-first", I = " ui-corner-" + (H ? "right" : "left");
									break;
								case J[1] - 1:
									x += " ui-datepicker-group-last", I = " ui-corner-" + (H ? "left" : "right");
									break;
								default:
									x += " ui-datepicker-group-middle", I = ""
							}
							x += "'>"
						}
						for (x += "<div class='ui-datepicker-header ui-widget-header ui-helper-clearfix" + I + "'>" + (/all|left/.test(I) && 0 === M ? H ? n : i : "") + (/all|right/.test(I) && 0 === M ? H ? i : n : "") + this._generateMonthYearHeader(e, Z, et, $, X, M > 0 || w > 0, g, _) + "</div><table class='ui-datepicker-calendar'><thead>" + "<tr>", N = u ? "<th class='ui-datepicker-week-col'>" + this._get(e, "weekHeader") + "</th>" : "", v = 0; 7 > v; v++) Y = (v + l) % 7, N += "<th" + ((v + l + 6) % 7 >= 5 ? " class='ui-datepicker-week-end'" : "") + ">" + "<span title='" + h[Y] + "'>" + p[Y] + "</span></th>";
						for (x += N + "</tr></thead><tbody>", S = this._getDaysInMonth(et, Z), et === e.selectedYear && Z === e.selectedMonth && (e.selectedDay = Math.min(e.selectedDay, S)), A = (this._getFirstDayOfMonth(et, Z) - l + 7) % 7, T = Math.ceil((A + S) / 7), F = G ? this.maxRows > T ? this.maxRows : T : T, this.maxRows = F, j = this._daylightSavingAdjust(new Date(et, Z, 1 - A)), K = 0; F > K; K++) {
							for (x += "<tr>", O = u ? "<td class='ui-datepicker-week-col'>" + this._get(e, "calculateWeek")(j) + "</td>" : "", v = 0; 7 > v; v++) E = f ? f.apply(e.input ? e.input[0] : null, [j]) : [!0, ""], P = j.getMonth() !== Z, L = P && !D || !E[0] || $ && $ > j || X && j > X, O += "<td class='" + ((v + l + 6) % 7 >= 5 ? " ui-datepicker-week-end" : "") + (P ? " ui-datepicker-other-month" : "") + (j.getTime() === C.getTime() && Z === e.selectedMonth && e._keyEvent || k.getTime() === j.getTime() && k.getTime() === C.getTime() ? " " + this._dayOverClass : "") + (L ? " " + this._unselectableClass + " ui-state-disabled" : "") + (P && !m ? "" : " " + E[1] + (j.getTime() === Q.getTime() ? " " + this._currentClass : "") + (j.getTime() === W.getTime() ? " ui-datepicker-today" : "")) + "'" + (P && !m || !E[2] ? "" : " title='" + E[2].replace(/'/g, "&#39;") + "'") + (L ? "" : " data-handler='selectDay' data-event='click' data-month='" + j.getMonth() + "' data-year='" + j.getFullYear() + "'") + ">" + (P && !m ? "&#xa0;" : L ? "<span class='ui-state-default'>" + j.getDate() + "</span>" : "<a class='ui-state-default" + (j.getTime() === W.getTime() ? " ui-state-highlight" : "") + (j.getTime() === Q.getTime() ? " ui-state-active" : "") + (P ? " ui-priority-secondary" : "") + "' href='#'>" + j.getDate() + "</a>") + "</td>", j.setDate(j.getDate() + 1), j = this._daylightSavingAdjust(j);
							x += O + "</tr>"
						}
						Z++, Z > 11 && (Z = 0, et++), x += "</tbody></table>" + (G ? "</div>" + (J[0] > 0 && w === J[1] - 1 ? "<div class='ui-datepicker-row-break'></div>" : "") : ""), b += x
					}
					y += b
				}
				return y += d, e._keyEvent = !1, y
			},
			_generateMonthYearHeader: function(e, t, a, i, s, n, r, o) {
				var c, d, l, u, h, p, g, _, f = this._get(e, "changeMonth"),
					m = this._get(e, "changeYear"),
					D = this._get(e, "showMonthAfterYear"),
					k = "<div class='ui-datepicker-title'>",
					y = "";
				if (n || !f) y += "<span class='ui-datepicker-month'>" + r[t] + "</span>";
				else {
					for (c = i && i.getFullYear() === a, d = s && s.getFullYear() === a, y += "<select class='ui-datepicker-month' data-handler='selectMonth' data-event='change'>", l = 0; 12 > l; l++)(!c || l >= i.getMonth()) && (!d || s.getMonth() >= l) && (y += "<option value='" + l + "'" + (l === t ? " selected='selected'" : "") + ">" + o[l] + "</option>");
					y += "</select>"
				} if (D || (k += y + (!n && f && m ? "" : "&#xa0;")), !e.yearshtml)
					if (e.yearshtml = "", n || !m) k += "<span class='ui-datepicker-year'>" + a + "</span>";
					else {
						for (u = this._get(e, "yearRange").split(":"), h = (new Date).getFullYear(), p = function(e) {
							var t = e.match(/c[+\-].*/) ? a + parseInt(e.substring(1), 10) : e.match(/[+\-].*/) ? h + parseInt(e, 10) : parseInt(e, 10);
							return isNaN(t) ? h : t
						}, g = p(u[0]), _ = Math.max(g, p(u[1] || "")), g = i ? Math.max(g, i.getFullYear()) : g, _ = s ? Math.min(_, s.getFullYear()) : _, e.yearshtml += "<select class='ui-datepicker-year' data-handler='selectYear' data-event='change'>"; _ >= g; g++) e.yearshtml += "<option value='" + g + "'" + (g === a ? " selected='selected'" : "") + ">" + g + "</option>";
						e.yearshtml += "</select>", k += e.yearshtml, e.yearshtml = null
					}
				return k += this._get(e, "yearSuffix"), D && (k += (!n && f && m ? "" : "&#xa0;") + y), k += "</div>"
			},
			_adjustInstDate: function(e, t, a) {
				var i = e.drawYear + ("Y" === a ? t : 0),
					s = e.drawMonth + ("M" === a ? t : 0),
					n = Math.min(e.selectedDay, this._getDaysInMonth(i, s)) + ("D" === a ? t : 0),
					r = this._restrictMinMax(e, this._daylightSavingAdjust(new Date(i, s, n)));
				e.selectedDay = r.getDate(), e.drawMonth = e.selectedMonth = r.getMonth(), e.drawYear = e.selectedYear = r.getFullYear(), ("M" === a || "Y" === a) && this._notifyChange(e)
			},
			_restrictMinMax: function(e, t) {
				var a = this._getMinMaxDate(e, "min"),
					i = this._getMinMaxDate(e, "max"),
					s = a && a > t ? a : t;
				return i && s > i ? i : s
			},
			_notifyChange: function(e) {
				var t = this._get(e, "onChangeMonthYear");
				t && t.apply(e.input ? e.input[0] : null, [e.selectedYear, e.selectedMonth + 1, e])
			},
			_getNumberOfMonths: function(e) {
				var t = this._get(e, "numberOfMonths");
				return null == t ? [1, 1] : "number" == typeof t ? [1, t] : t
			},
			_getMinMaxDate: function(e, t) {
				return this._determineDate(e, this._get(e, t + "Date"), null)
			},
			_getDaysInMonth: function(e, t) {
				return 32 - this._daylightSavingAdjust(new Date(e, t, 32)).getDate()
			},
			_getFirstDayOfMonth: function(e, t) {
				return new Date(e, t, 1).getDay()
			},
			_canAdjustMonth: function(e, t, a, i) {
				var s = this._getNumberOfMonths(e),
					n = this._daylightSavingAdjust(new Date(a, i + (0 > t ? t : s[0] * s[1]), 1));
				return 0 > t && n.setDate(this._getDaysInMonth(n.getFullYear(), n.getMonth())), this._isInRange(e, n)
			},
			_isInRange: function(e, t) {
				var a, i, s = this._getMinMaxDate(e, "min"),
					n = this._getMinMaxDate(e, "max"),
					r = null,
					o = null,
					c = this._get(e, "yearRange");
				return c && (a = c.split(":"), i = (new Date).getFullYear(), r = parseInt(a[0], 10), o = parseInt(a[1], 10), a[0].match(/[+\-].*/) && (r += i), a[1].match(/[+\-].*/) && (o += i)), (!s || t.getTime() >= s.getTime()) && (!n || t.getTime() <= n.getTime()) && (!r || t.getFullYear() >= r) && (!o || o >= t.getFullYear())
			},
			_getFormatConfig: function(e) {
				var t = this._get(e, "shortYearCutoff");
				return t = "string" != typeof t ? t : (new Date).getFullYear() % 100 + parseInt(t, 10), {
					shortYearCutoff: t,
					dayNamesShort: this._get(e, "dayNamesShort"),
					dayNames: this._get(e, "dayNames"),
					monthNamesShort: this._get(e, "monthNamesShort"),
					monthNames: this._get(e, "monthNames")
				}
			},
			_formatDate: function(e, t, a, i) {
				t || (e.currentDay = e.selectedDay, e.currentMonth = e.selectedMonth, e.currentYear = e.selectedYear);
				var s = t ? "object" == typeof t ? t : this._daylightSavingAdjust(new Date(i, a, t)) : this._daylightSavingAdjust(new Date(e.currentYear, e.currentMonth, e.currentDay));
				return this.formatDate(this._get(e, "dateFormat"), s, this._getFormatConfig(e))
			}
		}), e.fn.datepicker = function(t) {
			if (!this.length) return this;
			e.datepicker.initialized || (e(document).mousedown(e.datepicker._checkExternalClick), e.datepicker.initialized = !0), 0 === e("#" + e.datepicker._mainDivId).length && e("body").append(e.datepicker.dpDiv);
			var a = Array.prototype.slice.call(arguments, 1);
			return "string" != typeof t || "isDisabled" !== t && "getDate" !== t && "widget" !== t ? "option" === t && 2 === arguments.length && "string" == typeof arguments[1] ? e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this[0]].concat(a)) : this.each(function() {
				"string" == typeof t ? e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this].concat(a)) : e.datepicker._attachDatepicker(this, t)
			}) : e.datepicker["_" + t + "Datepicker"].apply(e.datepicker, [this[0]].concat(a))
		}, e.datepicker = new a, e.datepicker.initialized = !1, e.datepicker.uuid = (new Date).getTime(), e.datepicker.version = "1.10.3"
	})(jQuery)
})();;
(function() {
	window.console = window.console || {
		log: function() {},
		error: function() {},
		dir: function() {},
		assert: function() {},
		count: function() {},
		exception: function() {},
		group: function() {},
		groupCollapsed: function() {},
		groupEnd: function() {},
		info: function() {},
		profile: function() {},
		profileEnd: function() {},
		time: function() {},
		timeEnd: function() {},
		trace: function() {},
		warn: function() {}
	};
	$(function() {
		window.globalStorage = {
			x: "x",
			BREAKPOINT_1_START: 320,
			BREAKPOINT_2_START: 768,
			BREAKPOINT_3_START: 1024,
			BREAKPOINT_4_START: 1440,
			getWinSize: function() {
				var t = window.innerWidth || screen.width;
				e.IS_MOBILE = t < e.BREAKPOINT_3_START;
				e.IS_TABLET = t >= e.BREAKPOINT_2_START && t < e.BREAKPOINT_3_START;
				e.IS_DESKTOP = t >= e.BREAKPOINT_3_START && t < e.BREAKPOINT_4_START;
				e.IS_WIDE = t >= e.BREAKPOINT_4_START
			},
			init: function() {
				e.getWinSize();
				$(window).resize(function() {
					e.getWinSize()
				})
			}
		};
		window.device = {};
		_user_agent = window.navigator.userAgent.toLowerCase();
		device.windows = function() {
			return _find("windows")
		};
		device.windowsTablet = function() {
			return device.windows() && _find("touch")
		};
		device.tablet = function() {
			return device.windowsTablet()
		};
		_find = function(e) {
			return _user_agent.indexOf(e) !== -1
		};
		var e = window.globalStorage = window.globalStorage || {};
		e.init();
		e.PopUp = function(t, i, c) {
			var n = false;
			e.PopUp.isAnyShown = true;
			this.initBaseControls = function() {
				setTimeout(function() {
					$(t).on("click", false, function(t) {
						$(this).blur();
						n = true;
						t.preventDefault();
						if (e.IS_MOBILE) {
							$(".b-popupFader").next().hide()
						} else {
							$(window).scrollTop(0)
						}
						setTimeout(function() {
							$(".p__body").css({
								WebkitBackfaceVisibility: "hidden"
							});
							$(".b-popupFader").show();
							$(i).show()
						}, 50)
					})
				}, 100);
				$(c, i).on("click", false, function(t) {
					n = false;
					t.preventDefault();
					$(i).hide();
					$(".p__body").css({
						WebkitBackfaceVisibility: "visible"
					});
					if (e.IS_MOBILE) {
						$(".b-popupFader").next().show()
					}
					$(".b-popupFader").hide()
				});
				$(".b-popupFader").on("click", function(t) {
					if (!e.IS_MOBILE && t.target.getAttribute("class") === "b-popupFader") {
						$(this).children().hide();
						$(this).hide()
					}
				});
				$(document).keyup(function(e) {
					if (e.keyCode == 27) {
						$(".b-popup-confirm").hide();
						$(".b-popupFader").children().hide();
						$(".b-popupFader").hide();
						n = false;
						$(".b-popupFader").next().show()
					}
				});
				$(window).on("resize", false, function(t) {
					if (n) {
						if (e.IS_DESKTOP || e.IS_WIDE) {
							$(".b-popupFader").next().show()
						} else if (e.IS_MOBILE) {
							$(".b-popupFader").next().hide()
						}
					}
					if (e.IS_MOBILE) {
						$(".b-popupFader").css("background", "#F5F5F5")
					} else {
						$(".b-popupFader").css("background", "rgba(0, 0, 0, 0.2)")
					}
				})
			}
		};
		$(".acc-header").click(function(i) {
			i.preventDefault();
			if ($(this).parent(".acc-section").hasClass("acc-mobile")) {
				if (e.IS_MOBILE) {
					t($(this))
				}
			} else if ($(this).parent(".acc-section").hasClass("acc-mobile-no-tablet")) {
				if (e.IS_MOBILE && !e.IS_TABLET) {
					t($(this))
				}
			} else {
				$(this).closest(".acc-section").toggleClass("acc-state_active");
				$(this).next().slideToggle("fast", function() {
					if ((navigator.userAgent.toLowerCase().indexOf("msie") > -1 || navigator.userAgent.toLowerCase().indexOf("trident/7.0") > -1) && !e.IS_MOBILE) {
						if ($(".b-popup-ask").css("display") === "block") {
							$(".popupScroll").css("background", "rgba(0, 0, 0, 0.19999)");
							setTimeout(function() {
								$(".popupScroll").css("background", "rgba(0, 0, 0, 0.2)")
							}, 1)
						}
					}
				})
			}
		}).filter("[data-anchor]").each(function() {
			var e = $(this),
				t = e.next(),
				i = e.data("anchor"),
				c = window.location.hash;
			if (c != "#" + i) {
				return
			}
			t.filter(":hidden").show();
			$(window).scrollTop(e.offset().top)
		});

		function t(t) {
			t.parent(".acc-section").toggleClass("acc-state_active");
			t.next().slideToggle("fast", function() {
				if ((navigator.userAgent.toLowerCase().indexOf("msie") > -1 || navigator.userAgent.toLowerCase().indexOf("trident/7.0") > -1) && e.IS_MOBILE) {
					if ($(".b-popup-ask").css("display") === "block") {
						$(".popupScroll").css("background", "#F5F5F4");
						setTimeout(function() {
							$(".popupScroll").css("background", "#F5F5F5")
						}, 1)
					}
				}
			})
		}
		$(window).resize(function() {
			if (e.IS_MOBILE) {
				$(".acc-mobile > .acc-subsection").hide();
				$(".acc-mobile-no-tablet > .acc-subsection").hide();
				$(".acc-state_active > .acc-subsection").show();
				if (e.IS_TABLET) {
					$(".acc-mobile-no-tablet > .acc-subsection").show()
				}
			} else {
				$(".acc-mobile > .acc-subsection").show();
				$(".acc-mobile-no-tablet > .acc-subsection").show()
			}
		});
		var i;
		if ($(".b-questions__show-all").length > 1) {
			i = $(".b-questions__show-all")[0].innerText
		} else {
			i = $(".b-questions__show-all").text()
		}
		var c = $(".b-questions__show-all").attr("data-title");
		$(".b-questions__show-all").click(function(e) {
			e.preventDefault();
			if ($(this).hasClass("acc-showAll_state_active")) {
				$(this).text(i);
				$(this).parent().next(".acc-wrapper").find(".acc-section").removeClass("acc-state_active");
				$(this).parent().next(".acc-wrapper").find(".acc-subsection").slideUp("fast");
				$(this).removeClass("acc-showAll_state_active")
			} else {
				$(this).text(c);
				$(this).parent().next(".acc-wrapper").find(".acc-section").addClass("acc-state_active");
				$(this).parent().next(".acc-wrapper").find(".acc-subsection").slideDown("fast");
				$(this).addClass("acc-showAll_state_active")
			}
		});
		var n = $(".radio-button__input");
		n.filter(":checked").each(function() {
			$(this).parent().addClass("radio-button__label-checked")
		});
		n.filter(":disabled").each(function() {
			$(this).parent().addClass("radio-button__label-disabled")
		});
		n.bind("click", function() {
			if ($(this).is(":disabled")) {
				return
			}
			$(this).closest(".radio-button-general").find(".radio-button__label").each(function() {
				$(this).removeClass("radio-button__label-checked")
			});
			$(this).parent().addClass("radio-button__label-checked")
		});
		var s = $(".checkbox__input");
		s.filter(":checked").each(function() {
			$(this).parent().addClass("checkbox__label-checked")
		});
		s.filter(":disabled").each(function() {
			$(this).parent().addClass("checkbox__label-disabled")
		});
		s.click(function() {
			switch (true) {
				case $(this).is(":disabled"):
					return;
				default:
					$(this).parent().toggleClass("checkbox__label-checked", $(this).is(":checked"))
			}
		});
		var a;
		(function() {
			a = navigator.userAgent.toLowerCase().indexOf("ipad") > -1 || navigator.userAgent.toLowerCase().indexOf("iphone") > -1 || navigator.userAgent.toLowerCase().indexOf("ipod") > -1 || navigator.userAgent.toLowerCase().indexOf("android") > -1
		})();
		var o = $(".select-block");
		var l = $(".select-block__selected-item");
		var r = "select-block-active";
		var d = $(".select-block__scroll");
		var u = $(".select-block__scroll-item");
		var f = true;
		var h = {
			add: function(e) {
				if (!a) {
					return
				}
				var t = $(e);
				t.each(function() {
					if ($(this).data("cs")) {
						return
					}
					var e = $(this).attr("id");
					if (!e) {
						e = "iscrollid_" + +new Date;
						$(this).attr("id", e)
					}
					var t = $('<div class="iScrollContent"></div>');
					$(this).find(">").appendTo(t);
					t.appendTo($(this));
					$(this).data("cs", new iScroll(e));
					var i = $(this).data("cs");
					i.csRefresh = function() {
						var e = $(this.scroller);
						var t = e.parent();
						var i = e.height();
						var c = t.css("maxHeight");
						if (c) {
							c = parseInt(c);
							if (i > c) {
								t.height(c)
							} else {
								t.height(i)
							}
						}
						this.refresh()
					}
				})
			}
		};
		h.add(".select-block__scroll");
		$(document).bind("touchend click scroll", function(e) {
			if (!$(e.target).hasClass("select-block") && !$(e.target).hasClass("select-block__scroll").length && !$(e.target).hasClass("select-block__scroll-item") && !$(e.target).hasClass("select-block__selected-item")) {
				$(".select-block").removeClass(r);
				d.hide()
			}
		});

		function p(e, t) {
			var i = $(e).next(".select-block__scroll"),
				c = i.find(".select-block__scroll-item");
			if (c.length == 1) {
				c.trigger("click");
				return
			}
			if (!i.is(":visible")) {
				$(".select-block").removeClass(r);
				d.hide()
			}
			$(e).parent().toggleClass(r);
			i.is(":visible") ? i.hide() : i.show()
		}
		if (a) {
			l.bind("touchend", function() {
				$("input, textarea").blur();
				p(this, "touchend");
				$(this).parent().find("> .select-block__scroll").data("cs").csRefresh()
			});
			u.bind("touchmove", function() {
				f = false
			});
			u.bind("touchend", function() {
				if (f) {
					var e = $(this).contents().filter(function() {
						return this.nodeType === 3
					}).text();
					var t = $(this).data("internal"),
						i = $(this).closest(".select-block");
					i.find(".select-block__selected-item").text(e).trigger("change", [t]);
					i.find(".select-block__fakescroll").val(e);
					d.hide();
					o.removeClass(r)
				}
				f = true
			})
		} else {
			l.bind("click", function() {
				p(this, "click scroll")
			});
			u.bind({
				mouseenter: function() {
					$(this).addClass("select-block__scroll-item-active")
				},
				mouseleave: function() {
					$(this).removeClass("select-block__scroll-item-active")
				},
				click: function() {
					var e = $(this).contents().filter(function() {
						return this.nodeType === 3
					}).text();
					var t = $(this).data("internal"),
						i = $(this).closest(".select-block");
					i.find(".select-block__selected-item").text(e).trigger("change", [t]);
					i.find(".select-block__fakescroll").val(e);
					d.hide();
					o.removeClass(r)
				}
			})
		}
		$(document).on("resize", function() {
			if (a) {
				d.hide();
				o.removeClass(r)
			}
		});
		e.placeholderInit = function(e, t) {
			$(e).attr("placeholder", t);
			var i = document.createElement("input");
			placeholderSupport = "placeholder" in i;
			if (!placeholderSupport) {
				$("[placeholder]").each(function() {
					var e = $(this);
					if (e.val() == "") {
						e.addClass("placeholder");
						e.val(e.attr("placeholder"))
					}
				});
				$("[placeholder]").focus(function() {
					var e = $(this);
					if (e.val() == e.attr("placeholder")) {
						e.val("");
						e.removeClass("placeholder")
					}
				}).blur(function() {
					var e = $(this);
					if (e.val() == "" || e.val() == e.attr("placeholder")) {
						e.addClass("placeholder");
						e.val(e.attr("placeholder"))
					}
				}).blur().parents("form").submit(function() {
					$(this).find("[placeholder]").each(function() {
						var e = $(this);
						if (e.val() == e.attr("placeholder")) {
							e.val("")
						}
					})
				})
			}
		}
	})
})();;
(function() {
	(function(e) {
		e.datePicker = {
			keyDateMap: {
				37: -1,
				38: -7,
				39: 1,
				40: 7
			},
			changeDate: function(e, t) {
				var a = new Date(e.getTime());
				a.setDate(a.getDate() + t);
				return a
			},
			setControlOnArrows: function(e, t) {
				var a = t.find(".ui-state-hover");
				if (a.length == 0) {
					a = t.find(".ui-state-active")
				}
				var i = t.datepicker("getDate");
				switch (e.keyCode) {
					case 37:
					case 38:
					case 39:
					case 40:
						e.preventDefault();
						t.datepicker("setDate", this.changeDate(i, this.keyDateMap[e.keyCode]));
						break;
					case 13:
						e.preventDefault();
						a.trigger("click");
						break
				}
			}
		}
	})(jQuery)
})();;
(function() {
	(function(e) {
		if (typeof define === "function" && define.amd) {
			define(["jquery"], e)
		} else {
			e(jQuery)
		}
	})(function(e) {
		var n = /\+/g;

		function i(e) {
			return c.raw ? e : encodeURIComponent(e)
		}

		function r(e) {
			return c.raw ? e : decodeURIComponent(e)
		}

		function o(e) {
			return i(c.json ? JSON.stringify(e) : String(e))
		}

		function t(e) {
			if (e.indexOf('"') === 0) {
				e = e.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\")
			}
			try {
				e = decodeURIComponent(e.replace(n, " "));
				return c.json ? JSON.parse(e) : e
			} catch (i) {}
		}

		function u(n, i) {
			var r = c.raw ? n : t(n);
			return e.isFunction(i) ? i(r) : r
		}
		var c = e.cookie = function(n, t, f) {
			if (t !== undefined && !e.isFunction(t)) {
				f = e.extend({}, c.defaults, f);
				if (typeof f.expires === "number") {
					var a = f.expires,
						d = f.expires = new Date;
					d.setDate(d.getDate() + a)
				}
				return document.cookie = [i(n), "=", o(t), f.expires ? "; expires=" + f.expires.toUTCString() : "", f.path ? "; path=" + f.path : "", f.domain ? "; domain=" + f.domain : "", f.secure ? "; secure" : ""].join("")
			}
			var s = n ? undefined : {};
			var p = document.cookie ? document.cookie.split("; ") : [];
			for (var m = 0, l = p.length; m < l; m++) {
				var v = p[m].split("=");
				var x = r(v.shift());
				var k = v.join("=");
				if (n && n === x) {
					s = u(k, t);
					break
				}
				if (!n && (k = u(k)) !== undefined) {
					s[x] = k
				}
			}
			return s
		};
		c.defaults = {};
		e.removeCookie = function(n, i) {
			if (e.cookie(n) === undefined) {
				return false
			}
			e.cookie(n, "", e.extend({}, i, {
				expires: -1
			}));
			return !e.cookie(n)
		}
	})
})();;
(function() {
	(function(e) {
		e.fn.supportsEvent = function(e) {
			var t = this.get(0).tagName,
				a = document.createElement(t),
				n;
			e = "on" + e;
			n = e in a;
			if (!n) {
				a.setAttribute(e, "return;");
				n = typeof a[e] == "function"
			}
			return n
		};
		var t = navigator.userAgent.toLowerCase().indexOf("mozilla/5.0") > -1 && navigator.userAgent.toLowerCase().indexOf("msie") > -1 && navigator.userAgent.toLowerCase().indexOf("iemobile") > -1;
		var a = window.orientation != null;
		var n = true;
		var s = document.createElement("input");
		var r = e(s).supportsEvent("paste") ? "paste" : "input";
		var l = "selectionStart" in s ? function(e) {
			return {
				start: e.selectionStart,
				end: e.selectionEnd,
				dir: e.selectionDirection || "none"
			}
		} : function(e) {
			var t = {
					start: 0,
					end: 0
				},
				a = document.selection.createRange(),
				n = a.text.length;
			a.moveStart("character", -e.value.length);
			t.end = a.text.length;
			t.start = t.end - n;
			return t
		};
		var h = s.setSelectionRange ? function(e, t, a, n) {
			e.setSelectionRange(t, a || t, n || "none")
		} : function(e, t, a) {
			var n = e.createTextRange();
			n.collapse();
			n.moveEnd("character", a || t);
			n.moveStart("character", t);
			n.select()
		};
		var u = function(t) {
			t = e.event.fix(t || window.event);
			var a = t.target,
				n = a.value,
				s = l(a);
			setTimeout(function() {
				var r = a.value,
					i = l(a),
					u = r.substr(s.start, i.end - s.start);
				a.value = n;
				h(a, s.start, s.end, s.dir);
				t = e.Event("paste");
				t.which = u;
				t.range = s;
				t.target = a;
				if (e.event.dispatch.call(a, t) !== false) {
					a.value = r;
					h(a, i.start, i.end, i.dir)
				}
			}, 1)
		};
		e.event.special.paste = {
			setup: function(e, t) {
				if (this.addEventListener) this.addEventListener(r, u, false);
				else if (this.attachEvent) this.attachEvent("on" + r, u);
				return true
			},
			teardown: function() {
				if (this.removeEventListener) this.removeEventListener(r, u, false);
				else if (this.detachEvent) this.detachEvent("on" + r, u);
				return true
			}
		};
		e.extend({
			mask: {
				rules: {
					z: /[a-z]/,
					Z: /[A-Z]/,
					a: /[a-zA-Z]/,
					"*": /[0-9a-zA-Z]/,
					"@": /[0-9a-zA-Zцїц?ц?ц?цёц?ц?ц?ц?цґц?цЁц?цЄц?ц?ц№ц?]/
				},
				keyRepresentation: {
					8: "backspace",
					9: "tab",
					13: "enter",
					16: "shift",
					17: "control",
					18: "alt",
					27: "esc",
					33: "page up",
					34: "page down",
					35: "end",
					36: "home",
					37: "left",
					38: "up",
					39: "right",
					40: "down",
					45: "insert",
					46: "delete",
					116: "f5",
					123: "f12",
					224: "command"
				},
				mobileKeyRepresentation: {
					8: "backspace",
					10: "go",
					127: "delete"
				},
				signals: {
					"+": "",
					"-": "-"
				},
				ignoreKeys: [],
				options: {
					attr: "alt",
					mask: null,
					type: "fixed",
					maxLength: -1,
					defaultValue: "",
					signal: false,
					textAlign: true,
					selectCharsOnFocus: true,
					autoTab: true,
					setSize: false,
					fixedChars: "[(),./: -]",
					onInvalid: function() {},
					onValid: function() {},
					onOverflow: function() {},
					onFocus: function(e, t) {},
					onBlur: function(e, t) {}
				},
				masks: {
					phone: {
						mask: "(99) 9999-9999"
					},
					"phone-us": {
						mask: "(999) 999-9999"
					},
					cpf: {
						mask: "999.999.999-99"
					},
					cnpj: {
						mask: "99.999.999/9999-99"
					},
					date: {
						mask: "39/19/9999"
					},
					"date-us": {
						mask: "19/39/9999"
					},
					cep: {
						mask: "99999-999"
					},
					time: {
						mask: "29:59"
					},
					cc: {
						mask: "9999 9999 9999 9999"
					},
					integer: {
						mask: "999.999.999.999",
						type: "reverse"
					},
					decimal: {
						mask: "99,999.999.999.999",
						type: "reverse",
						defaultValue: "000"
					},
					"decimal-us": {
						mask: "99.999,999,999,999",
						type: "reverse",
						defaultValue: "000"
					},
					"signed-decimal": {
						mask: "99,999.999.999.999",
						type: "reverse",
						defaultValue: "+000"
					},
					"signed-decimal-us": {
						mask: "99,999.999.999.999",
						type: "reverse",
						defaultValue: "+000"
					}
				},
				init: function() {
					if (!this.hasInit) {
						var t = this,
							n, s = a ? this.mobileKeyRepresentation : this.keyRepresentation;
						this.ignore = false;
						for (n = 0; n <= 9; n++) this.rules[n] = new RegExp("[0-" + n + "]");
						this.keyRep = s;
						e.each(s, function(e) {
							t.ignoreKeys.push(parseInt(e))
						});
						this.hasInit = true
					}
				},
				set: function(t, a) {
					var s = this,
						r = e(t),
						i = "maxLength";
					a = a || {};
					this.init();
					return r.each(function() {
						var t = e(this),
							r = e.extend({}, s.options),
							l = "",
							h;
						l = typeof a == "string" ? a : t.attr(a.attr || r.attr) || null;
						if (l) r.mask = l;
						if (s.masks[l]) r = e.extend(r, s.masks[l]);
						if (typeof a == "object" && a.constructor != Array) r = e.extend(r, a);
						if (e.metadata) r = e.extend(r, t.metadata());
						if (r.mask != null) {
							r.mask += "";
							if (t.data("mask")) s.unset(t);
							if (r.maxLength === -1) {
								r.maxLength = r.type == "repeat" ? t.attr(i) : r.mask.length
							}
							r = e.extend({}, r, {
								fixedCharsReg: new RegExp(r.fixedChars),
								fixedCharsRegG: new RegExp(r.fixedChars, "g"),
								maskArray: r.mask.split("")
							});
							if (r.type == "infinite") {
								r.type = "repeat"
							}
							if (r.setSize && !t.attr("size")) {
								switch (r.type) {
									case "fixed":
									case "reverse":
									case "plain":
										t.attr("size", r.mask.length);
										break;
									case "repeat":
										r.maxLength > 0 && t.attr("size", r.maxLength);
										break
								}
							}
							if (r.type == "reverse" && r.textAlign) {
								t.css("text-align", "right")
							}
							if (t.val() || r.defaultValue) {
								h = s.string(t.val() || r.defaultValue, r);
								t.attr("value", h).val(h)
							}
							t.data("mask", r).removeAttr(i).on("keydown.mask", {
								func: s._onKeyDown,
								maskObj: s
							}, s._onMask).on("keyup.mask", {
								func: s._onKeyUp,
								maskObj: s
							}, s._onMask).on("paste.mask", {
								func: s._onPaste,
								maskObj: s
							}, s._onMask).on("focus.mask", s._onFocus).on("blur.mask", s._onBlur).on("change.mask", s._onChange);
							if (n = t.supportsEvent("keypress")) {
								t.on("keypress.mask", {
									func: s._onKeyPress,
									maskObj: s
								}, s._onMask)
							}
						}
					})
				},
				unset: function(t) {
					var a = e(t);
					return a.each(function() {
						var t = e(this);
						if (t.data("mask")) {
							var a = t.data("mask").maxLength;
							if (a != -1) t.attr("maxLength", a);
							t.unbind(".mask").removeData("mask")
						}
					})
				},
				string: function(t, a) {
					this.init();
					var n = {},
						s, r;
					if (typeof t != "string") t = String(t);
					switch (typeof a) {
						case "string":
							if (this.masks[a]) n = e.extend(n, this.masks[a]);
							else n.mask = a;
							break;
						case "object":
							n = a
					}
					n.fixedChars = n.fixedChars || this.options.fixedChars;
					s = new RegExp(n.fixedChars);
					r = new RegExp(n.fixedChars, "g");
					if (n.type === "reverse" && n.defaultValue) {
						if (typeof this.signals[n.defaultValue.charAt(0)] != "undefined") {
							var i = t.charAt(0);
							n.signal = typeof this.signals[i] != "undefined" ? this.signals[i] : this.signals[n.defaultValue.charAt(0)];
							n.defaultValue = n.defaultValue.substring(1)
						}
					}
					return this.__maskInsert(t, "", n.mask, n.type, n.maxLength, n.fixedChars)
				},
				_onFocus: function(t) {
					var a = e(this),
						n = a.data("mask");
					n.inputFocusValue = a.val();
					n.changed = false;
					if (n.selectCharsOnFocus) a.select();
					n.onFocus(this, t)
				},
				_onBlur: function(t) {
					var a = e(this),
						n = a.data("mask");
					if (n.inputFocusValue != a.val() && !n.changed) a.trigger("change");
					n.onBlur(this, t)
				},
				_onChange: function(t) {
					e(this).data("mask").changed = true
				},
				_onMask: function(t) {
					var a = t.data.maskObj,
						n = {},
						s;
					n._this = t.target;
					n.$this = e(n._this);
					n.data = n.$this.data("mask");
					n[n.data.type] = true;
					n.value = n.$this.val();
					n.nKey = a.__getKeyNumber(t);
					n.nKeyName = a.keyRep[n.nKey] || "";
					n.range = a.__getRange(n._this);
					n.valueArray = n.value.split("");
					s = t.data.func.call(a, t, n);
					if (!s) {
						t.preventDefault()
					}
					return s
				},
				_onKeyDown: function(t, a) {
					this.ignore = e.inArray(a.nKey, this.ignoreKeys) > -1 || t.ctrlKey || t.metaKey || t.altKey;
					if (this.ignore) {
						var s = this.keyRep[a.nKey];
						a.data.onValid.call(a._this, s || "", a.nKey)
					}
					var r = false;
					switch (a.nKeyName) {
						case "backspace":
							r = this.__maskRemove(a.value, a.data.mask, a.data.type, a.data.fixedChars, a.range, true);
							break;
						case "delete":
							r = this.__maskRemove(a.value, a.data.mask, a.data.type, a.data.fixedChars, a.range);
							break
					}
					if (r !== false) {
						a.$this.val(r);
						this.__setRange(a._this, a.range.start, a.range.end, a.range.dir);
						return false
					}
					this.__setRange(a._this, a.range.start, a.range.end, a.range.dir);
					return n || this._onKeyPress(t, a)
				},
				_onKeyUp: function(e, a) {
					if (t) {
						if (this.ignore) return true;
						if (a.reverse) this.__changeSignal(e.type, a);
						var n = String.fromCharCode(a.nKey);
						$thisVal = this.__maskInsert(a.value, n, a.data.mask, a.data.type, a.data.maxLength, a.data.fixedChars, a.range);
						if ($thisVal !== false) {
							a.$this.val($thisVal);
							this.__setRange(a._this, a.range.end, a.range.end)
						}
						return false
					} else {
						return true
					}
				},
				_onPaste: function(e, t) {
					if (t.reverse) this.__changeSignal(e.type, t);
					$thisVal = this.__maskInsert(t.value, e.which, t.data.mask, t.data.type, t.maxLength, t.data.fixedChars, t.range);
					if ($thisVal !== false) {
						t.$this.val($thisVal);
						this.__setRange(t._this, t.range.end, t.range.end, t.range.dir);
						this.__autoTab(t)
					} else {
						t.$this.val(t.value);
						this.__setRange(t._this, t.range.end, t.range.end, t.range.dir)
					}
					return false
				},
				_onKeyPress: function(e, t) {
					if (this.ignore) return true;
					if (t.reverse) this.__changeSignal(e.type, t);
					var a = String.fromCharCode(t.nKey);
					$thisVal = this.__maskInsert(t.value, a, t.data.mask, t.data.type, t.data.maxLength, t.data.fixedChars, t.range);
					if ($thisVal !== false) {
						t.$this.val($thisVal);
						this.__setRange(t._this, t.range.end, t.range.end)
					}
					return false
				},
				__autoTab: function(e) {
					if (e.data.autoTab && (e.$this.val().length >= e.data.maskArray.length && !e.repeat || e.data.maxLength != -1 && e.valueArray.length >= e.data.maxLength && e.repeat)) {
						var t = this.__getNextInput(e._this, e.data.autoTab);
						if (t) {
							e.$this.trigger("blur");
							t.focus().select()
						}
					}
				},
				__changeSignal: function(e, t) {
					if (t.data.signal !== false) {
						var a = e === "paste" ? t.value.charAt(0) : String.fromCharCode(t.nKey);
						if (this.signals && typeof this.signals[a] !== "undefined") {
							t.data.signal = this.signals[a]
						}
					}
				},
				__getKeyNumber: function(e) {
					return e.charCode || e.keyCode || e.which
				},
				__maskRemove: function(e, t, a, n, s, r) {
					var l = e.split(""),
						h = t.split(""),
						u = s ? s.start + 0 : t.length,
						o = s ? s.end + 0 : t.length,
						f = n || this.options.fixedChars,
						g = new RegExp(f),
						d, c;
					if (a == "reverse") {
						l.reverse();
						i = u;
						u = e.length - o;
						o = e.length - i
					}
					if (o == u) {
						do {
							null;
							c = a == "reverse" == !!r ? o++ : --u;
							if (c < 0 || c > l.length) {
								return false
							}
							d = l[c]
						} while (g.test(d))
					}
					if (a == "reverse") {
						l.reverse();
						i = u;
						u = e.length - o;
						o = e.length - i
					}
					s.start = u;
					s.end = o;
					return this.__maskInsert(l.join(""), "", t, a, 0, n, s)
				},
				__maskInsert: function(e, t, a, n, s, r, i, l, h, u) {
					var o = e.split(""),
						f = a.split(""),
						g = (t || "").split(""),
						d = [],
						c = i ? i.start + 0 : e.length,
						m = i ? i.end + 0 : e.length,
						v = r || this.options.fixedChars,
						p = new RegExp(v),
						k, _, y, x;
					(!s || s < 0) && (s = 0);
					n != "repeat" && (s = a.length);
					switch (n) {
						case "reverse":
							o.reverse();
							g.reverse();
							y = c;
							c = e.length - m;
							m = e.length - y;
						default:
							o = [].concat(o.slice(0, c), g, o.slice(m));
							break;
						case "fixed":
							o = [].concat(o.slice(0, c), g, o.slice(c + textArray.length));
							break
					}
					if (n != "reverse") {
						c = m = c + g.length
					} else {
						m = c
					}
					for (y = o.length - 1; y > 0 && p.test(o[y]); y--) {
						o.pop()
					}
					for (y = 0, x = 0; y <= o.length && x < f.length; y++, x++) {
						if (n == "repeat") {
							x %= f.length
						}
						_ = o[y] || "";
						k = f[x];
						switch (true) {
							default:
							case p.test(k):
								c >= d.length && c++;
								m >= d.length && m++;
								d.push(k);
								y--;
								break;
							case !!this.rules[k]:
								if (this.rules[k].test(_)) {
									d.push(_)
								} else {
									c > d.length && c--;
									m > d.length && m--;
									x--
								}
								break
						}
					}
					if (s && d.length + o.length - y > s) {
						typeof u == "function" && u(text);
						return false
					}
					if (n == "reverse") {
						d.reverse();
						while (p.test(d[0])) {
							d.shift()
						}
						y = c;
						c = d.length - m;
						m = d.length - y
					}
					while (d[c] && p.test(d[c])) {
						c++;
						m++
					}
					if (i) {
						i.start = c;
						i.end = m
					}
					return d.join("")
				},
				__getNextInput: function(t, a) {
					var n = t.form;
					if (n == null) {
						return null
					}
					var s = n.elements,
						r = e.inArray(t, s) + 1,
						i = s.length,
						l = null,
						h;
					for (h = r; h < i; h++) {
						l = e(s[h]);
						if (this.__isNextInput(l, a)) {
							return l
						}
					}
					var u = document.forms,
						o = e.inArray(t.form, u) + 1,
						f, g, d = u.length;
					for (f = o; f < d; f++) {
						g = u[f].elements;
						i = g.length;
						for (h = 0; h < i; h++) {
							l = e(g[h]);
							if (this.__isNextInput(l, a)) {
								return l
							}
						}
					}
					return null
				},
				__isNextInput: function(e, t) {
					var a = e.get(0);
					return a && (a.offsetWidth > 0 || a.offsetHeight > 0) && a.nodeName != "FIELDSET" && (t === true || typeof t == "string" && e.is(t))
				},
				__setRange: function(e, t, a, n) {
					h(e, t, a, n)
				},
				__getRange: function(e) {
					return l(e)
				},
				unmaskedVal: function(t) {
					return e(t).val().replace(e.mask.fixedCharsRegG, "")
				}
			}
		});
		e.fn.extend({
			setMask: function(t) {
				return e.mask.set(this, t)
			},
			unsetMask: function() {
				return e.mask.unset(this)
			},
			unmaskedVal: function() {
				return e.mask.unmaskedVal(this[0])
			}
		})
	})(jQuery)
})();;
(function() {
	(function(e) {
		var i = "iCheck",
			t = i + "-helper",
			s = "checkbox",
			a = "radio",
			n = "checked",
			r = "un" + n,
			o = "disabled",
			f = "determinate",
			l = "in" + f,
			c = "update",
			d = "type",
			u = "click",
			h = "touchbegin.i touchend.i",
			p = "addClass",
			v = "removeClass",
			b = "trigger",
			g = "label",
			m = "cursor",
			k = /ipad|iphone|ipod|android|blackberry|windows phone|opera mini|silk/i.test(navigator.userAgent);
		e.fn[i] = function(r, f) {
			var m = ":" + s + ", :" + a,
				A = e(),
				H = function(i) {
					i.each(function() {
						var i = e(this);
						if (i.is(m)) {
							A = A.add(i)
						} else {
							A = A.add(i.find(m))
						}
					})
				};
			if (/^(check|uncheck|toggle|indeterminate|determinate|disable|enable|update|destroy)$/i.test(r)) {
				r = r.toLowerCase();
				H(this);
				return A.each(function() {
					if (r == "destroy") {
						x(this, "ifDestroyed")
					} else {
						C(e(this), true, r)
					} if (e.isFunction(f)) {
						f()
					}
				})
			} else if (typeof r == "object" || !r) {
				var T = e.extend({
						checkedClass: n,
						disabledClass: o,
						indeterminateClass: l,
						labelHover: true
					}, r),
					j = T.handle,
					D = T.hoverClass || "controls-state-hover",
					P = T.focusClass || "controls-state-focus",
					F = T.activeClass || "controls-state-active",
					I = !!T.labelHover,
					L = T.labelHoverClass || "hover",
					N = ("" + T.increaseArea).replace("%", "") | 0;
				if (j == s || j == a) {
					m = ":" + j
				}
				if (N < -50) {
					N = -50
				}
				H(this);
				return A.each(function() {
					x(this);
					var r = e(this),
						f = this,
						l = f.id,
						m = -N + "%",
						A = 100 + N * 2 + "%",
						H = {
							position: "absolute",
							top: m,
							left: m,
							display: "block",
							width: A,
							height: A,
							margin: 0,
							padding: 0,
							background: "#fff",
							border: 0,
							opacity: 0
						},
						j = k ? {
							position: "absolute",
							visibility: "hidden"
						} : N ? H : {
							position: "absolute",
							opacity: 0
						},
						Q = f[d] == s ? T.checkboxClass || "i" + s : T.radioClass || "i" + a,
						U = e(g + '[for="' + l + '"]').add(r.closest(g)),
						$ = r.wrap('<div class="' + Q + '"/>')[b]("ifCreated").parent().append(T.insert),
						q = e('<ins class="' + t + '"/>').css(H).appendTo($);
					r.data(i, {
						o: T,
						s: r.attr("style")
					}).css(j);
					!!T.inheritClass && $[p](f.className);
					!!T.inheritID && l && $.attr("id", i + "-" + l);
					$.css("position") == "static" && $.css("position", "relative");
					C(r, true, c);
					if (U.length) {
						U.on(u + ".i mouseenter.i mouseleave.i " + h, function(i) {
							var t = i[d],
								s = e(this);
							if (!f[o]) {
								if (t == u) {
									C(r, false, true)
								} else if (I) {
									if (/ve|nd/.test(t)) {
										$[v](D);
										s[v](L)
									} else {
										$[p](D);
										s[p](L)
									}
								}
								if (k) {
									i.stopPropagation()
								} else {
									return false
								}
							}
						})
					}
					r.on(u + ".i focus.i blur.i keyup.i keydown.i keypress.i", function(e) {
						var i = e[d],
							t = e.keyCode;
						if (i == u) {
							return false
						} else if (i == "keydown" && t == 32) {
							if (!(f[d] == a && f[n])) {
								if (f[n]) {
									w(r, n)
								} else {
									y(r, n)
								}
							}
							return false
						} else if (i == "keyup" && f[d] == a) {
							!f[n] && y(r, n)
						} else if (/us|ur/.test(i)) {
							$[i == "blur" ? v : p](P)
						}
					});
					q.on(u + " mousedown mouseup mouseover mouseout " + h, function(e) {
						var i = e[d],
							t = /wn|up/.test(i) ? F : D;
						if (!f[o]) {
							if (i == u) {
								C(r, false, true)
							} else {
								if (/wn|er|in/.test(i)) {
									$[p](t)
								} else {
									$[v](t + " " + F)
								} if (U.length && I && t == D) {
									U[/ut|nd/.test(i) ? v : p](L)
								}
							} if (k) {
								e.stopPropagation()
							} else {
								return false
							}
						}
					})
				})
			} else {
				return this
			}
		};

		function C(e, i, t) {
			var s = e[0];
			r = /er/.test(t) ? l : /bl/.test(t) ? o : n, active = t == c ? {
				checked: s[n],
				disabled: s[o],
				indeterminate: e.attr(l) == "true" || e.attr(f) == "false"
			} : s[r];
			if (/^(ch|di|in)/.test(t) && !active) {
				y(e, r)
			} else if (/^(un|en|de)/.test(t) && active) {
				w(e, r)
			} else if (t == c) {
				for (var r in active) {
					if (active[r]) {
						y(e, r, true)
					} else {
						w(e, r, true)
					}
				}
			} else if (!i || t == "toggle") {
				setTimeout(function() {
					if (!i) {
						e[b]("ifClicked")
					}
					if (active) {
						if (s[d] !== a) {
							w(e, r)
						}
					} else {
						y(e, r)
					}
				}, 10)
			}
		}

		function y(s, c, u) {
			var h = s[0],
				b = s.parent(),
				g = c == n,
				k = c == l,
				C = k ? f : g ? r : "enabled",
				y = A(h, C + H(h[d])),
				x = A(h, c + H(h[d]));
			if (h[c] !== true) {
				if (!u && c == n && h[d] == a && h.name) {
					var j = s.closest("form"),
						D = 'input[name="' + h.name + '"]';
					D = j.length ? j.find(D) : e(D);
					D.each(function() {
						if (this !== h && e.data(this, i)) {
							w(e(this), c)
						}
					})
				}
				if (k) {
					h[c] = true;
					if (h[n]) {
						w(s, n, "force")
					}
				} else {
					if (!u) {
						h[c] = true
					}
					if (g && h[l]) {
						w(s, l, false)
					}
				}
				T(s, g, c, u)
			}
			if (h[o] && !!A(h, m, true)) {
				b.find("." + t).css(m, "default")
			}
			b[p](x || A(h, c));
			b[v](y || A(h, C) || "")
		}

		function w(e, i, s) {
			var a = e[0],
				c = e.parent(),
				u = i == n,
				h = i == l,
				b = h ? f : u ? r : "enabled",
				g = A(a, b + H(a[d])),
				k = A(a, i + H(a[d]));
			if (a[i] !== false) {
				if (h || !s || s == "force") {
					a[i] = false
				}
				T(e, u, b, s)
			}
			if (!a[o] && !!A(a, m, true)) {
				c.find("." + t).css(m, "pointer")
			}
			c[v](k || A(a, i) || "");
			c[p](g || A(a, b))
		}

		function x(t, s) {
			if (e.data(t, i)) {
				var a = e(t);
				a.parent().html(a.attr("style", e.data(t, i).s || "")[b](s || ""));
				a.off(".i").unwrap();
				e(g + '[for="' + t.id + '"]').add(a.closest(g)).off(".i")
			}
		}

		function A(t, s, a) {
			if (e.data(t, i)) {
				return e.data(t, i).o[s + (a ? "" : "Class")]
			}
		}

		function H(e) {
			return e.charAt(0).toUpperCase() + e.slice(1)
		}

		function T(e, i, t, s) {
			if (!s) {
				if (i) {
					e[b]("ifToggled")
				}
				e[b]("ifChanged")[b]("if" + H(t))
			}
		}
	})(jQuery)
})();;
(function() {
	(function(o, e) {
		var t = Math,
			r = e.createElement("div").style,
			l = function() {
				var o = "t,webkitT,MozT,msT,OT".split(","),
					e, t = 0,
					l = o.length;
				for (; t < l; t++) {
					e = o[t] + "ransform";
					if (e in r) {
						return o[t].substr(0, o[t].length - 1)
					}
				}
				return false
			}(),
			i = l ? "-" + l.toLowerCase() + "-" : "",
			s = E("transform"),
			n = E("transitionProperty"),
			a = E("transitionDuration"),
			c = E("transformOrigin"),
			p = E("transitionTimingFunction"),
			f = E("transitionDelay"),
			u = /android/gi.test(navigator.appVersion),
			m = /iphone|ipad/gi.test(navigator.appVersion),
			h = /hp-tablet/gi.test(navigator.appVersion),
			S = E("perspective") in r,
			d = "ontouchstart" in o && !h,
			b = l !== false,
			x = E("transition") in r,
			g = "onorientationchange" in o ? "orientationchange" : "resize",
			y = d ? "touchstart" : "mousedown",
			Y = d ? "touchmove" : "mousemove",
			v = d ? "touchend" : "mouseup",
			T = d ? "touchcancel" : "mouseup",
			X = function() {
				if (l === false) return false;
				var o = {
					"": "transitionend",
					webkit: "webkitTransitionEnd",
					Moz: "transitionend",
					O: "otransitionend",
					ms: "MSTransitionEnd"
				};
				return o[l]
			}(),
			w = function() {
				return o.requestAnimationFrame || o.webkitRequestAnimationFrame || o.mozRequestAnimationFrame || o.oRequestAnimationFrame || o.msRequestAnimationFrame || function(o) {
					return setTimeout(o, 1)
				}
			}(),
			_ = function() {
				return o.cancelRequestAnimationFrame || o.webkitCancelAnimationFrame || o.webkitCancelRequestAnimationFrame || o.mozCancelRequestAnimationFrame || o.oCancelRequestAnimationFrame || o.msCancelRequestAnimationFrame || clearTimeout
			}(),
			z = S ? " translateZ(0)" : "",
			M = function(t, r) {
				var l = this,
					f;
				l.wrapper = typeof t == "object" ? t : e.getElementById(t);
				l.wrapper.style.overflow = "hidden";
				l.scroller = l.wrapper.children[0];
				l.options = {
					hScroll: true,
					vScroll: true,
					x: 0,
					y: 0,
					bounce: true,
					bounceLock: false,
					momentum: true,
					lockDirection: true,
					useTransform: true,
					useTransition: false,
					topOffset: 0,
					checkDOMChanges: false,
					handleClick: true,
					hScrollbar: true,
					vScrollbar: true,
					fixedScrollbar: u,
					hideScrollbar: m,
					fadeScrollbar: m && S,
					scrollbarClass: "",
					zoom: false,
					zoomMin: 1,
					zoomMax: 4,
					doubleTapZoom: 2,
					wheelAction: "scroll",
					snap: false,
					snapThreshold: 1,
					onRefresh: null,
					onBeforeScrollStart: function(o) {
						o.preventDefault()
					},
					onScrollStart: null,
					onBeforeScrollMove: null,
					onScrollMove: null,
					onBeforeScrollEnd: null,
					onScrollEnd: null,
					onTouchEnd: null,
					onDestroy: null,
					onZoomStart: null,
					onZoom: null,
					onZoomEnd: null
				};
				for (f in r) l.options[f] = r[f];
				l.x = l.options.x;
				l.y = l.options.y;
				l.options.useTransform = b && l.options.useTransform;
				l.options.hScrollbar = l.options.hScroll && l.options.hScrollbar;
				l.options.vScrollbar = l.options.vScroll && l.options.vScrollbar;
				l.options.zoom = l.options.useTransform && l.options.zoom;
				l.options.useTransition = x && l.options.useTransition;
				if (l.options.zoom && u) {
					z = ""
				}
				l.scroller.style[n] = l.options.useTransform ? i + "transform" : "top left";
				l.scroller.style[a] = "0";
				l.scroller.style[c] = "0 0";
				if (l.options.useTransition) l.scroller.style[p] = "cubic-bezier(0.33,0.66,0.66,1)";
				if (l.options.useTransform) l.scroller.style[s] = "translate(" + l.x + "px," + l.y + "px)" + z;
				else l.scroller.style.cssText += ";position:absolute;top:" + l.y + "px;left:" + l.x + "px"; if (l.options.useTransition) l.options.fixedScrollbar = true;
				l.refresh();
				l._bind(g, o);
				l._bind(y);
				if (!d) {
					if (l.options.wheelAction != "none") {
						l._bind("DOMMouseScroll");
						l._bind("mousewheel")
					}
				}
				if (l.options.checkDOMChanges) l.checkDOMTime = setInterval(function() {
					l._checkDOMChanges()
				}, 500)
			};
		M.prototype = {
			enabled: true,
			x: 0,
			y: 0,
			steps: [],
			scale: 1,
			currPageX: 0,
			currPageY: 0,
			pagesX: [],
			pagesY: [],
			aniTime: null,
			wheelZoomCount: 0,
			handleEvent: function(o) {
				var e = this;
				switch (o.type) {
					case y:
						if (!d && o.button !== 0) return;
						e._start(o);
						break;
					case Y:
						e._move(o);
						break;
					case v:
					case T:
						e._end(o);
						break;
					case g:
						e._resize();
						break;
					case "DOMMouseScroll":
					case "mousewheel":
						e._wheel(o);
						break;
					case X:
						e._transitionEnd(o);
						break
				}
			},
			_checkDOMChanges: function() {
				if (this.moved || this.zoomed || this.animating || this.scrollerW == this.scroller.offsetWidth * this.scale && this.scrollerH == this.scroller.offsetHeight * this.scale) return;
				this.refresh()
			},
			_scrollbar: function(o) {
				var r = this,
					l;
				if (!r[o + "Scrollbar"]) {
					if (r[o + "ScrollbarWrapper"]) {
						if (b) r[o + "ScrollbarIndicator"].style[s] = "";
						r[o + "ScrollbarWrapper"].parentNode.removeChild(r[o + "ScrollbarWrapper"]);
						r[o + "ScrollbarWrapper"] = null;
						r[o + "ScrollbarIndicator"] = null
					}
					return
				}
				if (!r[o + "ScrollbarWrapper"]) {
					l = e.createElement("div");
					if (r.options.scrollbarClass) l.className = r.options.scrollbarClass + o.toUpperCase();
					else l.style.cssText = "position:absolute;z-index:100;" + (o == "h" ? "height:7px;bottom:1px;left:2px;right:" + (r.vScrollbar ? "7" : "2") + "px" : "width:7px;bottom:" + (r.hScrollbar ? "7" : "2") + "px;top:2px;right:1px");
					l.style.cssText += ";pointer-events:none;" + i + "transition-property:opacity;" + i + "transition-duration:" + (r.options.fadeScrollbar ? "350ms" : "0") + ";overflow:hidden;opacity:" + (r.options.hideScrollbar ? "0" : "1");
					r.wrapper.appendChild(l);
					r[o + "ScrollbarWrapper"] = l;
					l = e.createElement("div");
					if (!r.options.scrollbarClass) {
						l.style.cssText = "position:absolute;z-index:100;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.9);" + i + "background-clip:padding-box;" + i + "box-sizing:border-box;" + (o == "h" ? "height:100%" : "width:100%") + ";" + i + "border-radius:3px;border-radius:3px"
					}
					l.style.cssText += ";pointer-events:none;" + i + "transition-property:" + i + "transform;" + i + "transition-timing-function:cubic-bezier(0.33,0.66,0.66,1);" + i + "transition-duration:0;" + i + "transform: translate(0,0)" + z;
					if (r.options.useTransition) l.style.cssText += ";" + i + "transition-timing-function:cubic-bezier(0.33,0.66,0.66,1)";
					r[o + "ScrollbarWrapper"].appendChild(l);
					r[o + "ScrollbarIndicator"] = l
				}
				if (o == "h") {
					r.hScrollbarSize = r.hScrollbarWrapper.clientWidth;
					r.hScrollbarIndicatorSize = t.max(t.round(r.hScrollbarSize * r.hScrollbarSize / r.scrollerW), 8);
					r.hScrollbarIndicator.style.width = r.hScrollbarIndicatorSize + "px";
					r.hScrollbarMaxScroll = r.hScrollbarSize - r.hScrollbarIndicatorSize;
					r.hScrollbarProp = r.hScrollbarMaxScroll / r.maxScrollX
				} else {
					r.vScrollbarSize = r.vScrollbarWrapper.clientHeight;
					r.vScrollbarIndicatorSize = t.max(t.round(r.vScrollbarSize * r.vScrollbarSize / r.scrollerH), 8);
					r.vScrollbarIndicator.style.height = r.vScrollbarIndicatorSize + "px";
					r.vScrollbarMaxScroll = r.vScrollbarSize - r.vScrollbarIndicatorSize;
					r.vScrollbarProp = r.vScrollbarMaxScroll / r.maxScrollY
				}
				r._scrollbarPos(o, true)
			},
			_resize: function() {
				var o = this;
				setTimeout(function() {
					o.refresh()
				}, u ? 200 : 0)
			},
			_pos: function(o, e) {
				if (this.zoomed) return;
				o = this.hScroll ? o : 0;
				e = this.vScroll ? e : 0;
				if (this.options.useTransform) {
					this.scroller.style[s] = "translate(" + o + "px," + e + "px) scale(" + this.scale + ")" + z
				} else {
					o = t.round(o);
					e = t.round(e);
					this.scroller.style.left = o + "px";
					this.scroller.style.top = e + "px"
				}
				this.x = o;
				this.y = e;
				this._scrollbarPos("h");
				this._scrollbarPos("v")
			},
			_scrollbarPos: function(o, e) {
				var r = this,
					l = o == "h" ? r.x : r.y,
					i;
				if (!r[o + "Scrollbar"]) return;
				l = r[o + "ScrollbarProp"] * l;
				if (l < 0) {
					if (!r.options.fixedScrollbar) {
						i = r[o + "ScrollbarIndicatorSize"] + t.round(l * 3);
						if (i < 8) i = 8;
						r[o + "ScrollbarIndicator"].style[o == "h" ? "width" : "height"] = i + "px"
					}
					l = 0
				} else if (l > r[o + "ScrollbarMaxScroll"]) {
					if (!r.options.fixedScrollbar) {
						i = r[o + "ScrollbarIndicatorSize"] - t.round((l - r[o + "ScrollbarMaxScroll"]) * 3);
						if (i < 8) i = 8;
						r[o + "ScrollbarIndicator"].style[o == "h" ? "width" : "height"] = i + "px";
						l = r[o + "ScrollbarMaxScroll"] + (r[o + "ScrollbarIndicatorSize"] - i)
					} else {
						l = r[o + "ScrollbarMaxScroll"]
					}
				}
				r[o + "ScrollbarWrapper"].style[f] = "0";
				r[o + "ScrollbarWrapper"].style.opacity = e && r.options.hideScrollbar ? "0" : "1";
				r[o + "ScrollbarIndicator"].style[s] = "translate(" + (o == "h" ? l + "px,0)" : "0," + l + "px)") + z
			},
			_start: function(e) {
				var r = this,
					l = d ? e.touches[0] : e,
					i, n, a, c, p;
				if (!r.enabled) return;
				if (r.options.onBeforeScrollStart) r.options.onBeforeScrollStart.call(r, e);
				if (r.options.useTransition || r.options.zoom) r._transitionTime(0);
				r.moved = false;
				r.animating = false;
				r.zoomed = false;
				r.distX = 0;
				r.distY = 0;
				r.absDistX = 0;
				r.absDistY = 0;
				r.dirX = 0;
				r.dirY = 0;
				if (r.options.zoom && d && e.touches.length > 1) {
					c = t.abs(e.touches[0].pageX - e.touches[1].pageX);
					p = t.abs(e.touches[0].pageY - e.touches[1].pageY);
					r.touchesDistStart = t.sqrt(c * c + p * p);
					r.originX = t.abs(e.touches[0].pageX + e.touches[1].pageX - r.wrapperOffsetLeft * 2) / 2 - r.x;
					r.originY = t.abs(e.touches[0].pageY + e.touches[1].pageY - r.wrapperOffsetTop * 2) / 2 - r.y;
					if (r.options.onZoomStart) r.options.onZoomStart.call(r, e)
				}
				if (r.options.momentum) {
					if (r.options.useTransform) {
						i = getComputedStyle(r.scroller, null)[s].replace(/[^0-9\-.,]/g, "").split(",");
						n = +(i[12] || i[4]);
						a = +(i[13] || i[5])
					} else {
						n = +getComputedStyle(r.scroller, null).left.replace(/[^0-9-]/g, "");
						a = +getComputedStyle(r.scroller, null).top.replace(/[^0-9-]/g, "")
					} if (n != r.x || a != r.y) {
						if (r.options.useTransition) r._unbind(X);
						else _(r.aniTime);
						r.steps = [];
						r._pos(n, a);
						if (r.options.onScrollEnd) r.options.onScrollEnd.call(r)
					}
				}
				r.absStartX = r.x;
				r.absStartY = r.y;
				r.startX = r.x;
				r.startY = r.y;
				r.pointX = l.pageX;
				r.pointY = l.pageY;
				r.startTime = e.timeStamp || Date.now();
				if (r.options.onScrollStart) r.options.onScrollStart.call(r, e);
				r._bind(Y, o);
				r._bind(v, o);
				r._bind(T, o)
			},
			_move: function(o) {
				var e = this,
					r = d ? o.touches[0] : o,
					l = r.pageX - e.pointX,
					i = r.pageY - e.pointY,
					n = e.x + l,
					a = e.y + i,
					c, p, f, u = o.timeStamp || Date.now();
				if (e.options.onBeforeScrollMove) e.options.onBeforeScrollMove.call(e, o);
				if (e.options.zoom && d && o.touches.length > 1) {
					c = t.abs(o.touches[0].pageX - o.touches[1].pageX);
					p = t.abs(o.touches[0].pageY - o.touches[1].pageY);
					e.touchesDist = t.sqrt(c * c + p * p);
					e.zoomed = true;
					f = 1 / e.touchesDistStart * e.touchesDist * this.scale;
					if (f < e.options.zoomMin) f = .5 * e.options.zoomMin * Math.pow(2, f / e.options.zoomMin);
					else if (f > e.options.zoomMax) f = 2 * e.options.zoomMax * Math.pow(.5, e.options.zoomMax / f);
					e.lastScale = f / this.scale;
					n = this.originX - this.originX * e.lastScale + this.x;
					a = this.originY - this.originY * e.lastScale + this.y;
					this.scroller.style[s] = "translate(" + n + "px," + a + "px) scale(" + f + ")" + z;
					if (e.options.onZoom) e.options.onZoom.call(e, o);
					return
				}
				e.pointX = r.pageX;
				e.pointY = r.pageY;
				if (n > 0 || n < e.maxScrollX) {
					n = e.options.bounce ? e.x + l / 2 : n >= 0 || e.maxScrollX >= 0 ? 0 : e.maxScrollX
				}
				if (a > e.minScrollY || a < e.maxScrollY) {
					a = e.options.bounce ? e.y + i / 2 : a >= e.minScrollY || e.maxScrollY >= 0 ? e.minScrollY : e.maxScrollY
				}
				e.distX += l;
				e.distY += i;
				e.absDistX = t.abs(e.distX);
				e.absDistY = t.abs(e.distY);
				if (e.absDistX < 6 && e.absDistY < 6) {
					return
				}
				if (e.options.lockDirection) {
					if (e.absDistX > e.absDistY + 5) {
						a = e.y;
						i = 0
					} else if (e.absDistY > e.absDistX + 5) {
						n = e.x;
						l = 0
					}
				}
				e.moved = true;
				e._pos(n, a);
				e.dirX = l > 0 ? -1 : l < 0 ? 1 : 0;
				e.dirY = i > 0 ? -1 : i < 0 ? 1 : 0;
				if (u - e.startTime > 300) {
					e.startTime = u;
					e.startX = e.x;
					e.startY = e.y
				}
				if (e.options.onScrollMove) e.options.onScrollMove.call(e, o)
			},
			_end: function(r) {
				if (d && r.touches.length !== 0) return;
				var l = this,
					i = d ? r.changedTouches[0] : r,
					n, c, p = {
						dist: 0,
						time: 0
					},
					f = {
						dist: 0,
						time: 0
					},
					u = (r.timeStamp || Date.now()) - l.startTime,
					m = l.x,
					h = l.y,
					S, b, x, g, y;
				l._unbind(Y, o);
				l._unbind(v, o);
				l._unbind(T, o);
				if (l.options.onBeforeScrollEnd) l.options.onBeforeScrollEnd.call(l, r);
				if (l.zoomed) {
					y = l.scale * l.lastScale;
					y = Math.max(l.options.zoomMin, y);
					y = Math.min(l.options.zoomMax, y);
					l.lastScale = y / l.scale;
					l.scale = y;
					l.x = l.originX - l.originX * l.lastScale + l.x;
					l.y = l.originY - l.originY * l.lastScale + l.y;
					l.scroller.style[a] = "200ms";
					l.scroller.style[s] = "translate(" + l.x + "px," + l.y + "px) scale(" + l.scale + ")" + z;
					l.zoomed = false;
					l.refresh();
					if (l.options.onZoomEnd) l.options.onZoomEnd.call(l, r);
					return
				}
				if (!l.moved) {
					if (d) {
						if (l.doubleTapTimer && l.options.zoom) {
							clearTimeout(l.doubleTapTimer);
							l.doubleTapTimer = null;
							if (l.options.onZoomStart) l.options.onZoomStart.call(l, r);
							l.zoom(l.pointX, l.pointY, l.scale == 1 ? l.options.doubleTapZoom : 1);
							if (l.options.onZoomEnd) {
								setTimeout(function() {
									l.options.onZoomEnd.call(l, r)
								}, 200)
							}
						} else if (this.options.handleClick) {
							l.doubleTapTimer = setTimeout(function() {
								l.doubleTapTimer = null;
								n = i.target;
								while (n.nodeType != 1) n = n.parentNode;
								if (n.tagName != "SELECT" && n.tagName != "INPUT" && n.tagName != "TEXTAREA") {
									c = e.createEvent("MouseEvents");
									c.initMouseEvent("click", true, true, r.view, 1, i.screenX, i.screenY, i.clientX, i.clientY, r.ctrlKey, r.altKey, r.shiftKey, r.metaKey, 0, null);
									c._fake = true;
									n.dispatchEvent(c)
								}
							}, l.options.zoom ? 250 : 0)
						}
					}
					l._resetPos(400);
					if (l.options.onTouchEnd) l.options.onTouchEnd.call(l, r);
					return
				}
				if (u < 300 && l.options.momentum) {
					p = m ? l._momentum(m - l.startX, u, -l.x, l.scrollerW - l.wrapperW + l.x, l.options.bounce ? l.wrapperW : 0) : p;
					f = h ? l._momentum(h - l.startY, u, -l.y, l.maxScrollY < 0 ? l.scrollerH - l.wrapperH + l.y - l.minScrollY : 0, l.options.bounce ? l.wrapperH : 0) : f;
					m = l.x + p.dist;
					h = l.y + f.dist;
					if (l.x > 0 && m > 0 || l.x < l.maxScrollX && m < l.maxScrollX) p = {
						dist: 0,
						time: 0
					};
					if (l.y > l.minScrollY && h > l.minScrollY || l.y < l.maxScrollY && h < l.maxScrollY) f = {
						dist: 0,
						time: 0
					}
				}
				if (p.dist || f.dist) {
					x = t.max(t.max(p.time, f.time), 10);
					if (l.options.snap) {
						S = m - l.absStartX;
						b = h - l.absStartY;
						if (t.abs(S) < l.options.snapThreshold && t.abs(b) < l.options.snapThreshold) {
							l.scrollTo(l.absStartX, l.absStartY, 200)
						} else {
							g = l._snap(m, h);
							m = g.x;
							h = g.y;
							x = t.max(g.time, x)
						}
					}
					l.scrollTo(t.round(m), t.round(h), x);
					if (l.options.onTouchEnd) l.options.onTouchEnd.call(l, r);
					return
				}
				if (l.options.snap) {
					S = m - l.absStartX;
					b = h - l.absStartY;
					if (t.abs(S) < l.options.snapThreshold && t.abs(b) < l.options.snapThreshold) l.scrollTo(l.absStartX, l.absStartY, 200);
					else {
						g = l._snap(l.x, l.y);
						if (g.x != l.x || g.y != l.y) l.scrollTo(g.x, g.y, g.time)
					} if (l.options.onTouchEnd) l.options.onTouchEnd.call(l, r);
					return
				}
				l._resetPos(200);
				if (l.options.onTouchEnd) l.options.onTouchEnd.call(l, r)
			},
			_resetPos: function(o) {
				var e = this,
					t = e.x >= 0 ? 0 : e.x < e.maxScrollX ? e.maxScrollX : e.x,
					r = e.y >= e.minScrollY || e.maxScrollY > 0 ? e.minScrollY : e.y < e.maxScrollY ? e.maxScrollY : e.y;
				if (t == e.x && r == e.y) {
					if (e.moved) {
						e.moved = false;
						if (e.options.onScrollEnd) e.options.onScrollEnd.call(e)
					}
					if (e.hScrollbar && e.options.hideScrollbar) {
						if (l == "webkit") e.hScrollbarWrapper.style[f] = "300ms";
						e.hScrollbarWrapper.style.opacity = "0"
					}
					if (e.vScrollbar && e.options.hideScrollbar) {
						if (l == "webkit") e.vScrollbarWrapper.style[f] = "300ms";
						e.vScrollbarWrapper.style.opacity = "0"
					}
					return
				}
				e.scrollTo(t, r, o || 0)
			},
			_wheel: function(o) {
				var e = this,
					t, r, l, i, s;
				if ("wheelDeltaX" in o) {
					t = o.wheelDeltaX / 12;
					r = o.wheelDeltaY / 12
				} else if ("wheelDelta" in o) {
					t = r = o.wheelDelta / 12
				} else if ("detail" in o) {
					t = r = -o.detail * 3
				} else {
					return
				} if (e.options.wheelAction == "zoom") {
					s = e.scale * Math.pow(2, 1 / 3 * (r ? r / Math.abs(r) : 0));
					if (s < e.options.zoomMin) s = e.options.zoomMin;
					if (s > e.options.zoomMax) s = e.options.zoomMax;
					if (s != e.scale) {
						if (!e.wheelZoomCount && e.options.onZoomStart) e.options.onZoomStart.call(e, o);
						e.wheelZoomCount++;
						e.zoom(o.pageX, o.pageY, s, 400);
						setTimeout(function() {
							e.wheelZoomCount--;
							if (!e.wheelZoomCount && e.options.onZoomEnd) e.options.onZoomEnd.call(e, o)
						}, 400)
					}
					return
				}
				l = e.x + t;
				i = e.y + r;
				if (l > 0) l = 0;
				else if (l < e.maxScrollX) l = e.maxScrollX;
				if (i > e.minScrollY) i = e.minScrollY;
				else if (i < e.maxScrollY) i = e.maxScrollY;
				if (e.maxScrollY < 0) {
					e.scrollTo(l, i, 0)
				}
			},
			_transitionEnd: function(o) {
				var e = this;
				if (o.target != e.scroller) return;
				e._unbind(X);
				e._startAni()
			},
			_startAni: function() {
				var o = this,
					e = o.x,
					r = o.y,
					l = Date.now(),
					i, s, n;
				if (o.animating) return;
				if (!o.steps.length) {
					o._resetPos(400);
					return
				}
				i = o.steps.shift();
				if (i.x == e && i.y == r) i.time = 0;
				o.animating = true;
				o.moved = true;
				if (o.options.useTransition) {
					o._transitionTime(i.time);
					o._pos(i.x, i.y);
					o.animating = false;
					if (i.time) o._bind(X);
					else o._resetPos(0);
					return
				}
				n = function() {
					var a = Date.now(),
						c, p;
					if (a >= l + i.time) {
						o._pos(i.x, i.y);
						o.animating = false;
						if (o.options.onAnimationEnd) o.options.onAnimationEnd.call(o);
						o._startAni();
						return
					}
					a = (a - l) / i.time - 1;
					s = t.sqrt(1 - a * a);
					c = (i.x - e) * s + e;
					p = (i.y - r) * s + r;
					o._pos(c, p);
					if (o.animating) o.aniTime = w(n)
				};
				n()
			},
			_transitionTime: function(o) {
				o += "ms";
				this.scroller.style[a] = o;
				if (this.hScrollbar) this.hScrollbarIndicator.style[a] = o;
				if (this.vScrollbar) this.vScrollbarIndicator.style[a] = o
			},
			_momentum: function(o, e, r, l, i) {
				var s = 6e-4,
					n = t.abs(o) / e,
					a = n * n / (2 * s),
					c = 0,
					p = 0;
				if (o > 0 && a > r) {
					p = i / (6 / (a / n * s));
					r = r + p;
					n = n * r / a;
					a = r
				} else if (o < 0 && a > l) {
					p = i / (6 / (a / n * s));
					l = l + p;
					n = n * l / a;
					a = l
				}
				a = a * (o < 0 ? -1 : 1);
				c = n / s;
				return {
					dist: a,
					time: t.round(c)
				}
			},
			_offset: function(o) {
				var e = -o.offsetLeft,
					t = -o.offsetTop;
				while (o = o.offsetParent) {
					e -= o.offsetLeft;
					t -= o.offsetTop
				}
				if (o != this.wrapper) {
					e *= this.scale;
					t *= this.scale
				}
				return {
					left: e,
					top: t
				}
			},
			_snap: function(o, e) {
				var r = this,
					l, i, s, n, a, c;
				s = r.pagesX.length - 1;
				for (l = 0, i = r.pagesX.length; l < i; l++) {
					if (o >= r.pagesX[l]) {
						s = l;
						break
					}
				}
				if (s == r.currPageX && s > 0 && r.dirX < 0) s--;
				o = r.pagesX[s];
				a = t.abs(o - r.pagesX[r.currPageX]);
				a = a ? t.abs(r.x - o) / a * 500 : 0;
				r.currPageX = s;
				s = r.pagesY.length - 1;
				for (l = 0; l < s; l++) {
					if (e >= r.pagesY[l]) {
						s = l;
						break
					}
				}
				if (s == r.currPageY && s > 0 && r.dirY < 0) s--;
				e = r.pagesY[s];
				c = t.abs(e - r.pagesY[r.currPageY]);
				c = c ? t.abs(r.y - e) / c * 500 : 0;
				r.currPageY = s;
				n = t.round(t.max(a, c)) || 200;
				return {
					x: o,
					y: e,
					time: n
				}
			},
			_bind: function(o, e, t) {
				(e || this.scroller).addEventListener(o, this, !!t)
			},
			_unbind: function(o, e, t) {
				(e || this.scroller).removeEventListener(o, this, !!t)
			},
			destroy: function() {
				var e = this;
				e.scroller.style[s] = "";
				e.hScrollbar = false;
				e.vScrollbar = false;
				e._scrollbar("h");
				e._scrollbar("v");
				e._unbind(g, o);
				e._unbind(y);
				e._unbind(Y, o);
				e._unbind(v, o);
				e._unbind(T, o);
				if (!e.options.hasTouch) {
					e._unbind("DOMMouseScroll");
					e._unbind("mousewheel")
				}
				if (e.options.useTransition) e._unbind(X);
				if (e.options.checkDOMChanges) clearInterval(e.checkDOMTime);
				if (e.options.onDestroy) e.options.onDestroy.call(e)
			},
			refresh: function() {
				var o = this,
					e, r, l, i, s = 0,
					n = 0;
				if (o.scale < o.options.zoomMin) o.scale = o.options.zoomMin;
				o.wrapperW = o.wrapper.clientWidth || 1;
				o.wrapperH = o.wrapper.clientHeight || 1;
				o.minScrollY = -o.options.topOffset || 0;
				o.scrollerW = t.round(o.scroller.offsetWidth * o.scale);
				o.scrollerH = t.round((o.scroller.offsetHeight + o.minScrollY) * o.scale);
				o.maxScrollX = o.wrapperW - o.scrollerW;
				o.maxScrollY = o.wrapperH - o.scrollerH + o.minScrollY;
				o.dirX = 0;
				o.dirY = 0;
				if (o.options.onRefresh) o.options.onRefresh.call(o);
				o.hScroll = o.options.hScroll && o.maxScrollX < 0;
				o.vScroll = o.options.vScroll && (!o.options.bounceLock && !o.hScroll || o.scrollerH > o.wrapperH);
				o.hScrollbar = o.hScroll && o.options.hScrollbar;
				o.vScrollbar = o.vScroll && o.options.vScrollbar && o.scrollerH > o.wrapperH;
				e = o._offset(o.wrapper);
				o.wrapperOffsetLeft = -e.left;
				o.wrapperOffsetTop = -e.top;
				if (typeof o.options.snap == "string") {
					o.pagesX = [];
					o.pagesY = [];
					i = o.scroller.querySelectorAll(o.options.snap);
					for (r = 0, l = i.length; r < l; r++) {
						s = o._offset(i[r]);
						s.left += o.wrapperOffsetLeft;
						s.top += o.wrapperOffsetTop;
						o.pagesX[r] = s.left < o.maxScrollX ? o.maxScrollX : s.left * o.scale;
						o.pagesY[r] = s.top < o.maxScrollY ? o.maxScrollY : s.top * o.scale
					}
				} else if (o.options.snap) {
					o.pagesX = [];
					while (s >= o.maxScrollX) {
						o.pagesX[n] = s;
						s = s - o.wrapperW;
						n++
					}
					if (o.maxScrollX % o.wrapperW) o.pagesX[o.pagesX.length] = o.maxScrollX - o.pagesX[o.pagesX.length - 1] + o.pagesX[o.pagesX.length - 1];
					s = 0;
					n = 0;
					o.pagesY = [];
					while (s >= o.maxScrollY) {
						o.pagesY[n] = s;
						s = s - o.wrapperH;
						n++
					}
					if (o.maxScrollY % o.wrapperH) o.pagesY[o.pagesY.length] = o.maxScrollY - o.pagesY[o.pagesY.length - 1] + o.pagesY[o.pagesY.length - 1]
				}
				o._scrollbar("h");
				o._scrollbar("v");
				if (!o.zoomed) {
					o.scroller.style[a] = "0";
					o._resetPos(400)
				}
			},
			scrollTo: function(o, e, t, r) {
				var l = this,
					i = o,
					s, n;
				l.stop();
				if (!i.length) i = [{
					x: o,
					y: e,
					time: t,
					relative: r
				}];
				for (s = 0, n = i.length; s < n; s++) {
					if (i[s].relative) {
						i[s].x = l.x - i[s].x;
						i[s].y = l.y - i[s].y
					}
					l.steps.push({
						x: i[s].x,
						y: i[s].y,
						time: i[s].time || 0
					})
				}
				l._startAni()
			},
			scrollToElement: function(o, e) {
				var r = this,
					l;
				o = o.nodeType ? o : r.scroller.querySelector(o);
				if (!o) return;
				l = r._offset(o);
				l.left += r.wrapperOffsetLeft;
				l.top += r.wrapperOffsetTop;
				l.left = l.left > 0 ? 0 : l.left < r.maxScrollX ? r.maxScrollX : l.left;
				l.top = l.top > r.minScrollY ? r.minScrollY : l.top < r.maxScrollY ? r.maxScrollY : l.top;
				e = e === undefined ? t.max(t.abs(l.left) * 2, t.abs(l.top) * 2) : e;
				r.scrollTo(l.left, l.top, e)
			},
			scrollToPage: function(o, e, t) {
				var r = this,
					l, i;
				t = t === undefined ? 400 : t;
				if (r.options.onScrollStart) r.options.onScrollStart.call(r);
				if (r.options.snap) {
					o = o == "next" ? r.currPageX + 1 : o == "prev" ? r.currPageX - 1 : o;
					e = e == "next" ? r.currPageY + 1 : e == "prev" ? r.currPageY - 1 : e;
					o = o < 0 ? 0 : o > r.pagesX.length - 1 ? r.pagesX.length - 1 : o;
					e = e < 0 ? 0 : e > r.pagesY.length - 1 ? r.pagesY.length - 1 : e;
					r.currPageX = o;
					r.currPageY = e;
					l = r.pagesX[o];
					i = r.pagesY[e]
				} else {
					l = -r.wrapperW * o;
					i = -r.wrapperH * e;
					if (l < r.maxScrollX) l = r.maxScrollX;
					if (i < r.maxScrollY) i = r.maxScrollY
				}
				r.scrollTo(l, i, t)
			},
			disable: function() {
				this.stop();
				this._resetPos(0);
				this.enabled = false;
				this._unbind(Y, o);
				this._unbind(v, o);
				this._unbind(T, o)
			},
			enable: function() {
				this.enabled = true
			},
			stop: function() {
				if (this.options.useTransition) this._unbind(X);
				else _(this.aniTime);
				this.steps = [];
				this.moved = false;
				this.animating = false
			},
			zoom: function(o, e, t, r) {
				var l = this,
					i = t / l.scale;
				if (!l.options.useTransform) return;
				l.zoomed = true;
				r = r === undefined ? 200 : r;
				o = o - l.wrapperOffsetLeft - l.x;
				e = e - l.wrapperOffsetTop - l.y;
				l.x = o - o * i + l.x;
				l.y = e - e * i + l.y;
				l.scale = t;
				l.refresh();
				l.x = l.x > 0 ? 0 : l.x < l.maxScrollX ? l.maxScrollX : l.x;
				l.y = l.y > l.minScrollY ? l.minScrollY : l.y < l.maxScrollY ? l.maxScrollY : l.y;
				l.scroller.style[a] = r + "ms";
				l.scroller.style[s] = "translate(" + l.x + "px," + l.y + "px) scale(" + t + ")" + z;
				l.zoomed = false
			},
			isReady: function() {
				return !this.moved && !this.zoomed && !this.animating
			}
		};

		function E(o) {
			if (l === "") return o;
			o = o.charAt(0).toUpperCase() + o.substr(1);
			return l + o
		}
		r = null;
		if (typeof exports !== "undefined") exports.iScroll = M;
		else o.iScroll = M
	})(window, document)
})();;
(function() {
	(function(e) {
		var t = function() {
				_
			}.toString().indexOf("_") > -1,
			n = function() {},
			i = Object.create || function(e) {
				var t = function() {};
				t.prototype = e;
				return new t
			},
			r = true,
			o = {
				toString: ""
			};
		for (var u in o) {
			o.hasOwnProperty(u) && (r = false)
		}
		var s = r ? ["toString", "valueOf"] : null;

		function f(n, i, o) {
			var u = false;
			if (r) {
				var f = [];
				e.each(s, function() {
					o.hasOwnProperty(this) && (u = true) && f.push({
						name: this,
						val: o[this]
					})
				});
				if (u) {
					e.each(o, function(e) {
						f.push({
							name: e,
							val: this
						})
					});
					o = f
				}
			}
			e.each(o, function(r, o) {
				if (u) {
					r = o.name;
					o = o.val
				}
				if (e.isFunction(o) && (!t || o.toString().indexOf(".__base") > -1)) {
					var s = n[r] || function() {};
					i[r] = function() {
						var e = this.__base;
						this.__base = s;
						var t = o.apply(this, arguments);
						this.__base = e;
						return t
					}
				} else {
					i[r] = o
				}
			})
		}
		e.inherit = function() {
			var t = arguments,
				r = e.isFunction(t[0]),
				o = r ? t[0] : n,
				u = t[r ? 1 : 0] || {},
				s = t[r ? 2 : 1],
				a = u.__constructor || r && o.prototype.__constructor ? function() {
					return this.__constructor.apply(this, arguments)
				} : function() {};
			if (!r) {
				a.prototype = u;
				a.prototype.__self = a.prototype.constructor = a;
				return e.extend(a, s)
			}
			e.extend(a, o);
			var l = o.prototype,
				c = a.prototype = i(l);
			c.__self = c.constructor = a;
			f(l, c, u);
			s && f(o, a, s);
			return a
		};
		e.inheritSelf = function(e, t, n) {
			var i = e.prototype;
			f(i, i, t);
			n && f(e, e, n);
			return e
		}
	})(jQuery);
	(function(e) {
		var t = 0,
			n = "__" + +new Date,
			i = function() {
				return "uniq" + ++t
			};
		e.identify = function(e, t) {
			if (!e) return i();
			var r = "uniqueID" in e ? "uniqueID" : n;
			return t || r in e ? e[r] : e[r] = i()
		}
	})(jQuery);
	(function(e) {
		e.isEmptyObject || (e.isEmptyObject = function(e) {
			for (var t in e) return false;
			return true
		})
	})(jQuery);
	(function(e) {
		e.extend({
			debounce: function(e, t, n, i) {
				if (arguments.length == 3 && typeof n != "boolean") {
					i = n;
					n = false
				}
				var r;
				return function() {
					var o = arguments;
					i = i || this;
					n && !r && e.apply(i, o);
					clearTimeout(r);
					r = setTimeout(function() {
						n || e.apply(i, o);
						r = null
					}, t)
				}
			},
			throttle: function(e, t, n) {
				var i, r, o;
				return function() {
					r = arguments;
					o = true;
					n = n || this;
					i || function() {
						if (o) {
							e.apply(n, r);
							o = false;
							i = setTimeout(arguments.callee, t)
						} else {
							i = null
						}
					}()
				}
			}
		})
	})(jQuery);
	(function(e) {
		var t = "__" + +new Date + "storage",
			n = function(t, n) {
				return e.identify(t) + (n ? e.identify(n) : "")
			},
			i = {
				buildEventName: function(e) {
					return e
				},
				on: function(i, r, o, u, s) {
					if (typeof i == "string") {
						if (e.isFunction(r)) {
							u = o;
							o = r;
							r = undefined
						}
						var f = n(o, u),
							a = this[t] || (this[t] = {}),
							l = i.split(" "),
							c = 0,
							d;
						while (i = l[c++]) {
							i = this.buildEventName(i);
							d = a[i] || (a[i] = {
								ids: {},
								list: {}
							});
							if (!(f in d.ids)) {
								var h = d.list,
									m = {
										fn: o,
										data: r,
										ctx: u,
										special: s
									};
								if (h.last) {
									h.last.next = m;
									m.prev = h.last
								} else {
									h.first = m
								}
								d.ids[f] = h.last = m
							}
						}
					} else {
						var _ = this;
						e.each(i, function(e, t) {
							_.on(e, t, r, s)
						})
					}
					return this
				},
				onFirst: function(e, t, n, i) {
					return this.on(e, t, n, i, {
						one: true
					})
				},
				un: function(i, r, o) {
					if (typeof i == "string" || typeof i == "undefined") {
						var u = this[t];
						if (u) {
							if (i) {
								var s = i.split(" "),
									f = 0,
									a;
								while (i = s[f++]) {
									i = this.buildEventName(i);
									if (a = u[i]) {
										if (r) {
											var l = n(r, o),
												c = a.ids;
											if (l in c) {
												var d = a.list,
													h = c[l],
													m = h.prev,
													_ = h.next;
												if (m) {
													m.next = _
												} else if (h === d.first) {
													d.first = _
												}
												if (_) {
													_.prev = m
												} else if (h === d.last) {
													d.last = m
												}
												delete c[l]
											}
										} else {
											delete this[t][i]
										}
									}
								}
							} else {
								delete this[t]
							}
						}
					} else {
						var v = this;
						e.each(i, function(e, t) {
							v.un(e, t, o)
						})
					}
					return this
				},
				trigger: function(n, i) {
					var r = this,
						o = r[t],
						u;
					typeof n === "string" ? n = e.Event(r.buildEventName(u = n)) : n.type = r.buildEventName(u = n.type);
					n.target || (n.target = r);
					if (o && (o = o[n.type])) {
						var s = o.list.first,
							f;
						while (s) {
							n.data = s.data;
							f = s.fn.call(s.ctx || r, n, i);
							if (typeof f !== "undefined") {
								n.result = f;
								if (f === false) {
									n.preventDefault();
									n.stopPropagation()
								}
							}
							s.special && s.special.one && r.un(u, s.fn, s.ctx);
							s = s.next
						}
					}
					return this
				}
			};
		e.observable = e.inherit(i, i)
	})(jQuery);
	(function(e, t) {
		var n = [],
			i = {},
			r = {};

		function o(e, t, n) {
			return (e ? "__elem_" + e : "") + "__mod" + (t ? "_" + t : "") + (n ? "_" + n : "")
		}

		function u(t, n, i) {
			e.isFunction(t) ? n[o(i, "*", "*")] = t : e.each(t, function(t, r) {
				e.isFunction(r) ? n[o(i, t, "*")] = r : e.each(r, function(e, r) {
					n[o(i, t, e)] = r
				})
			})
		}

		function s(e, t) {
			return t ? Array.isArray(t) ? function(n) {
				var i = 0,
					r = t.length;
				while (i < r)
					if (n.hasMod(e, t[i++])) return true;
				return false
			} : function(n) {
				return n.hasMod(e, t)
			} : function(t) {
				return t.hasMod(e)
			}
		}
		this.BEM = e.inherit(e.observable, {
			__constructor: function(e, t, n) {
				var i = this;
				i._modCache = e || {};
				i._processingMods = {};
				i._params = t;
				i.params = null;
				n !== false ? i._init() : i.afterCurrentEvent(function() {
					i._init()
				})
			},
			_init: function() {
				if (!this._initing && !this.hasMod("js", "inited")) {
					this._initing = true;
					if (!this.params) {
						this.params = e.extend(this.getDefaultParams(), this._params);
						delete this._params
					}
					this.setMod("js", "inited");
					delete this._initing;
					this.hasMod("js", "inited") && this.trigger("init")
				}
				return this
			},
			changeThis: function(e, t) {
				return e.bind(t || this)
			},
			afterCurrentEvent: function(e, t) {
				this.__self.afterCurrentEvent(this.changeThis(e, t))
			},
			trigger: function(e, t) {
				this.__base(e = this.buildEvent(e), t).__self.trigger(e, t);
				return this
			},
			buildEvent: function(t) {
				typeof t == "string" && (t = e.Event(t));
				t.block = this;
				return t
			},
			hasMod: function(e, n, i) {
				var r = arguments.length,
					o = false;
				if (r == 1) {
					i = "";
					n = e;
					e = t;
					o = true
				} else if (r == 2) {
					if (typeof e == "string") {
						i = n;
						n = e;
						e = t
					} else {
						i = "";
						o = true
					}
				}
				var u = this.getMod(e, n) === i;
				return o ? !u : u
			},
			getMod: function(e, t) {
				var n = typeof e;
				if (n === "string" || n === "undefined") {
					t = e || t;
					var i = this._modCache;
					return t in i ? i[t] : i[t] = this._extractModVal(t)
				}
				return this._getElemMod(t, e)
			},
			_getElemMod: function(e, t, n) {
				return this._extractModVal(e, t, n)
			},
			getMods: function(e) {
				var n = e && typeof e != "string",
					i = this,
					r = [].slice.call(arguments, n ? 1 : 0),
					o = i._extractMods(r, n ? e : t);
				if (!n) {
					r.length ? r.forEach(function(e) {
						i._modCache[e] = o[e]
					}) : i._modCache = o
				}
				return o
			},
			setMod: function(n, i, r) {
				if (typeof r == "undefined") {
					r = i;
					i = n;
					n = t
				}
				var o = this;
				if (!n || n[0]) {
					var u = (n && n[0] ? e.identify(n[0]) : "") + "_" + i;
					if (this._processingMods[u]) return o;
					var s, f = n ? o._getElemMod(i, n, s = o.__self._extractElemNameFrom(n)) : o.getMod(i);
					if (f === r) return o;
					this._processingMods[u] = true;
					var a = true,
						l = [i, r, f];
					n && l.unshift(n);
					[
						["*", "*"],
						[i, "*"],
						[i, r]
					].forEach(function(e) {
						a = o._callModFn(s, e[0], e[1], l) !== false && a
					});
					!n && a && (o._modCache[i] = r);
					a && o._afterSetMod(i, r, f, n, s);
					delete this._processingMods[u]
				}
				return o
			},
			_afterSetMod: function(e, t, n, i, r) {},
			toggleMod: function(e, n, i, r, o) {
				if (typeof e == "string") {
					o = r;
					r = i;
					i = n;
					n = e;
					e = t
				}
				if (typeof r == "undefined") {
					r = ""
				} else if (typeof r == "boolean") {
					o = r;
					r = ""
				}
				var u = this.getMod(e, n);
				(u == i || u == r) && this.setMod(e, n, typeof o === "boolean" ? o ? i : r : this.hasMod(e, n, i) ? r : i);
				return this
			},
			delMod: function(e, n) {
				if (!n) {
					n = e;
					e = t
				}
				return this.setMod(e, n, "")
			},
			mod: function(e, t, n) {
				return typeof n !== "undefined" || typeof t !== "undefined" && typeof e === "string" ? this.setMod(e, t, n) : this.getMod(e, t, n)
			},
			_callModFn: function(e, n, i, r) {
				var u = o(e, n, i);
				return this[u] ? this[u].apply(this, r) : t
			},
			_extractModVal: function(e, t) {
				return ""
			},
			_extractMods: function(e, t) {
				return {}
			},
			channel: function(e, t) {
				return this.__self.channel(e, t)
			},
			getDefaultParams: function() {
				return {}
			},
			del: function(e) {
				var t = [].slice.call(arguments);
				typeof e == "string" && t.unshift(this);
				this.__self.del.apply(this.__self, t);
				return this
			},
			destruct: function() {}
		}, {
			_name: "i-bem",
			blocks: i,
			decl: function(n, r, o) {
				if (typeof n == "string") n = {
					block: n
				};
				else if (n.name) {
					n.block = n.name
				}
				if (n.baseBlock && !i[n.baseBlock]) throw 'baseBlock "' + n.baseBlock + '" for "' + n.block + '" is undefined';
				r || (r = {});
				if (r.onSetMod) {
					u(r.onSetMod, r);
					delete r.onSetMod
				}
				if (r.onElemSetMod) {
					e.each(r.onElemSetMod, function(e, t) {
						u(t, r, e)
					});
					delete r.onElemSetMod
				}
				var f = i[n.baseBlock || n.block] || this;
				if (n.modName) {
					var a = s(n.modName, n.modVal);
					e.each(r, function(n, i) {
						e.isFunction(i) && (r[n] = function() {
							var e;
							if (a(this)) {
								e = i
							} else {
								var o = f.prototype[n];
								o && o !== r[n] && (e = this.__base)
							}
							return e ? e.apply(this, arguments) : t
						})
					})
				}
				if (o && typeof o.live === "boolean") {
					var l = o.live;
					o.live = function() {
						return l
					}
				}
				var c;
				n.block == f._name ? (c = e.inheritSelf(f, r, o))._processLive(true) : (c = i[n.block] = e.inherit(f, r, o))._name = n.block;
				return c
			},
			_processLive: function(e) {
				return false
			},
			create: function(e, t) {
				typeof e == "string" && (e = {
					block: e
				});
				return new i[e.block](e.mods, t)
			},
			getName: function() {
				return this._name
			},
			_extractElemNameFrom: function(e) {},
			afterCurrentEvent: function(e, t) {
				n.push({
					fn: e,
					ctx: t
				}) == 1 && setTimeout(this._runAfterCurrentEventFns, 0)
			},
			_runAfterCurrentEventFns: function() {
				var e = n.length;
				if (e) {
					var t, i = n.splice(0, e);
					while (t = i.shift()) t.fn.call(t.ctx || this)
				}
			},
			changeThis: function(e, t) {
				return e.bind(t || this)
			},
			del: function(e) {
				var t = typeof e == "string",
					n = t ? 0 : 1,
					i = arguments.length;
				t && (e = this);
				while (n < i) delete e[arguments[n++]];
				return this
			},
			channel: function(n, i) {
				if (typeof n == "boolean") {
					i = n;
					n = t
				}
				n || (n = "default");
				if (i) {
					if (r[n]) {
						r[n].un();
						delete r[n]
					}
					return
				}
				return r[n] || (r[n] = new e.observable)
			}
		})
	})(jQuery);
	(function() {
		Object.keys || (Object.keys = function(e) {
			var t = [];
			for (var n in e) e.hasOwnProperty(n) && t.push(n);
			return t
		})
	})();
	(function() {
		var e = Array.prototype,
			t = Object.prototype.toString,
			n = {
				indexOf: function(e, t) {
					t = +(t || 0);
					var n = this,
						i = n.length;
					if (i > 0 && t < i) {
						t = t < 0 ? Math.ceil(t) : Math.floor(t);
						t < -i && (t = 0);
						t < 0 && (t = t + i);
						while (t < i) {
							if (t in n && n[t] === e) return t;
							++t
						}
					}
					return -1
				},
				forEach: function(e, t) {
					var n = -1,
						i = this,
						r = i.length;
					while (++n < r) n in i && (t ? e.call(t, i[n], n, i) : e(i[n], n, i))
				},
				map: function(e, t) {
					var n = -1,
						i = this,
						r = i.length,
						o = new Array(r);
					while (++n < r) n in i && (o[n] = t ? e.call(t, i[n], n, i) : e(i[n], n, i));
					return o
				},
				filter: function(e, t) {
					var n = -1,
						i = this,
						r = i.length,
						o = [];
					while (++n < r) n in i && (t ? e.call(t, i[n], n, i) : e(i[n], n, i)) && o.push(i[n]);
					return o
				},
				reduce: function(e, t) {
					var n = -1,
						i = this,
						r = i.length,
						o;
					if (arguments.length < 2) {
						while (++n < r) {
							if (n in i) {
								o = i[n];
								break
							}
						}
					} else {
						o = t
					}
					while (++n < r) n in i && (o = e(o, i[n], n, i));
					return o
				},
				some: function(e, t) {
					var n = -1,
						i = this,
						r = i.length;
					while (++n < r)
						if (n in i && (t ? e.call(t, i[n], n, i) : e(i[n], n, i))) return true;
					return false
				},
				every: function(e, t) {
					var n = -1,
						i = this,
						r = i.length;
					while (++n < r)
						if (n in i && !(t ? e.call(t, i[n], n, i) : e(i[n], n, i))) return false;
					return true
				}
			};
		for (var i in n) e[i] || (e[i] = n[i]);
		Array.isArray || (Array.isArray = function(e) {
			return t.call(e) === "[object Array]"
		})
	})();
	(function() {
		var e = Array.prototype.slice;
		Function.prototype.bind || (Function.prototype.bind = function(t) {
			var n = this,
				i = e.call(arguments, 1);
			return function() {
				return n.apply(t, i.concat(e.call(arguments)))
			}
		})
	})();
	(function(e, t, n) {
		var i = "_",
			r = "__",
			o = "[a-zA-Z0-9-]+";

		function u(e, t, n) {
			n.push(i, e, i, t)
		}

		function s(e, t, n, i) {
			i.push(e);
			n && u(t, n, i)
		}

		function f(e, t, i, o, f) {
			s(e, n, n, f);
			f.push(r, t);
			o && u(i, o, f)
		}
		e.INTERNAL = {
			NAME_PATTERN: o,
			MOD_DELIM: i,
			ELEM_DELIM: r,
			buildModPostfix: function(e, t, n) {
				var i = n || [];
				u(e, t, i);
				return n ? i : i.join("")
			},
			buildClass: function(e, t, i, r, o) {
				var u = typeof i;
				if (u == "string") {
					if (typeof r != "string") {
						o = r;
						r = i;
						i = t;
						t = n
					}
				} else if (u != "undefined") {
					o = i;
					i = n
				} else if (t && typeof t != "string") {
					o = t;
					t = n
				}
				if (!(t || i || o)) {
					return e
				}
				var a = o || [];
				t ? f(e, t, i, r, a) : s(e, i, r, a);
				return o ? a : a.join("")
			},
			buildClasses: function(e, i, r, o) {
				if (i && typeof i != "string") {
					o = r;
					r = i;
					i = n
				}
				var u = o || [];
				i ? f(e, i, n, n, u) : s(e, n, n, u);
				r && t.each(r, function(t, n) {
					if (n) {
						u.push(" ");
						i ? f(e, i, t, n, u) : s(e, t, n, u)
					}
				});
				return o ? u : u.join("")
			}
		}
	})(BEM, jQuery);
	(function(e, t, n) {
		var i = t(window),
			r = t(document),
			o = {},
			u = {},
			s = {},
			f = {},
			a = {},
			l = e.blocks,
			c = e.INTERNAL,
			d = c.NAME_PATTERN,
			h = c.MOD_DELIM,
			m = c.ELEM_DELIM,
			_ = c.buildModPostfix,
			v = c.buildClass;

		function p(e, n) {
			var i = e[0];
			t.each(y(i), function(r, o) {
				E(o, i, r, n);
				var s = u[o.uniqId];
				if (s) {
					if (s.domElem.index(i) < 0) {
						s.domElem = s.domElem.add(e);
						t.extend(s._params, o)
					}
				} else {
					b(r, e, o)
				}
			})
		}

		function b(e, i, r, s, f) {
			if (typeof r == "boolean") {
				f = s;
				s = r;
				r = n
			}
			var a = i[0];
			r = E(r || y(a)[e], a, e);
			var c = r.uniqId;
			if (u[c]) {
				return u[c]._init()
			}
			o[c] = o[c] ? o[c].add(i) : i;
			var d = a.parentNode;
			if (!d || d.nodeType === 11) {
				t.unique(o[c])
			}
			var h = l[e] || I.decl(e, {}, {
				live: true
			});
			if (!(h._liveInitable = !!h._processLive()) || s || r.live === false) {
				var m = new h(o[c], r, !!s);
				delete o[c];
				f && f.apply(m, Array.prototype.slice.call(arguments, 4));
				return m
			}
		}

		function E(e, n, i, r) {
			(e || (e = {})).uniqId || (e.uniqId = (e.id ? i + "-id-" + e.id : t.identify()) + (r || t.identify()));
			var o = t.identify(n),
				u = s[o] || (s[o] = {});
			u[i] || (u[i] = e);
			return e
		}

		function g(e, t, n) {
			var i = e.find(t);
			return n ? i : i.add(e.filter(t))
		}

		function y(e) {
			var n = t.identify(e);
			return s[n] || (s[n] = x(e))
		}

		function x(e) {
			var n = e.onclick || e.ondblclick;
			if (!n && e.tagName.toLowerCase() == "body") {
				var i = t(e),
					r = i.attr("onclick") || i.attr("ondblclick");
				r && (n = Function(r))
			}
			return n ? n() : {}
		}

		function M(e) {
			delete s[t.identify(e)]
		}

		function N(e, t) {
			e.domElem.length === 1 ? e.destruct(true) : e.domElem = e.domElem.not(t)
		}

		function C() {
			return r[0][t.support.boxModel ? "documentElement" : "body"]
		}
		t.fn.bem = function(e, t) {
			return b(e, this, t, true)
		};
		var I = e.DOM = e.decl("i-bem__dom", {
			__constructor: function(e, n, i) {
				var r = this;
				r.domElem = e;
				r._eventNameCache = {};
				r._elemCache = {};
				u[r._uniqId = n.uniqId || t.identify(r)] = r;
				r._needSpecialUnbind = false;
				r.__base(null, n, i)
			},
			findBlocksInside: function(e, t) {
				return this._findBlocks("find", e, t)
			},
			findBlockInside: function(e, t) {
				return this._findBlocks("find", e, t, true)
			},
			findBlocksOutside: function(e, t) {
				return this._findBlocks("parents", e, t)
			},
			findBlockOutside: function(e, t) {
				return this._findBlocks("closest", e, t)[0] || null
			},
			findBlocksOn: function(e, t) {
				return this._findBlocks("", e, t)
			},
			findBlockOn: function(e, t) {
				return this._findBlocks("", e, t, true)
			},
			_findBlocks: function(e, i, r, o) {
				if (!r) {
					r = i;
					i = n
				}
				var u = i ? typeof i == "string" ? this.findElem(i) : i : this.domElem,
					s = typeof r == "string",
					f = s ? r : r.block || r.blockName,
					a = "." + (s ? v(f) : v(f, r.modName, r.modVal)) + (o ? ":first" : ""),
					l = u.filter(a);
				e && (l = l.add(u[e](a)));
				if (o) {
					return l[0] ? b(f, l.eq(0), true) : null
				}
				var c = [],
					d = {};
				t.each(l, function(e, n) {
					var i = b(f, t(n), true);
					if (!d[i._uniqId]) {
						d[i._uniqId] = true;
						c.push(i)
					}
				});
				return c
			},
			bindToDomElem: function(e, n, i) {
				var r = this;
				i ? e.bind(r._buildEventName(n), function(e) {
					(e.data || (e.data = {})).domElem = t(this);
					return i.apply(r, arguments)
				}) : t.each(n, function(t, n) {
					r.bindToDomElem(e, t, n)
				});
				return r
			},
			bindToDoc: function(e, t) {
				this._needSpecialUnbind = true;
				return this.bindToDomElem(r, e, t)
			},
			bindToWin: function(e, t) {
				this._needSpecialUnbind = true;
				return this.bindToDomElem(i, e, t)
			},
			bindTo: function(e, n, i) {
				if (!n || t.isFunction(n)) {
					i = n;
					n = e;
					e = this.domElem
				} else if (typeof e == "string") {
					e = this.elem(e)
				}
				return this.bindToDomElem(e, n, i)
			},
			unbindFromDomElem: function(e, t) {
				e.unbind(this._buildEventName(t));
				return this
			},
			unbindFromDoc: function(e) {
				return this.unbindFromDomElem(r, e)
			},
			unbindFromWin: function(e) {
				return this.unbindFromDomElem(i, e)
			},
			unbindFrom: function(e, t) {
				if (!t) {
					t = e;
					e = this.domElem
				} else if (typeof e == "string") {
					e = this.elem(e)
				}
				return this.unbindFromDomElem(e, t)
			},
			_buildEventName: function(e) {
				var t = this;
				return e.indexOf(" ") > 1 ? e.split(" ").map(function(e) {
					return t._buildOneEventName(e)
				}).join(" ") : t._buildOneEventName(e)
			},
			_buildOneEventName: function(e) {
				var t = this,
					n = t._eventNameCache;
				if (e in n) return n[e];
				var i = "." + t._uniqId;
				if (e.indexOf(".") < 0) return n[e] = e + i;
				var r = ".bem_" + t.__self._name;
				return n[e] = e.split(".").map(function(e, t) {
					return t == 0 ? e + r : r + "_" + e
				}).join("") + i
			},
			trigger: function(e, t) {
				this.__base(e = this.buildEvent(e), t).domElem && this._ctxTrigger(e, t);
				return this
			},
			_ctxTrigger: function(e, n) {
				var i = this,
					r = f[i.__self._buildCtxEventName(e.type)],
					o = {};
				r && i.domElem.each(function() {
					var u = this,
						s = r.counter;
					while (u && s) {
						var f = t.identify(u, true);
						if (f) {
							if (o[f]) break;
							var a = r.ctxs[f];
							if (a) {
								t.each(a, function(t, r) {
									r.fn.call(r.ctx || i, e, n)
								});
								s--
							}
							o[f] = true
						}
						u = u.parentNode
					}
				})
			},
			setMod: function(e, n, i) {
				if (e && typeof i != "undefined" && e.length > 1) {
					var r = this;
					e.each(function() {
						var o = t(this);
						o.__bemElemName = e.__bemElemName;
						r.setMod(o, n, i)
					});
					return r
				}
				return this.__base(e, n, i)
			},
			_extractModVal: function(e, t, n) {
				var i = (t || this.domElem)[0],
					r;
				i && (r = i.className.match(this.__self._buildModValRE(e, n || t)));
				return r ? r[2] : ""
			},
			_extractMods: function(e, t) {
				var n = {},
					i = !e.length,
					r = 0;
				((t || this.domElem)[0].className.match(this.__self._buildModValRE("(" + (i ? d : e.join("|")) + ")", t, "g")) || []).forEach(function(e) {
					var t = (e = e.trim()).lastIndexOf(h),
						i = e.substr(0, t - 1).lastIndexOf(h);
					n[e.substr(i + 1, t - i - 1)] = e.substr(t + 1);
					++r
				});
				r < e.length && e.forEach(function(e) {
					e in n || (n[e] = "")
				});
				return n
			},
			_afterSetMod: function(e, n, i, r, o) {
				var u = this.__self,
					s = u._buildModClassPrefix(e, o),
					f = u._buildModValRE(e, o),
					a = n === "";
				(r || this.domElem).each(function() {
					var e = this.className;
					e.indexOf(s) > -1 ? this.className = e.replace(f, (a ? "" : "$1" + s + n) + "$3") : a || t(this).addClass(s + n)
				});
				o && this.dropElemCache(o, e, i).dropElemCache(o, e, n)
			},
			findElem: function(e, t, n, i) {
				if (arguments.length % 2) {
					i = n;
					n = t;
					t = e;
					e = this.domElem
				} else if (typeof e == "string") {
					e = this.findElem(e)
				}
				var r = this.__self,
					o = "." + t.split(" ").map(function(e) {
						return v(r._name, e, n, i)
					}).join(",.");
				return g(e, o)
			},
			_elem: function(e, t, n) {
				var i = e + _(t, n),
					r;
				if (!(r = this._elemCache[i])) {
					r = this._elemCache[i] = this.findElem(e, t, n);
					r.__bemElemName = e
				}
				return r
			},
			elem: function(e, n, i) {
				if (n && typeof n != "string") {
					n.__bemElemName = e;
					return n
				}
				if (e.indexOf(" ") < 0) {
					return this._elem(e, n, i)
				}
				var r = t([]),
					o = this;
				e.split(" ").forEach(function(e) {
					r = r.add(o._elem(e, n, i))
				});
				return r
			},
			dropElemCache: function(e, t, n) {
				if (e) {
					var i = this,
						r = _(t, n);
					e.indexOf(" ") < 0 ? delete i._elemCache[e + r] : e.split(" ").forEach(function(e) {
						delete i._elemCache[e + r]
					})
				} else {
					this._elemCache = {}
				}
				return this
			},
			elemParams: function(e) {
				var t;
				if (typeof e == "string") {
					t = e;
					e = this.elem(e)
				} else {
					t = this.__self._extractElemNameFrom(e)
				}
				return x(e[0])[v(this.__self.getName(), t)] || {}
			},
			containsDomElem: function(e) {
				var t = false;
				this.domElem.each(function() {
					return !(t = e.parents().andSelf().index(this) > -1)
				});
				return t
			},
			buildSelector: function(e, t, n) {
				return this.__self.buildSelector(e, t, n)
			},
			destruct: function(e) {
				var n = this,
					i = n.__self;
				n._isDestructing = true;
				n._needSpecialUnbind && i.doc.add(i.win).unbind("." + n._uniqId);
				n.dropElemCache().domElem.each(function(e, n) {
					var i = y(n);
					t.each(i, function(e, t) {
						var r = u[t.uniqId];
						if (r) {
							if (!r._isDestructing) {
								N(r, n);
								delete i[e]
							}
						} else {
							delete o[t.uniqId]
						}
					});
					t.isEmptyObject(i) && M(n)
				});
				e || n.domElem.remove();
				delete u[n.un()._uniqId];
				delete n.domElem;
				delete n._elemCache;
				n.__base()
			}
		}, {
			doc: r,
			win: i,
			_processLive: function(e) {
				var t = this,
					n = t._liveInitable;
				if ("live" in t) {
					var i = typeof n == "undefined";
					if (i ^ e) {
						n = t.live() !== false;
						t.live = function() {}
					}
				}
				return n
			},
			init: function(e, n, i) {
				if (!e || t.isFunction(e)) {
					i = n;
					n = e;
					e = r
				}
				var o = t.identify();
				g(e, ".i-bem").each(function() {
					p(t(this), o)
				});
				n && this.afterCurrentEvent(function() {
					n.call(i || this, e)
				});
				this._runAfterCurrentEventFns();
				return e
			},
			destruct: function(e, i, r) {
				if (typeof e != "boolean") {
					r = i;
					i = e;
					e = n
				}
				g(i, ".i-bem", r).each(function(e, n) {
					var i = y(this);
					t.each(i, function(e, t) {
						if (t.uniqId) {
							var r = u[t.uniqId];
							if (r) {
								N(r, n);
								delete i[e]
							} else {
								delete o[t.uniqId]
							}
						}
					});
					t.isEmptyObject(i) && M(this)
				});
				e || (r ? i.empty() : i.remove())
			},
			update: function(e, t, n, i) {
				this.destruct(e, true);
				this.init(e.html(t), n, i)
			},
			replace: function(e, n) {
				this.destruct(true, e);
				this.init(t(n).replaceAll(e))
			},
			append: function(e, n) {
				this.init(t(n).appendTo(e))
			},
			prepend: function(e, n) {
				this.init(t(n).prependTo(e))
			},
			before: function(e, n) {
				this.init(t(n).insertBefore(e))
			},
			after: function(e, n) {
				this.init(t(n).insertAfter(e))
			},
			_buildCtxEventName: function(e) {
				return this._name + ":" + e
			},
			_liveClassBind: function(e, n, i, o) {
				var u = this;
				if (n.indexOf(" ") > -1) {
					n.split(" ").forEach(function(t) {
						u._liveClassBind(e, t, i, o)
					})
				} else {
					var s = a[n],
						f = t.identify(i);
					if (!s) {
						s = a[n] = {};
						r.bind(n, u.changeThis(u._liveClassTrigger, u))
					}
					s = s[e] || (s[e] = {
						uniqIds: {},
						fns: []
					});
					if (!(f in s.uniqIds)) {
						s.fns.push({
							uniqId: f,
							fn: u._buildLiveEventFn(i, o)
						});
						s.uniqIds[f] = s.fns.length - 1
					}
				}
				return this
			},
			_liveClassUnbind: function(e, n, i) {
				var r = a[n];
				if (r) {
					if (i) {
						if (r = r[e]) {
							var o = t.identify(i);
							if (o in r.uniqIds) {
								var u = r.uniqIds[o],
									s = r.fns.length - 1;
								r.fns.splice(u, 1);
								while (u < s) r.uniqIds[r.fns[u++].uniqId] = u - 1;
								delete r.uniqIds[o]
							}
						}
					} else {
						delete r[e]
					}
				}
				return this
			},
			_liveClassTrigger: function(e) {
				var n = a[e.type];
				if (n) {
					var i = e.target,
						r = [];
					for (var o in n) n.hasOwnProperty(o) && r.push(o);
					do {
						var u = " " + i.className + " ",
							s = 0;
						while (o = r[s++]) {
							if (u.indexOf(" " + o + " ") > -1) {
								var f = 0,
									l = n[o].fns,
									c, d = false;
								while (c = l[f++])
									if (c.fn.call(t(i), e) === false) d = true;
								d && e.preventDefault();
								if (d || e.isPropagationStopped()) return;
								r.splice(--s, 1)
							}
						}
					} while (r.length && (i = i.parentNode))
				}
			},
			_buildLiveEventFn: function(e, n) {
				var i = this;
				return function(r) {
					var o = [i._name, ((r.data || (r.data = {})).domElem = t(this)).closest(i.buildSelector()), true],
						u = b.apply(null, n ? o.concat([e, r]) : o);
					if (u && !n && e) return e.apply(u, arguments)
				}
			},
			liveInitOnEvent: function(e, t, n) {
				return this.liveBindTo(e, t, n, true)
			},
			liveBindTo: function(e, i, r, o) {
				if (!i || t.isFunction(i)) {
					r = i;
					i = e;
					e = n
				}
				if (!e || typeof e == "string") {
					e = {
						elem: e
					}
				}
				e.elemName && (e.elem = e.elemName);
				var u = this;
				if (e.elem && e.elem.indexOf(" ") > 1) {
					e.elem.split(" ").forEach(function(t) {
						u._liveClassBind(v(u._name, t, e.modName, e.modVal), i, r, o)
					});
					return u
				}
				return u._liveClassBind(v(u._name, e.elem, e.modName, e.modVal), i, r, o)
			},
			liveUnbindFrom: function(e, t, n) {
				var i = this;
				if (e.indexOf(" ") > 1) {
					e.split(" ").forEach(function(e) {
						i._liveClassUnbind(v(i._name, e), t, n)
					});
					return i
				}
				return i._liveClassUnbind(v(i._name, e), t, n)
			},
			_liveInitOnBlockEvent: function(e, t, n, i) {
				var r = this._name;
				l[t].on(e, function(e) {
					var t = arguments,
						o = e.block[i](r);
					n && o.forEach(function(e) {
						n.apply(e, t)
					})
				});
				return this
			},
			liveInitOnBlockEvent: function(e, t, n) {
				return this._liveInitOnBlockEvent(e, t, n, "findBlocksOn")
			},
			liveInitOnBlockInsideEvent: function(e, t, n) {
				return this._liveInitOnBlockEvent(e, t, n, "findBlocksOutside")
			},
			liveInitOnBlockInit: function(e, t) {
				return this.liveInitOnBlockEvent("init", e, t)
			},
			liveInitOnBlockInsideInit: function(e, t) {
				return this.liveInitOnBlockInsideEvent("init", e, t)
			},
			on: function(e, t, n, i, r) {
				return e.jquery ? this._liveCtxBind(e, t, n, i, r) : this.__base(e, t, n, i)
			},
			un: function(e, t, n, i) {
				return e.jquery ? this._liveCtxUnbind(e, t, n, i) : this.__base(e, t, n)
			},
			liveCtxBind: function(e, t, n, i, r) {
				return this._liveCtxBind(e, t, n, i, r)
			},
			_liveCtxBind: function(e, i, r, o, u) {
				var s = this;
				if (typeof i == "string") {
					if (t.isFunction(r)) {
						u = o;
						o = r;
						r = n
					}
					if (i.indexOf(" ") > -1) {
						i.split(" ").forEach(function(t) {
							s._liveCtxBind(e, t, r, o, u)
						})
					} else {
						var a = s._buildCtxEventName(i),
							l = f[a] || (f[a] = {
								counter: 0,
								ctxs: {}
							});
						e.each(function() {
							var e = t.identify(this),
								n = l.ctxs[e];
							if (!n) {
								n = l.ctxs[e] = {};
								++l.counter
							}
							n[t.identify(o) + (u ? t.identify(u) : "")] = {
								fn: o,
								data: r,
								ctx: u
							}
						})
					}
				} else {
					t.each(i, function(t, n) {
						s._liveCtxBind(e, t, n, r)
					})
				}
				return s
			},
			liveCtxUnbind: function(e, t, n, i) {
				return this._liveCtxUnbind(e, t, n, i)
			},
			_liveCtxUnbind: function(e, n, i, r) {
				var o = this,
					u = f[n = o._buildCtxEventName(n)];
				if (u) {
					e.each(function() {
						var e = t.identify(this, true),
							n;
						if (e && (n = u.ctxs[e])) {
							i && delete n[t.identify(i) + (r ? t.identify(r) : "")];
							if (!i || t.isEmptyObject(n)) {
								u.counter--;
								delete u.ctxs[e]
							}
						}
					});
					u.counter || delete f[n]
				}
				return o
			},
			_extractElemNameFrom: function(e) {
				if (e.__bemElemName) return e.__bemElemName;
				var t = e[0].className.match(this._buildElemNameRE());
				return t ? t[1] : n
			},
			extractParams: x,
			_buildModClassPrefix: function(e, t) {
				return v(this._name) + (t ? m + (typeof t === "string" ? t : this._extractElemNameFrom(t)) : "") + h + e + h
			},
			_buildModValRE: function(e, t, n) {
				return new RegExp("(\\s?)" + this._buildModClassPrefix(e, t) + "(" + d + ")(\\s|$)", n)
			},
			_buildElemNameRE: function() {
				return new RegExp(this._name + m + "(" + d + ")(?:\\s|$)")
			},
			buildSelector: function(e, t, n) {
				return "." + v(this._name, e, t, n)
			},
			getBlockByUniqId: function(e) {
				return u[e]
			},
			getWindowSize: function() {
				return {
					width: i.width(),
					height: i.height()
				}
			}
		})
	})(BEM, jQuery);
	(function() {
		String.prototype.trim || (String.prototype.trim = function() {
			var e = this.replace(/^\s\s*/, ""),
				t = /\s/,
				n = e.length;
			while (t.test(e.charAt(--n)));
			return e.slice(0, n + 1)
		})
	})();
	$(function() {
		BEM.DOM.init()
	})
})();;
(function() {~
	function() {
		var e = "old_browsers_popup",
			r = {
				expires: new Date("Fri, 31 Dec 9999 23:59:59")
			};
		$.browser = $.browser || {};
		switch (true) {
			default:
			case $.cookie(e) !== undefined:
				return;
			case $.browser.msie && $.browser.version <= 7:
			case $.browser.chrome && $.browser.version <= 8:
			case $.browser.mozilla && $.browser.version <= 3:
			case $.browser.opera && $.browser.version <= 10:
			case $.browser.safari && $.browser.version[0] <= 3:
		}
		$.cookie(e, 1, r);
		BEM.DOM.decl("b-old-browsers-popup", {
			onSetMod: {
				js: function() {
					this.setMod("visible", "yes");
					this.bindTo("close", "click", function() {
						this.delMod("visible")
					})
				}
			}
		})
	}()
})();;
(function() {
	BEM.DOM.decl("b-phone-input", {
		skip: false,
		onSetMod: {
			js: function() {
				this.bindTo("paste", this.fixPhonePrefix);
				this.domElem.setMask({
					mask: "999 999 99 99",
					type: "regular"
				})
			}
		},
		fixPhonePrefix: function(e) {
			if (e.range && e.range.start == 0 && e.which) {
				e.which = e.which.replace(/^(?:\+7|8)/, "")
			}
		}
	})
})();;
(function() {
	$(function() {
		var e = window.globalStorage || {};
		var i = "ontouchstart" in window ? true : false;
		var t;

		function n() {
			$(".p__body").css("position", "relative");
			$(".p__body").animate({
				right: "0",
				left: "0"
			}, 300, function() {
				t = false;
				$(".b-mobilemenu").css("display", "none");
				$(".b-mobileShowerButtons__link").css("color", "#b1b1b1");
				$(".p__body").unbind("click", n)
			})
		}
		$(".b-mobileShowerButtons__link").click(function(e) {
			$(".b-mobileShowerButtons__link").css("color", "#18a562");
			e.preventDefault();
			if (t != true) {
				$(".p__body").css({
					position: "fixed",
					left: "auto"
				});
				$(".b-mobilemenu").css("display", "block");
				$(".p__body").animate({
					right: "82%",
					left: "-82%"
				}, 300, function() {
					t = true;
					$(".p__body").bind("click", n)
				})
			} else {
				n()
			}
		});
		$(window).on("orientationchange", false, function() {
			n()
		});
		$(window).on("resize", false, function() {
			if (e.IS_DESKTOP || e.IS_WIDE) {
				n()
			}
		});
		$(".b-mobileMenuSubmenu__link").on("click", false, function() {
			$(".b-mobilemenu").find($(".b-mobilemenu-state_current")).removeClass("b-mobilemenu-state_current");
			$(this).addClass("b-mobilemenu-state_current")
		});
		var o;
		$(".b-mobilemenu__link.acc-header").on("click", false, function(e) {
			var i = $(this),
				t = $(this).closest(".b-mobilemenu__item");
			if (t.hasClass("b-mobilemenu__item_empty_yes")) {
				location.href = i.prop("href");
				return
			}
			if (o != undefined) {
				if ($(this).text() != $(o).text()) {
					$(o).parent().removeClass("acc-state_active");
					$(o).next().slideUp("fast")
				}
			} else {
				o = $(this)
			}
			o = $(this)
		});
		var s = $(".b-mobileMenuSubmenu__item");
		s.click(l);

		function l(e) {
			var i = $(this).text();
			$(this).closest(".b-mobilemenu__item_selectable").children(".b-mobilemenu__link_custom").text(i);
			c($(this))
		}

		function c(e) {
			e.closest(".b-mobilemenu__item_selectable").removeClass("acc-state_active");
			e.parent().css("display", "none")
		}

		function a(e) {
			e.closest(".b-mobilemenu__item_selectable").addClass("acc-state_active");
			e.parent().css("display", "block")
		}
		if (i) {
			s.find(".b-mobileMenuSubmenu__link").bind("click", function(e) {
				if (activeMenu != this) {
					activeMenu = this;
					a($(this).parent().parent())
				} else {
					c($(this).parent().parent());
					activeMenu = null
				}
			})
		}
	})
})();;
(function() {
	$(function() {
		var e = window.globalStorage || {};
		$(window).on("resize", false, function() {
			if (e.IS_DESKTOP || e.IS_WIDE) {
				if ($(".b-mobileShowerSearch").css("display") !== "none") {
					$(".b-mobileShowerSearch").hide()
				} else {
					$(".b-mobileShowerSearch").show()
				}
			}
		});
		$(window).resize(function() {
			if (e.IS_DESKTOP || e.IS_WIDE) {
				$(".b-mobileShowerSearch__form__search").blur();
				if ($(".b-mobileShowerSearch").css("display") !== "none") {
					$(".b-mobileShowerSearch").hide()
				} else {
					$(".b-mobileShowerSearch").show()
				}
			}
		});
		$(".b-mobileShowerButtons__button").on("click", false, function() {
			$(".b-mobileShowerSearch").toggle();
			if ($(".b-mobileShowerSearch").css("display") !== "none") {
				$("div.b-header").addClass("b-mobileShower__open");
				$(".b-mobileShowerSearch").addClass("b-mobileShowerSearch__open");
				$(".b-mobileShower").addClass("b-mobileShower__open")
			} else {
				$("div.b-header").removeClass("b-mobileShower__open");
				$(".b-mobileShowerSearch").removeClass("b-mobileShowerSearch__open");
				$(".b-mobileShower").removeClass("b-mobileShower__open")
			}
		});
		$(".b-mobileShowerSearch__form").on("submit", false, function() {
			$(".b-mobileShowerSearch").css("display", "none")
		})
	})
})();;
(function() {
	if (!("placeholder" in document.createElement("input"))) {
		BEM.DOM.decl("b-placeholder", {
			placeholder: $(),
			onSetMod: {
				js: {
					inited: function() {
						var e = this,
							t = BEM.INTERNAL.buildClass(this.__self._name, "placeholder"),
							i = BEM.INTERNAL.buildClass(this.__self._name, "input"),
							n = $("<div></div>").addClass(t);
						this.domElem = this.domElem.addClass(i).before(n).add(n);
						this.__self.on("update", function() {
							e._updateAttributes()
						});
						this.bindTo("input", "blur focus change", this._togglePlaceholder);
						this.bindTo("placeholder", "mousedown", function() {
							var e = this.elem("input");
							!e.prop("disabled") && e.is(":visible") && e.focus();
							return false
						});
						if ("onpropertychange" in this.elem("input")[0]) {
							this.elem("input")[0].onpropertychange = function() {
								if (!window.event || window.event.propertyName != "value") {
									return
								}
								e._togglePlaceholder()
							}
						}
						this._togglePlaceholder()
					}
				}
			},
			_togglePlaceholder: function() {
				this.toggleMod("placeholder", "show", !this.elem("input").val().length)
			},
			_updateAttributes: function() {
				var e = this.elem("input"),
					t = this.elem("placeholder"),
					i;
				if (!e.is(":visible")) {
					this.setMod("input", "hidden");
					return
				}
				this.delMod("input");
				t.css(e.css(["padding-left", "padding-top", "padding-right", "padding-bottom", "margin-left", "margin-top", "margin-right", "margin-bottom", "border-top-width", "border-right-width", "border-bottom-width", "border-left-width", "border-top-style", "border-right-style", "border-bottom-style", "border-left-style", "font-style", "font-variant", "font-weight", "font-size", "font-family", "line-height", "width", "height"]));
				this.__zIndex(t, this.__zIndex(e) + 1);
				i = e.position();
				t.css({
					top: i.top + "px",
					left: i.left + "px",
					position: "absolute"
				});
				t.text(e.attr("placeholder"))
			},
			__zIndex: function(e, t) {
				if (t !== undefined) {
					return e.css("zIndex", t)
				}
				if (e.length) {
					var i = $(e[0]),
						n, o;
					while (i.length && i[0] !== document) {
						n = i.css("position");
						if (n === "absolute" || n === "relative" || n === "fixed") {
							o = parseInt(i.css("zIndex"), 10);
							if (!isNaN(o) && o !== 0) {
								return o
							}
						}
						i = i.parent()
					}
				}
				return 0
			}
		}, {
			UPDATE_TIMEOUT: 200,
			run: function() {
				var e = this;
				$("input").add("textarea").not(".b-placeholder__input").filter("[placeholder]").each(function() {
					$(this).bem("b-placeholder")
				});
				this.trigger("update");
				window.setTimeout(function() {
					e.run()
				}, this.UPDATE_TIMEOUT)
			}
		});
		$(function() {
			BEM.DOM.blocks["b-placeholder"].run()
		})
	}
})();;
(function() {
	BEM.DOM.decl("b-topline", {
		onSetMod: {
			js: function() {
				var e = this;
				e.setMod("state", "msisdn");
				e.bindTo(e.elem("opener"), "click", function() {
					e.elem("row close").slideDown(100, function() {
						e.setMod(e.elem("row close"), "state", "open");
						e.elem("opener").slideUp(80, function() {
							e.setMod(e.elem("opener"), "state", "close");
							$.removeCookie("b-topline-hide")
						})
					});
					return false
				});
				e.bindTo(e.elem("close"), "click", function() {
					e.elem("row close").slideUp(100, function() {
						e.setMod(e.elem("row close"), "state", "close");
						e.elem("opener").slideDown(80, function() {
							e.setMod(e.elem("opener"), "state", "open");
							$.cookie("b-topline-hide", true)
						})
					});
					return false
				});
				e.bindTo(e.elem("balance"), "click", function() {
					e.setMod("state", "balance");
					return false
				})
			},
			state: {
				msisdn: function() {
					var e = this;
					$.ajax("/sjs/megafonuser.json", {
						dataType: "text"
					}).done(function(s) {
						e.user = e.__self.jparse(s) || {};
						e.user.uap = e.user.uap || {};
						if (e.user.uap.cabinet_url) {
							var n = e.elem("link");
							n.attr("href", e.user.uap.cabinet_url);
							e.setMod(n, "visible", "yes")
						}
						if (e.user.msisdn) {
							var a = ["+" + e.user.msisdn.substr(0, 1), e.user.msisdn.substr(1, 3), e.user.msisdn.substr(4, 3), e.user.msisdn.substr(7)];
							e.elem("phone").text(a.join(" "));
							e.setMod("state", "balance")
						}
					})
				},
				balance: function() {
					var e = this;
					e.setMod(e.elem("balance"), "state", "loading");
					$.ajax("/abonent.json?action=balance", {
						dataType: "text"
					}).done(function(s) {
						e.user = e.user || {};
						e.user.balance = e.__self.jparse(s) || {};
						e.setMod(e.elem("balance"), "state", "ready");
						e.setMod("state", "ready");
						e.setMod("display", "visible")
					})
				},
				ready: function() {
					var e = this;
					e.user.balance.balance = e.user.balance.balance || "---";
					e.user.balance.balance = e.user.balance.balance.toString().replace(".", ",");
					e.elem("balanceVal").text(e.user.balance.balance);
					if (!e.hasMod(e.elem("opener"), "state", "open")) {
						e.setMod(e.elem("row close"), "state", "close")
					}
					if (!e.hasMod(e.elem("row close"), "state", "open")) {
						e.setMod(e.elem("opener"), "state", "open")
					}
					if (!$.cookie("b-topline-hide")) {
						e.setMod(e.elem("row close"), "state", "open");
						e.setMod(e.elem("opener"), "state", "close")
					}
				}
			}
		}
	}, {
		jparse: function(e) {
			return JSON.parse(e.length > 9 ? e.substr(9) : e)
		}
	});
	BEM.DOM.decl({
		name: "b-topline",
		modName: "mode",
		modVal: "square"
	}, {
		msisdn: false,
		balance: false,
		widgetHolder: false,
		onSetMod: {
			js: function() {
				this.widgetHolder = $(".b-options-form__topline");
				if (this.widgetHolder.length == 0) {
					return
				}
				this.askUser()
			}
		},
		askUser: function() {
			var e = this;
			$.ajax("/sjs/megafonuser.json", {
				dataType: "text"
			}).done(function(s) {
				var n = e.__self.jparse(s) || {};
				if (n.msisdn) {
					e.msisdn = ["+" + n.msisdn.substr(0, 1), n.msisdn.substr(1, 3), n.msisdn.substr(4, 3), n.msisdn.substr(7)].join(" ");
					e.askBalance()
				}
			})
		},
		askBalance: function() {
			var e = this;
			$.ajax("/abonent.json?action=balance", {
				dataType: "text"
			}).done(function(s) {
				var n = e.__self.jparse(s) || {};
				n = n.balance || "";
				n = n.toString().replace(".", ",");
				e.balance = n;
				e.render()
			})
		},
		render: function() {
			if (!this.msisdn || !this.balance) {
				return
			}
			this.widgetHolder.before(['<a class="b-topline_mode_square__content b-popup__lk-link">', '<span class="b-topline_mode_square__balance-section">', '<span class="b-topline_mode_square__text">Ваш баланс:</span>', '<div class="b-topline_mode_square__balance">', '<span class="b-topline_mode_square__balanceVal">' + this.balance + "</span>&nbsp;", '<span class="b-topline_mode_square__balanceText">&#8381;</span>', "</div>", "</span>", '<span class="b-topline_mode_square__phone-section">', '<span class="b-topline_mode_square__text">Ваш номер телефона:</span>', '<span class="b-topline_mode_square__phone">' + this.msisdn + "</span>", "</span>", "</a>"].join(""))
		}
	}, {
		jparse: function(e) {
			return JSON.parse(e.length > 9 ? e.substr(9) : e)
		}
	})
})();;
(function() {
	$(function() {
		"use strict";
		var t = function(t) {
			var e = t.data("js");
			e.subtitle = e.subtitle || "Проверьте, поддерживает ли Ваша SIM-карта и телефон Интернет 4G";
			t.before(['<div class="b-options__4gform-content">', '<form method="GET" action="/api/usim/check4g" class="b-options__4gform-form">', '<p class="b-options__4gform-text b-options__4gform-text_state_init">', e.subtitle, "</p>", '<span class="b-options__4gform-phone">', '<input type="text" class="b-options__4gform-phone-prefix" value="+7" readonly="readonly" />', '<input type="text" maxlength="10" name="msisdn" class="b-options__4gform-phone-number" />', "</span>", '<input type="submit" value="Проверить" class="b-options__4gform-check" />', "</form>", "</div>"].join(""));
			this.errors = {
				"spam-filter": "Недоступно в данный момент",
				"empty-msisdn": "Пожалуйста, введите ваш номер",
				"invalid-msisdn": "Проверьте, пожалуйста, номер",
				"uap-internal-error": "Внутренняя ошибка сервиса",
				"lte-internal-error": "Внутренняя ошибка сервиса",
				"data-resolve-error": "Ошибка получения данных",
				"simtype-resolve-error": "Ошибка получения данных",
				"devcaps-resolve-error": "Ошибка получения данных",
				sms: "Не удалось отправить СМС. Повторите позже"
			};
			this.msisdn = "";
			this.form = ".b-options__4gform-form";
			this.$prefix = $(".b-options__4gform-phone-prefix");
			this.$phone = $(".b-options__4gform-phone-number");
			this.$result = $(".b-options__4gform-text_state_init")
		};
		t.prototype.init = function() {
			var t = this;
			this.$phone.bem("b-phone-input");
			this.$prefix.on("mousedown", function() {
				t.$phone.focus();
				return false
			});
			$.ajax("/sjs/megafonuser.json", {
				dataType: "text"
			}).done(function(e) {
				var o = t.jparse(e) || {},
					r = $.trim(o.msisdn) || "";
				r = r.length === 11 ? r.substr(1) : r;
				t.msisdn = r;
				t.$phone.val(r).trigger("paste")
			});
			$(document).on("submit", this.form, $.proxy(this.onSubmit, this))
		};
		t.prototype.jparse = function(t) {
			return JSON.parse(t.charAt(0) === "w" ? t.substr(9) : t)
		};
		t.prototype.changeResult = function(t, e) {
			this.$result.addClass(t).text(e)
		};
		t.prototype.onSubmit = function(t) {
			t.preventDefault();
			var e = this.$phone.val().replace(/\D/g, "");
			if (e.length !== 10) {
				this.$result.addClass("b-options__4gform-text_state_error").text("Проверьте корректность введенного номера");
				return
			}
			this.$phone.removeClass("b-options__4gform-text_state_error");
			var o = this,
				r = $(this.form);
			var s = "msisdn=" + e;
			if (this.msisdn === e) {
				s = "mode=results"
			}
			$.ajax({
				url: r.attr("action"),
				data: s,
				method: "GET",
				cache: false,
				dataType: "text"
			}).done(function(t) {
				var e = o.jparse(t);
				if (e.error) {
					o.changeResult("b-options__4gform-text_state_error", o.errors[e.error] || "Внутренняя ошибка сервиса")
				} else if (e.msg) {
					var r = $.grep(BEM.blocks["b-popup-container"].getPopupContainers(), function(t) {
						return t.getInternalParamValue() === "internet-4g-widget"
					});
					r = r.length > 0 ? r[0] : false;
					if (!r) {
						return
					}
					var s = r.elem("result"),
						n = r.elem(e.msg);
					if (!s || !n) {
						return
					}
					s.hide();
					n.show();
					r.show()
				} else if (e.result === "ok") {
					o.$result.removeClass("b-options__4gform-text_state_error");
					o.changeResult("b-options__4gform-text_state_replied", "Ответ отправлен на указанный номер телефона")
				} else {
					o.changeResult("b-options__4gform-text_state_error", "Внутренняя ошибка сервиса")
				}
			}).fail(function() {
				o.changeResult("b-options__4gform-text_state_error", "Внутренняя ошибка сервиса")
			})
		};
		var e = $(".b-options-form__internet-4g");
		if (e.length > 0) {
			new t(e).init()
		}
	})
})();;
(function() {
	$(function() {
		"use strict";
		var t = [];
		var i = function(t, i, n) {
			this.parent = t;
			this.item = i;
			this.tag = n
		};
		i.prototype.parent = null;
		i.prototype.item = null;
		i.prototype.tag = null;
		i.prototype.animateItem = null;
		i.prototype.popupItem = null;
		i.prototype.init = function() {
			var t = this;
			t.animateItem = t.parent.find(".b-options__item__fake.b-options__position__" + t.tag);
			t.popupItem = t.parent.find(".b-options__column__popup.b-options__column__" + t.tag);
			t.item.on("click", function() {
				if (t.animateItem.attr("class").indexOf("right") != -1) {
					t.animateItem.css("right", $(this).css("margin-right"))
				}
				if (t.animateItem.attr("class").indexOf("left") != -1) {
					t.animateItem.css("left", "-" + $(this).css("margin-right"))
				}
				t.animateItem.show().css("zIndex", "3").animate({
					height: "100%",
					width: "100%"
				}, 500, function() {});
				t.popupItem.fadeIn(700);
				return false
			});
			t.popupItem.find(".b-options__popup__reset").on("click", function() {
				t.animateItem.hide().removeAttr("style");
				t.popupItem.removeAttr("style");
				return false
			})
		};
		$(".b-options__item__popup").each(function() {
			var n = $(this),
				e = n.parents(".b-options__wrap"),
				o = n.attr("class").split(/\s+/),
				p = o.length,
				s = null,
				a = null;
			for (s = 0; s < p; s++) {
				var r = o[s],
					_ = null;
				if (r.indexOf("b-options__position__") === 0) {
					a = r.substr("b-options__position__".length);
					break
				}
			}
			if (a) {
				_ = new i(e, n, a);
				_.init();
				t.push(_)
			}
		})
	})
})();;
(function() {
	BEM.DOM.decl("b-fox-banner", {
		linkBase: "//adfox.megafon.ru/218063/prepareCode",
		onSetMod: {
			js: function() {
				var e, t = this.params,
					i = [location.protocol, this.linkBase, "?pp=", t.pp, "&ps=", t.ps, "&p2=", t.p2, "&pct=", t.pct, "&plp=", t.plp, "&pli=", t.pli, "&pop=", t.pop, "&puid1=", t.puid1];
				t.random && i.push("&random=", t.random);
				e = new n(i.join(""), t.params || "", t.t);
				this.domElem.html(e.getBannerCode());
				e.createBanner()
			}
		}
	});

	function e() {
		var e;
		if (!t) e = this;
		else return t;
		this.phoneWidth = 767;
		this.tabletWidth = 1024;
		this.minWidth = 200;
		this.autoReloads = false;
		this.pc = "display";
		this.pad = "tablet";
		this.phone = "phone";
		this.rnd = function() {
			return Math.floor(Math.random() * 1e6)
		};
		this.pr = window.adfox_pr = typeof window.adfox_pr == "undefined" ? this.rnd() : window.adfox_pr;
		this.ref = escape(document.referrer);
		this.dl = escape(document.location);
		this.banners = [];
		this.state = "";
		this.prev = "";
		this.screen = function() {
			var e = this.getWidth();
			if (e > this.tabletWidth) {
				this.prev = this.state;
				this.state = this.pc
			} else if (e <= this.tabletWidth && e > this.phoneWidth) {
				this.prev = this.state;
				this.state = this.pad
			} else if (e <= this.phoneWidth) {
				this.prev = this.state;
				this.state = this.phone
			}
		};
		this.getWidth = function() {
			var e = window,
				t = document,
				i = t.documentElement,
				n = t.getElementsByTagName("body")[0],
				s = e.innerWidth || i.clientWidth || n.clientWidth;
			return s
		};
		this.removeBanner = function(e) {
			for (var i = 0; i < t.banners.length; i++) {
				if (t.banners[i] == e) {
					t.banners[i].ph.innerHTML = "";
					t.banners.splice(i, 1)
				}
			}
		};
		this.loadDefault = function(e, i, n, s) {
			clearTimeout(n);
			t.gDefaultElement(s, e)
		};
		this.gDefaultElement = function(e, i, n) {
			if (n) clearTimeout(n);
			if (e > 9 && e < 100) {
				setTimeout(function s() {
					if (typeof bmLinks == "function") bmLinks(e, i);
					else setTimeout(s, 30)
				}, 30)
			}
			if (e == 100) {
				setTimeout(function a() {
					if (typeof t.slider == "function") t.slider(i);
					else setTimeout(a, 30)
				}, 30)
			}
		};
		this.enterframe = function() {
			var e = this.pc,
				i = this.pad,
				n = this.phone;

			function s() {
				t.screen();
				for (var a = 0; a < t.banners.length; a++) {
					var o = t.banners[a];
					if (o.settings != "none") {
						if (t.parse(e, o.settings) || t.parse(i, o.settings) || t.parse(n, o.settings)) {
							o.ph.style.display = t.parse(t.state, o.settings) ? "none" : "block"
						}
						if (t.parse("scale", o.settings) && o.w != "") {
							var r = o.ph.parentNode.clientWidth / o.w < 1 ? o.ph.parentNode.clientWidth / o.w : 1;
							o.ph.style.width = Math.floor(r * o.w) + "px";
							if (parseInt(o.ph.style.width) < t.minWidth) {
								o.ph.style.width = Math.floor(t.minWidth) + "px"
							}
						}
					}
					if (t.autoReloads == true && (o.ph.style.display == "block" || o.ph.style.display == "")) {
						if (t.state != t.prev) {
							t.removeBanner(o);
							o.createBanner()
						}
					}
				}
				setTimeout(s, 200)
			}
			s()
		};
		this.parse = function(e, t) {
			var i = e.toLowerCase(),
				n = t.toLowerCase();
			return n.indexOf(i) != -1
		}
	}
	var t = new e;
	t.enterframe();
	var i = document.createElement("style");
	i.type = "text/css";
	i[i.innerText ? "innerText" : "textContent"] = "img{height:auto;}";
	document.getElementsByTagName("head")[0].appendChild(i);

	function n(e, i, n) {
		var a = this;
		this.pr1 = t.rnd();
		this.ph = null;
		this.date;
		this.iframe;
		this.settings = i || "none";
		this.link = e;
		this.w = "";
		this.defaultLoad = n;
		this.getCode = function(e) {
			var i = this.link,
				n = this.pr1,
				o = this.settings,
				r = function() {
					if (o != "") {
						if (t.parse(t.state, o)) {
							setTimeout(r, 30)
						} else {
							s(a.defaultLoad, n, i)
						}
					} else {
						s(a.defaultLoad, n, i)
					}
				};
			r()
		};
		this.getBannerCode = function() {
			var e = [];
			if (this.ph == "" || this.ph == null) {
				e.push('<div id="AdFox_banner_' + this.pr1 + '"></div>');
				e.push('<div style="visibility:hidden; position:absolute;"><iframe id="AdFox_iframe_' + this.pr1 + '" width=1 height=1 marginwidth=0 marginheight=0 scrolling=no frameborder=0></iframe></div>')
			}
			return e.join("")
		};
		this.createBanner = function() {
			var e = true,
				i;
			this.date = new Date;
			this.secParams = "&pr=" + t.pr + "&pt=b&pd=" + this.date.getDate() + "&pw=" + this.date.getDay() + "&pv=" + this.date.getHours() + "&prr=" + t.ref + "&dl=" + t.dl + "&pr1=" + this.pr1 + "&phid=AdFox_banner_" + this.pr1;
			for (var n = 0; n < t.banners.length; n++) {
				if (t.banners[n] == this) {
					e = false;
					break
				}
			}
			if (e) {
				t.banners.push(this);
				i = t.banners.length - 1
			}
			this.ph = document.getElementById("AdFox_banner_" + this.pr1);
			this.iframe = document.getElementById("AdFox_iframe_" + this.pr1);
			if (this.ph != null) {
				this.link = this.link.replace(/&amp;/g, "&");
				this.link += this.secParams;
				this.getCode(i)
			}
		}
	}

	function s(e, i, n) {
		var s = document.getElementsByTagName("script"),
			a, o, r = setTimeout(l, 1e4);
		s = s[s.length - 1];
		try {
			if (document.all && !window.opera) {
				a = window.frames["AdFox_iframe_" + i].document
			} else if (document.getElementById) {
				a = document.getElementById("AdFox_iframe_" + i).contentDocument
			}
			if (a) {
				if (+"1") {
					a.open();
					a.close()
				}
				n = n.replace(/&amp;/g, "&");
				o = a.createElement("script");
				o.src = n + "&pap1=" + r;
				o.onload = function() {
					clearTimeout(r);
					r = null
				};
				o.onerror = function() {
					clearTimeout(r);
					r = null;
					t.gDefaultElement(e, i)
				};
				o.onreadystatechange = function() {
					if (o.readyState == "complete") {
						clearTimeout(r);
						r = null
					}
				};
				d()
			}
		} catch (h) {
			t.loadDefault(i, s, r, e)
		}

		function d() {
			setTimeout(function() {
				var e = a.getElementsByTagName("head")[0];
				if (e) {
					e.appendChild(o)
				} else {
					d()
				}
			}, 30)
		}

		function l(n) {
			if (!r) {
				return
			}
			var a = document.getElementById("AdFox_iframe_" + i);
			a && a.parentNode.removeChild(a);
			t.loadDefault(i, s, r, e)
		}
	}

	function a(e, t) {
		document.getElementById(e).style.visibility = t
	}

	function o(e) {
		a("AdFox_DivBaseFlash_" + e, "hidden");
		a("AdFox_DivOverFlash_" + e, "visible")
	}

	function r(e) {
		a("AdFox_DivOverFlash_" + e, "hidden");
		a("AdFox_DivBaseFlash_" + e, "visible")
	}

	function h(e, t, i) {
		var n = document.getElementById("adfoxBanner" + e).style;
		if (t == "100%") n.width = t;
		else n.width = t + "px"; if (i == "100%") n.height = i;
		else n.height = i + "px"
	}

	function d(e, t, i) {
		var n = document.getElementById(e).style;
		if (t == "100%") n.width = t;
		else n.width = t + "px"; if (i == "100%") n.height = i;
		else n.height = i + "px"
	}

	function l(e, t, i, n, s, a, o, r) {
		if (t == 1) d("adfoxFlash1" + e, s, a);
		else if (t == 2) {
			d("adfoxFlash2" + e, o, r);
			if (i == "yes") d("adfoxFlash1" + e, s, a);
			if (n == "yes") h(e, o, r);
			else h(e, s, a)
		}
	}

	function f(e, t, i, n, s) {
		var a = new Image;
		var o = document.getElementById("aEventOpen" + e);
		if (o) a.src = o.title + "&rand=" + Math.random() * 1e6 + "&prb=" + Math.random() * 1e6;
		d("adfoxFlash2" + e, n, s);
		if (t != "yes") d("adfoxFlash1" + e, 1, 1);
		if (i == "yes") h(e, n, s)
	}

	function p(e, t, i, n, s) {
		var a = new Image;
		var o = document.getElementById("aEventClose" + e);
		if (o) a.src = o.title + "&rand=" + Math.random() * 1e6 + "&prb=" + Math.random() * 1e6;
		d("adfoxFlash2" + e, 1, 1);
		if (t != "yes") d("adfoxFlash1" + e, n, s);
		if (i == "yes") h(e, n, s)
	}
})();;
(function() {
	(function() {
		window.device = {};
		_user_agent = window.navigator.userAgent.toLowerCase();
		device.windows = function() {
			return _find("windows")
		};
		device.windowsTablet = function() {
			return device.windows() && _find("touch")
		};
		device.tablet = function() {
			return device.windowsTablet()
		};
		_find = function(n) {
			return _user_agent.indexOf(n) !== -1
		}
	}).call(this);
	$(function() {
		var n = "ontouchstart" in window ? true : false;
		var e = device.windowsTablet();
		var i = $(".b-additionalmenu__item-customers");
		var a = $("#b-additionalmenu__wrapper");
		var t = $(".b-additionalmenu__submenu");
		var d = "b-additionalmenu__item-hover";
		var o = $(".b-additionalmenu__submenu-link-scroller");
		var s = $(".b-additionalmenu__submenu-link");
		var l = $(".b-additionalmenu__item-cities");
		var u = /iPad/.test(window.navigator.userAgent);
		var r = u ? "touchend" : "click";
		var m;
		a.bind("touchmove", function() {
			m = true
		});
		if (n || e) {
			l.bind(r, function() {
				if (!m) {
					l.toggleClass(d);
					a.toggleClass("b-additionalmenu__wrapper")
				}
				m = false
			});
			i.bind(r, function() {
				i.toggleClass(d);
				$(".b-additionalmenu__submenu").toggleClass("b-additionalmenu__submenu-customers")
			})
		} else {
			l.bind({
				mouseenter: function() {
					l.addClass(d);
					$(".b-additionalmenu-item__link-scroller").addClass("b-additionalmenu-item__link-hover");
					a.removeClass("b-additionalmenu__wrapper")
				},
				mouseleave: function() {
					l.removeClass(d);
					$(".b-additionalmenu-item__link-scroller").removeClass("b-additionalmenu-item__link-hover");
					a.addClass("b-additionalmenu__wrapper")
				},
				click: function() {
					l.removeClass(d);
					a.addClass("b-additionalmenu__wrapper")
				}
			});
			i.bind({
				mouseenter: function() {
					i.addClass(d);
					$(".b-additionalmenu-item__link").addClass("b-additionalmenu-item__link-hover");
					$(".b-additionalmenu__submenu").removeClass("b-additionalmenu__submenu-customers")
				},
				mouseleave: function() {
					i.removeClass(d);
					$(".b-additionalmenu-item__link").removeClass("b-additionalmenu-item__link-hover");
					$(".b-additionalmenu__submenu").addClass("b-additionalmenu__submenu-customers")
				},
				click: function() {
					i.removeClass(d);
					$(".b-additionalmenu__submenu").addClass("b-additionalmenu__submenu-customers")
				}
			})
		}
		o.bind(r, function() {
			if (!m) {
				var n = $(this).text();
				l.children(".b-additionalmenu-item__link-scroller").text(n);
				o.removeClass("b-additionalmenu__submenu-link-hover");
				$(this).addClass("b-additionalmenu__submenu-link-hover")
			}
		});
		s.bind(r, function() {
			var n = $(this).text();
			$(".b-additionalmenu__item-customers").children(".b-additionalmenu-item__link").text(n);
			s.removeClass("b-additionalmenu__submenu-link-hover");
			$(this).addClass("b-additionalmenu__submenu-link-hover")
		});
		setTimeout(function() {
			$(".p__body").bind(r, function(n) {
				if (!$(n.target).hasClass("b-additionalmenu-item__link-scroller") && !$(n.target).closest(".b-additionalmenu__wrapper-click").length) {
					l.removeClass("b-additionalmenu__item-hover");
					a.addClass("b-additionalmenu__wrapper")
				}
				if (!$(n.target).hasClass("b-additionalmenu-item__link") && !$(n.target).closest(".b-additionalmenu__submenu").length) {
					i.removeClass("b-additionalmenu__item-hover");
					t.addClass("b-additionalmenu__submenu-customers")
				}
			})
		}, 10);
		var _ = $(".b-dropdown"),
			a = _.find(".b-dropdown__list-wrap");
		_.bind({
			mouseenter: function() {
				setTimeout(function() {
					var n = a.find(".b-dropdown__link-hover"),
						e = a.find(".b-dropdown__link").outerHeight();
					a.scrollTop(e * n.parent().index() + 5)
				}, 50)
			}
		})
	})
})();;
(function() {
	$(function() {
		$(".b-menu__item").mouseover(function() {
			$(this).addClass("b-menu__item_active")
		}).mouseleave(function() {
			$(this).removeClass("b-menu__item_active")
		})
	})
})();;
(function() {
	! function(e, t) {
		"use strict";

		function n() {
			r.READY || (T.determineEventTypes(), E.each(r.gestures, function(e) {
				M.register(e)
			}), T.onTouch(r.DOCUMENT, d, M.detect), T.onTouch(r.DOCUMENT, g, M.detect), r.READY = !0)
		}
		var r = function y(e, t) {
			return new y.Instance(e, t || {})
		};
		r.VERSION = "1.1.3", r.defaults = {
			behavior: {
				userSelect: "none",
				touchAction: "pan-y",
				touchCallout: "none",
				contentZooming: "none",
				userDrag: "none",
				tapHighlightColor: "rgba(0,0,0,0)"
			}
		}, r.DOCUMENT = document, r.HAS_POINTEREVENTS = navigator.pointerEnabled || navigator.msPointerEnabled, r.HAS_TOUCHEVENTS = "ontouchstart" in e, r.IS_MOBILE = /mobile|tablet|ip(ad|hone|od)|android|silk/i.test(navigator.userAgent), r.NO_MOUSEEVENTS = r.HAS_TOUCHEVENTS && r.IS_MOBILE || r.HAS_POINTEREVENTS, r.CALCULATE_INTERVAL = 25;
		var i = {},
			a = r.DIRECTION_DOWN = "down",
			o = r.DIRECTION_LEFT = "left",
			s = r.DIRECTION_UP = "up",
			c = r.DIRECTION_RIGHT = "right",
			u = r.POINTER_MOUSE = "mouse",
			l = r.POINTER_TOUCH = "touch",
			h = r.POINTER_PEN = "pen",
			p = r.EVENT_START = "start",
			d = r.EVENT_MOVE = "move",
			g = r.EVENT_END = "end",
			f = r.EVENT_RELEASE = "release",
			v = r.EVENT_TOUCH = "touch";
		r.READY = !1, r.plugins = r.plugins || {}, r.gestures = r.gestures || {};
		var E = r.utils = {
				extend: function(e, n, r) {
					for (var i in n)!n.hasOwnProperty(i) || e[i] !== t && r || (e[i] = n[i]);
					return e
				},
				on: function(e, t, n) {
					e.addEventListener(t, n, !1)
				},
				off: function(e, t, n) {
					e.removeEventListener(t, n, !1)
				},
				each: function(e, n, r) {
					var i, a;
					if ("forEach" in e) e.forEach(n, r);
					else if (e.length !== t) {
						for (i = 0, a = e.length; a > i; i++)
							if (n.call(r, e[i], i, e) === !1) return
					} else
						for (i in e)
							if (e.hasOwnProperty(i) && n.call(r, e[i], i, e) === !1) return
				},
				inStr: function(e, t) {
					return e.indexOf(t) > -1
				},
				inArray: function(e, t) {
					if (e.indexOf) {
						var n = e.indexOf(t);
						return -1 === n ? !1 : n
					}
					for (var r = 0, i = e.length; i > r; r++)
						if (e[r] === t) return r;
					return !1
				},
				toArray: function(e) {
					return Array.prototype.slice.call(e, 0)
				},
				hasParent: function(e, t) {
					for (; e;) {
						if (e == t) return !0;
						e = e.parentNode
					}
					return !1
				},
				getCenter: function(e) {
					var t = [],
						n = [],
						r = [],
						i = [],
						a = Math.min,
						o = Math.max;
					return 1 === e.length ? {
						pageX: e[0].pageX,
						pageY: e[0].pageY,
						clientX: e[0].clientX,
						clientY: e[0].clientY
					} : (E.each(e, function(e) {
						t.push(e.pageX), n.push(e.pageY), r.push(e.clientX), i.push(e.clientY)
					}), {
						pageX: (a.apply(Math, t) + o.apply(Math, t)) / 2,
						pageY: (a.apply(Math, n) + o.apply(Math, n)) / 2,
						clientX: (a.apply(Math, r) + o.apply(Math, r)) / 2,
						clientY: (a.apply(Math, i) + o.apply(Math, i)) / 2
					})
				},
				getVelocity: function(e, t, n) {
					return {
						x: Math.abs(t / e) || 0,
						y: Math.abs(n / e) || 0
					}
				},
				getAngle: function(e, t) {
					var n = t.clientX - e.clientX,
						r = t.clientY - e.clientY;
					return 180 * Math.atan2(r, n) / Math.PI
				},
				getDirection: function(e, t) {
					var n = Math.abs(e.clientX - t.clientX),
						r = Math.abs(e.clientY - t.clientY);
					return n >= r ? e.clientX - t.clientX > 0 ? o : c : e.clientY - t.clientY > 0 ? s : a
				},
				getDistance: function(e, t) {
					var n = t.clientX - e.clientX,
						r = t.clientY - e.clientY;
					return Math.sqrt(n * n + r * r)
				},
				getScale: function(e, t) {
					return e.length >= 2 && t.length >= 2 ? this.getDistance(t[0], t[1]) / this.getDistance(e[0], e[1]) : 1
				},
				getRotation: function(e, t) {
					return e.length >= 2 && t.length >= 2 ? this.getAngle(t[1], t[0]) - this.getAngle(e[1], e[0]) : 0
				},
				isVertical: function(e) {
					return e == s || e == a
				},
				setPrefixedCss: function(e, t, n, r) {
					var i = ["", "Webkit", "Moz", "O", "ms"];
					t = E.toCamelCase(t);
					for (var a = 0; a < i.length; a++) {
						var o = t;
						if (i[a] && (o = i[a] + o.slice(0, 1).toUpperCase() + o.slice(1)), o in e.style) {
							e.style[o] = (null == r || r) && n || "";
							break
						}
					}
				},
				toggleBehavior: function(e, t, n) {
					if (t && e && e.style) {
						E.each(t, function(t, r) {
							E.setPrefixedCss(e, r, t, n)
						});
						var r = n && function() {
							return !1
						};
						"none" == t.userSelect && (e.onselectstart = r), "none" == t.userDrag && (e.ondragstart = r)
					}
				},
				toCamelCase: function(e) {
					return e.replace(/[_-]([a-z])/g, function(e) {
						return e[1].toUpperCase()
					})
				}
			},
			T = r.event = {
				preventMouseEvents: !1,
				started: !1,
				shouldDetect: !1,
				on: function(e, t, n, r) {
					var i = t.split(" ");
					E.each(i, function(t) {
						E.on(e, t, n), r && r(t)
					})
				},
				off: function(e, t, n, r) {
					var i = t.split(" ");
					E.each(i, function(t) {
						E.off(e, t, n), r && r(t)
					})
				},
				onTouch: function(e, t, n) {
					var a = this,
						o = function(i) {
							var o, s = i.type.toLowerCase(),
								c = r.HAS_POINTEREVENTS,
								u = E.inStr(s, "mouse");
							u && a.preventMouseEvents || (u && t == p && 0 === i.button ? (a.preventMouseEvents = !1, a.shouldDetect = !0) : c && t == p ? a.shouldDetect = 1 === i.buttons || m.matchType(l, i) : u || t != p || (a.preventMouseEvents = !0, a.shouldDetect = !0), c && t != g && m.updatePointer(t, i), a.shouldDetect && (o = a.doDetect.call(a, i, t, e, n)), o == g && (a.preventMouseEvents = !1, a.shouldDetect = !1, m.reset()), c && t == g && m.updatePointer(t, i))
						};
					return this.on(e, i[t], o), o
				},
				doDetect: function(e, t, n, r) {
					var i = this.getTouchList(e, t),
						a = i.length,
						o = t,
						s = i.trigger,
						c = a;
					t == p ? s = v : t == g && (s = f, c = i.length - (e.changedTouches ? e.changedTouches.length : 1)), c > 0 && this.started && (o = d), this.started = !0;
					var u = this.collectEventData(n, o, i, e);
					return t != g && r.call(M, u), s && (u.changedLength = c, u.eventType = s, r.call(M, u), u.eventType = o, delete u.changedLength), o == g && (r.call(M, u), this.started = !1), o
				},
				determineEventTypes: function() {
					var t;
					return t = r.HAS_POINTEREVENTS ? e.PointerEvent ? ["pointerdown", "pointermove", "pointerup pointercancel lostpointercapture"] : ["MSPointerDown", "MSPointerMove", "MSPointerUp MSPointerCancel MSLostPointerCapture"] : r.NO_MOUSEEVENTS ? ["touchstart", "touchmove", "touchend touchcancel"] : ["touchstart mousedown", "touchmove mousemove", "touchend touchcancel mouseup"], i[p] = t[0], i[d] = t[1], i[g] = t[2], i
				},
				getTouchList: function(e, t) {
					if (r.HAS_POINTEREVENTS) return m.getTouchList();
					if (e.touches) {
						if (t == d) return e.touches;
						var n = [],
							i = [].concat(E.toArray(e.touches), E.toArray(e.changedTouches)),
							a = [];
						return E.each(i, function(e) {
							E.inArray(n, e.identifier) === !1 && a.push(e), n.push(e.identifier)
						}), a
					}
					return e.identifier = 1, [e]
				},
				collectEventData: function(e, t, n, r) {
					var i = l;
					return E.inStr(r.type, "mouse") || m.matchType(u, r) ? i = u : m.matchType(h, r) && (i = h), {
						center: E.getCenter(n),
						timeStamp: Date.now(),
						target: r.target,
						touches: n,
						eventType: t,
						pointerType: i,
						srcEvent: r,
						preventDefault: function() {
							var e = this.srcEvent;
							e.preventManipulation && e.preventManipulation(), e.preventDefault && e.preventDefault()
						},
						stopPropagation: function() {
							this.srcEvent.stopPropagation()
						},
						stopDetect: function() {
							return M.stopDetect()
						}
					}
				}
			},
			m = r.PointerEvent = {
				pointers: {},
				getTouchList: function() {
					var e = [];
					return E.each(this.pointers, function(t) {
						e.push(t)
					}), e
				},
				updatePointer: function(e, t) {
					e == g || e != g && 1 !== t.buttons ? delete this.pointers[t.pointerId] : (t.identifier = t.pointerId, this.pointers[t.pointerId] = t)
				},
				matchType: function(e, t) {
					if (!t.pointerType) return !1;
					var n = t.pointerType,
						r = {};
					return r[u] = n === (t.MSPOINTER_TYPE_MOUSE || u), r[l] = n === (t.MSPOINTER_TYPE_TOUCH || l), r[h] = n === (t.MSPOINTER_TYPE_PEN || h), r[e]
				},
				reset: function() {
					this.pointers = {}
				}
			},
			M = r.detection = {
				gestures: [],
				current: null,
				previous: null,
				stopped: !1,
				startDetect: function(e, t) {
					this.current || (this.stopped = !1, this.current = {
						inst: e,
						startEvent: E.extend({}, t),
						lastEvent: !1,
						lastCalcEvent: !1,
						futureCalcEvent: !1,
						lastCalcData: {},
						name: ""
					}, this.detect(t))
				},
				detect: function(e) {
					if (this.current && !this.stopped) {
						e = this.extendEventData(e);
						var t = this.current.inst,
							n = t.options;
						return E.each(this.gestures, function(r) {
							!this.stopped && t.enabled && n[r.name] && r.handler.call(r, e, t)
						}, this), this.current && (this.current.lastEvent = e), e.eventType == g && this.stopDetect(), e
					}
				},
				stopDetect: function() {
					this.previous = E.extend({}, this.current), this.current = null, this.stopped = !0
				},
				getCalculatedData: function(e, t, n, i, a) {
					var o = this.current,
						s = !1,
						c = o.lastCalcEvent,
						u = o.lastCalcData;
					c && e.timeStamp - c.timeStamp > r.CALCULATE_INTERVAL && (t = c.center, n = e.timeStamp - c.timeStamp, i = e.center.clientX - c.center.clientX, a = e.center.clientY - c.center.clientY, s = !0), (e.eventType == v || e.eventType == f) && (o.futureCalcEvent = e), (!o.lastCalcEvent || s) && (u.velocity = E.getVelocity(n, i, a), u.angle = E.getAngle(t, e.center), u.direction = E.getDirection(t, e.center), o.lastCalcEvent = o.futureCalcEvent || e, o.futureCalcEvent = e), e.velocityX = u.velocity.x, e.velocityY = u.velocity.y, e.interimAngle = u.angle, e.interimDirection = u.direction
				},
				extendEventData: function(e) {
					var t = this.current,
						n = t.startEvent,
						r = t.lastEvent || n;
					(e.eventType == v || e.eventType == f) && (n.touches = [], E.each(e.touches, function(e) {
						n.touches.push({
							clientX: e.clientX,
							clientY: e.clientY
						})
					}));
					var i = e.timeStamp - n.timeStamp,
						a = e.center.clientX - n.center.clientX,
						o = e.center.clientY - n.center.clientY;
					return this.getCalculatedData(e, r.center, i, a, o), E.extend(e, {
						startEvent: n,
						deltaTime: i,
						deltaX: a,
						deltaY: o,
						distance: E.getDistance(n.center, e.center),
						angle: E.getAngle(n.center, e.center),
						direction: E.getDirection(n.center, e.center),
						scale: E.getScale(n.touches, e.touches),
						rotation: E.getRotation(n.touches, e.touches)
					}), e
				},
				register: function(e) {
					var n = e.defaults || {};
					return n[e.name] === t && (n[e.name] = !0), E.extend(r.defaults, n, !0), e.index = e.index || 1e3, this.gestures.push(e), this.gestures.sort(function(e, t) {
						return e.index < t.index ? -1 : e.index > t.index ? 1 : 0
					}), this.gestures
				}
			};
		r.Instance = function(e, t) {
			var i = this;
			n(), this.element = e, this.enabled = !0, E.each(t, function(e, n) {
				delete t[n], t[E.toCamelCase(n)] = e
			}), this.options = E.extend(E.extend({}, r.defaults), t || {}), this.options.behavior && E.toggleBehavior(this.element, this.options.behavior, !0), this.eventStartHandler = T.onTouch(e, p, function(e) {
				i.enabled && e.eventType == p ? M.startDetect(i, e) : e.eventType == v && M.detect(e)
			}), this.eventHandlers = []
		}, r.Instance.prototype = {
			on: function(e, t) {
				var n = this;
				return T.on(n.element, e, t, function(e) {
					n.eventHandlers.push({
						gesture: e,
						handler: t
					})
				}), n
			},
			off: function(e, t) {
				var n = this;
				return T.off(n.element, e, t, function(e) {
					var r = E.inArray({
						gesture: e,
						handler: t
					});
					r !== !1 && n.eventHandlers.splice(r, 1)
				}), n
			},
			trigger: function(e, t) {
				t || (t = {});
				var n = r.DOCUMENT.createEvent("Event");
				n.initEvent(e, !0, !0), n.gesture = t;
				var i = this.element;
				return E.hasParent(t.target, i) && (i = t.target), i.dispatchEvent(n), this
			},
			enable: function(e) {
				return this.enabled = e, this
			},
			dispose: function() {
				var e, t;
				for (E.toggleBehavior(this.element, this.options.behavior, !1), e = -1; t = this.eventHandlers[++e];) E.off(this.element, t.gesture, t.handler);
				return this.eventHandlers = [], T.off(this.element, i[p], this.eventStartHandler), null
			}
		},
		function(e) {
			function t(t, r) {
				var i = M.current;
				if (!(r.options.dragMaxTouches > 0 && t.touches.length > r.options.dragMaxTouches)) switch (t.eventType) {
					case p:
						n = !1;
						break;
					case d:
						if (t.distance < r.options.dragMinDistance && i.name != e) return;
						var u = i.startEvent.center;
						if (i.name != e && (i.name = e, r.options.dragDistanceCorrection && t.distance > 0)) {
							var l = Math.abs(r.options.dragMinDistance / t.distance);
							u.pageX += t.deltaX * l, u.pageY += t.deltaY * l, u.clientX += t.deltaX * l, u.clientY += t.deltaY * l, t = M.extendEventData(t)
						}(i.lastEvent.dragLockToAxis || r.options.dragLockToAxis && r.options.dragLockMinDistance <= t.distance) && (t.dragLockToAxis = !0);
						var h = i.lastEvent.direction;
						t.dragLockToAxis && h !== t.direction && (t.direction = E.isVertical(h) ? t.deltaY < 0 ? s : a : t.deltaX < 0 ? o : c), n || (r.trigger(e + "start", t), n = !0), r.trigger(e, t), r.trigger(e + t.direction, t);
						var v = E.isVertical(t.direction);
						(r.options.dragBlockVertical && v || r.options.dragBlockHorizontal && !v) && t.preventDefault();
						break;
					case f:
						n && t.changedLength <= r.options.dragMaxTouches && (r.trigger(e + "end", t), n = !1);
						break;
					case g:
						n = !1
				}
			}
			var n = !1;
			r.gestures.Drag = {
				name: e,
				index: 50,
				handler: t,
				defaults: {
					dragMinDistance: 10,
					dragDistanceCorrection: !0,
					dragMaxTouches: 1,
					dragBlockHorizontal: !1,
					dragBlockVertical: !1,
					dragLockToAxis: !1,
					dragLockMinDistance: 25
				}
			}
		}("drag"), r.gestures.Gesture = {
			name: "gesture",
			index: 1337,
			handler: function(e, t) {
				t.trigger(this.name, e)
			}
		},
		function(e) {
			function t(t, r) {
				var i = r.options,
					a = M.current;
				switch (t.eventType) {
					case p:
						clearTimeout(n), a.name = e, n = setTimeout(function() {
							a && a.name == e && r.trigger(e, t)
						}, i.holdTimeout);
						break;
					case d:
						t.distance > i.holdThreshold && clearTimeout(n);
						break;
					case f:
						clearTimeout(n)
				}
			}
			var n;
			r.gestures.Hold = {
				name: e,
				index: 10,
				defaults: {
					holdTimeout: 500,
					holdThreshold: 2
				},
				handler: t
			}
		}("hold"), r.gestures.Release = {
			name: "release",
			index: 1 / 0,
			handler: function(e, t) {
				e.eventType == f && t.trigger(this.name, e)
			}
		}, r.gestures.Swipe = {
			name: "swipe",
			index: 40,
			defaults: {
				swipeMinTouches: 1,
				swipeMaxTouches: 1,
				swipeVelocityX: .6,
				swipeVelocityY: .6
			},
			handler: function(e, t) {
				if (e.eventType == f) {
					var n = e.touches.length,
						r = t.options;
					if (n < r.swipeMinTouches || n > r.swipeMaxTouches) return;
					(e.velocityX > r.swipeVelocityX || e.velocityY > r.swipeVelocityY) && (t.trigger(this.name, e), t.trigger(this.name + e.direction, e))
				}
			}
		},
		function(e) {
			function t(t, r) {
				var i, a, o = r.options,
					s = M.current,
					c = M.previous;
				switch (t.eventType) {
					case p:
						n = !1;
						break;
					case d:
						n = n || t.distance > o.tapMaxDistance;
						break;
					case g:
						!E.inStr(t.srcEvent.type, "cancel") && t.deltaTime < o.tapMaxTime && !n && (i = c && c.lastEvent && t.timeStamp - c.lastEvent.timeStamp, a = !1, c && c.name == e && i && i < o.doubleTapInterval && t.distance < o.doubleTapDistance && (r.trigger("doubletap", t), a = !0), (!a || o.tapAlways) && (s.name = e, r.trigger(s.name, t)))
				}
			}
			var n = !1;
			r.gestures.Tap = {
				name: e,
				index: 100,
				handler: t,
				defaults: {
					tapMaxTime: 250,
					tapMaxDistance: 10,
					tapAlways: !0,
					doubleTapDistance: 20,
					doubleTapInterval: 300
				}
			}
		}("tap"), r.gestures.Touch = {
			name: "touch",
			index: -1 / 0,
			defaults: {
				preventDefault: !1,
				preventMouse: !1
			},
			handler: function(e, t) {
				return t.options.preventMouse && e.pointerType == u ? void e.stopDetect() : (t.options.preventDefault && e.preventDefault(), void(e.eventType == v && t.trigger("touch", e)))
			}
		},
		function(e) {
			function t(t, r) {
				switch (t.eventType) {
					case p:
						n = !1;
						break;
					case d:
						if (t.touches.length < 2) return;
						var i = Math.abs(1 - t.scale),
							a = Math.abs(t.rotation);
						if (i < r.options.transformMinScale && a < r.options.transformMinRotation) return;
						M.current.name = e, n || (r.trigger(e + "start", t), n = !0), r.trigger(e, t), a > r.options.transformMinRotation && r.trigger("rotate", t), i > r.options.transformMinScale && (r.trigger("pinch", t), r.trigger("pinch" + (t.scale < 1 ? "in" : "out"), t));
						break;
					case f:
						n && t.changedLength < 2 && (r.trigger(e + "end", t), n = !1)
				}
			}
			var n = !1;
			r.gestures.Transform = {
				name: e,
				index: 45,
				defaults: {
					transformMinScale: .01,
					transformMinRotation: 1
				},
				handler: t
			}
		}("transform"), "function" == typeof define && define.amd ? define(function() {
			return r
		}) : "undefined" != typeof module && module.exports ? module.exports = r : e.Hammer = r
	}(window)
})();;
(function() {
	$(function() {
		"use strict";
		var e = window.globalStorage || {},
			n = window._promo_dummy || {};
		n = "object" === typeof n ? n : {};
		n = "number" === typeof n.length ? {} : n;

		function i() {
			var i = $(".b-banners-slider__spacer").outerHeight(),
				a = null;
			a = e.IS_MOBILE && !e.IS_TABLET ? n.image_mobile : n.image;
			$(".b-banners-slider__link, .b-banners-slider__viewpoint").outerHeight(i);
			$(".b-banners-slider__bg").css("filter", ["progid:DXImageTransform.Microsoft.AlphaImageLoader(src='", a, "',sizingMethod='scale')"].join("")).css("background-image", ["url(", a, ")"].join(""))
		}

		function a() {
			var e = $("<div/>"),
				i = $("<a/>"),
				a = $("<div/>"),
				s = $("<span/>");
			e.addClass("b-banners-slider__viewpoint");
			a.addClass("b-banners-slider__bg");
			i.addClass("b-banners-slider__link");
			i.addClass("b-banners-slider__active");
			i.prop("href", n.href);
			if (n.new_window) {
				i.prop("target", "_blank")
			}
			s.addClass("b-banners-slider__spacer");
			a.append(s);
			i.append(a);
			e.append(i);
			$(".b-banners-slider").html(e)
		}
		if (!window._promo_adblock_disabled) {
			r()
		} else {
			setTimeout(r, 500)
		}

		function s() {
			$(window).off("resize", i).off("adfox-loaded", s)
		}

		function r() {
			var e = $(".b-banners-slider");
			Hammer(e.get(0)).on("dragleft swipeleft", function() {
				if (!e.data("isAnimated")) {
					$(".b-banners-simple-slider__navy-button_action_next").click()
				}
			}).on("dragright swiperight", function() {
				if (!e.data("isAnimated")) {
					$(".b-banners-simple-slider__navy-button_action_prev").click()
				}
			});
			if ($("html").hasClass("ua_adfox_yes")) {
				return
			}
			$(window).on("resize", i).on("adfox-loaded", s);
			a();
			i()
		}
	})
})();;
(function() {
	window.Modernizr = function(e, t, n) {
		function r(e) {
			h.cssText = e
		}

		function o(e, t) {
			return r(v.join(e + ";") + (t || ""))
		}

		function i(e, t) {
			return typeof e === t
		}

		function a(e, t) {
			return !!~("" + e).indexOf(t)
		}

		function c(e, t, r) {
			for (var o in e) {
				var a = t[e[o]];
				if (a !== n) return r === !1 ? e[o] : i(a, "function") ? a.bind(r || t) : a
			}
			return !1
		}
		var l = "2.8.2",
			s = {},
			u = !0,
			f = t.documentElement,
			d = "modernizr",
			p = t.createElement(d),
			h = p.style,
			m, y = {}.toString,
			v = " -webkit- -moz- -o- -ms- ".split(" "),
			g = {},
			b = {},
			E = {},
			j = [],
			C = j.slice,
			w, S = function(e, n, r, o) {
				var i, a, c, l, s = t.createElement("div"),
					u = t.body,
					p = u || t.createElement("body");
				if (parseInt(r, 10))
					while (r--) c = t.createElement("div"), c.id = o ? o[r] : d + (r + 1), s.appendChild(c);
				return i = ["&#173;", '<style id="s', d, '">', e, "</style>"].join(""), s.id = d, (u ? s : p).innerHTML += i, p.appendChild(s), u || (p.style.background = "", p.style.overflow = "hidden", l = f.style.overflow, f.style.overflow = "hidden", f.appendChild(p)), a = n(s, e), u ? s.parentNode.removeChild(s) : (p.parentNode.removeChild(p), f.style.overflow = l), !!a
			},
			N = {}.hasOwnProperty,
			x;
		!i(N, "undefined") && !i(N.call, "undefined") ? x = function(e, t) {
			return N.call(e, t)
		} : x = function(e, t) {
			return t in e && i(e.constructor.prototype[t], "undefined")
		}, Function.prototype.bind || (Function.prototype.bind = function(e) {
			var t = this;
			if (typeof t != "function") throw new TypeError;
			var n = C.call(arguments, 1),
				r = function() {
					if (this instanceof r) {
						var o = function() {};
						o.prototype = t.prototype;
						var i = new o,
							a = t.apply(i, n.concat(C.call(arguments)));
						return Object(a) === a ? a : i
					}
					return t.apply(e, n.concat(C.call(arguments)))
				};
			return r
		}), g.touch = function() {
			var n;
			return "ontouchstart" in e || e.DocumentTouch && t instanceof DocumentTouch ? n = !0 : S(["@media (", v.join("touch-enabled),("), d, ")", "{#modernizr{top:9px;position:absolute}}"].join(""), function(e) {
				n = e.offsetTop === 9
			}), n
		};
		for (var T in g) x(g, T) && (w = T.toLowerCase(), s[w] = g[T](), j.push((s[w] ? "" : "no-") + w));
		return s.addTest = function(e, t) {
				if (typeof e == "object")
					for (var r in e) x(e, r) && s.addTest(r, e[r]);
				else {
					e = e.toLowerCase();
					if (s[e] !== n) return s;
					t = typeof t == "function" ? t() : t, typeof u != "undefined" && u && (f.className += " " + (t ? "" : "no-") + e), s[e] = t
				}
				return s
			}, r(""), p = m = null,
			function(e, t) {
				function n(e, t) {
					var n = e.createElement("p"),
						r = e.getElementsByTagName("head")[0] || e.documentElement;
					return n.innerHTML = "x<style>" + t + "</style>", r.insertBefore(n.lastChild, r.firstChild)
				}

				function r() {
					var e = g.elements;
					return typeof e == "string" ? e.split(" ") : e
				}

				function o(e) {
					var t = y[e[h]];
					return t || (t = {}, m++, e[h] = m, y[m] = t), t
				}

				function i(e, n, r) {
					n || (n = t);
					if (v) return n.createElement(e);
					r || (r = o(n));
					var i;
					return r.cache[e] ? i = r.cache[e].cloneNode() : d.test(e) ? i = (r.cache[e] = r.createElem(e)).cloneNode() : i = r.createElem(e), i.canHaveChildren && !f.test(e) && !i.tagUrn ? r.frag.appendChild(i) : i
				}

				function a(e, n) {
					e || (e = t);
					if (v) return e.createDocumentFragment();
					n = n || o(e);
					var i = n.frag.cloneNode(),
						a = 0,
						c = r(),
						l = c.length;
					for (; a < l; a++) i.createElement(c[a]);
					return i
				}

				function c(e, t) {
					t.cache || (t.cache = {}, t.createElem = e.createElement, t.createFrag = e.createDocumentFragment, t.frag = t.createFrag()), e.createElement = function(n) {
						return g.shivMethods ? i(n, e, t) : t.createElem(n)
					}, e.createDocumentFragment = Function("h,f", "return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&(" + r().join().replace(/[\w\-]+/g, function(e) {
						return t.createElem(e), t.frag.createElement(e), 'c("' + e + '")'
					}) + ");return n}")(g, t.frag)
				}

				function l(e) {
					e || (e = t);
					var r = o(e);
					return g.shivCSS && !p && !r.hasCSS && (r.hasCSS = !!n(e, "article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")), v || c(e, r), e
				}
				var s = "3.7.0",
					u = e.html5 || {},
					f = /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,
					d = /^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,
					p, h = "_html5shiv",
					m = 0,
					y = {},
					v;
				(function() {
					try {
						var e = t.createElement("a");
						e.innerHTML = "<xyz></xyz>", p = "hidden" in e, v = e.childNodes.length == 1 || function() {
							t.createElement("a");
							var e = t.createDocumentFragment();
							return typeof e.cloneNode == "undefined" || typeof e.createDocumentFragment == "undefined" || typeof e.createElement == "undefined"
						}()
					} catch (n) {
						p = !0, v = !0
					}
				})();
				var g = {
					elements: u.elements || "abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",
					version: s,
					shivCSS: u.shivCSS !== !1,
					supportsUnknownElements: v,
					shivMethods: u.shivMethods !== !1,
					type: "default",
					shivDocument: l,
					createElement: i,
					createDocumentFragment: a
				};
				e.html5 = g, l(t)
			}(this, t), s._version = l, s._prefixes = v, s.testStyles = S, f.className = f.className.replace(/(^|\s)no-js(\s|$)/, "$1$2") + (u ? " js " + j.join(" ") : ""), s
	}(this, this.document),
	function(e, t, n) {
		function r(e) {
			return "[object Function]" == h.call(e)
		}

		function o(e) {
			return "string" == typeof e
		}

		function i() {}

		function a(e) {
			return !e || "loaded" == e || "complete" == e || "uninitialized" == e
		}

		function c() {
			var e = m.shift();
			y = 1, e ? e.t ? d(function() {
				("c" == e.t ? T.injectCss : T.injectJs)(e.s, 0, e.a, e.x, e.e, 1)
			}, 0) : (e(), c()) : y = 0
		}

		function l(e, n, r, o, i, l, s) {
			function u(t) {
				if (!h && a(f.readyState) && (E.r = h = 1, !y && c(), f.onload = f.onreadystatechange = null, t)) {
					"img" != e && d(function() {
						b.removeChild(f)
					}, 50);
					for (var r in S[n]) S[n].hasOwnProperty(r) && S[n][r].onload()
				}
			}
			var s = s || T.errorTimeout,
				f = t.createElement(e),
				h = 0,
				v = 0,
				E = {
					t: r,
					s: n,
					e: i,
					a: l,
					x: s
				};
			1 === S[n] && (v = 1, S[n] = []), "object" == e ? f.data = n : (f.src = n, f.type = e), f.width = f.height = "0", f.onerror = f.onload = f.onreadystatechange = function() {
				u.call(this, v)
			}, m.splice(o, 0, E), "img" != e && (v || 2 === S[n] ? (b.insertBefore(f, g ? null : p), d(u, s)) : S[n].push(f))
		}

		function s(e, t, n, r, i) {
			return y = 0, t = t || "j", o(e) ? l("c" == t ? j : E, e, t, this.i++, n, r, i) : (m.splice(this.i++, 0, e), 1 == m.length && c()), this
		}

		function u() {
			var e = T;
			return e.loader = {
				load: s,
				i: 0
			}, e
		}
		var f = t.documentElement,
			d = e.setTimeout,
			p = t.getElementsByTagName("script")[0],
			h = {}.toString,
			m = [],
			y = 0,
			v = "MozAppearance" in f.style,
			g = v && !!t.createRange().compareNode,
			b = g ? f : p.parentNode,
			f = e.opera && "[object Opera]" == h.call(e.opera),
			f = !!t.attachEvent && !f,
			E = v ? "object" : f ? "script" : "img",
			j = f ? "script" : E,
			C = Array.isArray || function(e) {
				return "[object Array]" == h.call(e)
			},
			w = [],
			S = {},
			N = {
				timeout: function(e, t) {
					return t.length && (e.timeout = t[0]), e
				}
			},
			x, T;
		T = function(e) {
			function t(e) {
				var e = e.split("!"),
					t = w.length,
					n = e.pop(),
					r = e.length,
					n = {
						url: n,
						origUrl: n,
						prefixes: e
					},
					o, i, a;
				for (i = 0; i < r; i++) a = e[i].split("="), (o = N[a.shift()]) && (n = o(n, a));
				for (i = 0; i < t; i++) n = w[i](n);
				return n
			}

			function a(e, o, i, a, c) {
				var l = t(e),
					s = l.autoCallback;
				l.url.split(".").pop().split("?").shift(), l.bypass || (o && (o = r(o) ? o : o[e] || o[a] || o[e.split("/").pop().split("?")[0]]), l.instead ? l.instead(e, o, i, a, c) : (S[l.url] ? l.noexec = !0 : S[l.url] = 1, i.load(l.url, l.forceCSS || !l.forceJS && "css" == l.url.split(".").pop().split("?").shift() ? "c" : n, l.noexec, l.attrs, l.timeout), (r(o) || r(s)) && i.load(function() {
					u(), o && o(l.origUrl, c, a), s && s(l.origUrl, c, a), S[l.url] = 2
				})))
			}

			function c(e, t) {
				function n(e, n) {
					if (e) {
						if (o(e)) n || (s = function() {
							var e = [].slice.call(arguments);
							u.apply(this, e), f()
						}), a(e, s, t, 0, c);
						else if (Object(e) === e)
							for (p in d = function() {
								var t = 0,
									n;
								for (n in e) e.hasOwnProperty(n) && t++;
								return t
							}(), e) e.hasOwnProperty(p) && (!n && !--d && (r(s) ? s = function() {
								var e = [].slice.call(arguments);
								u.apply(this, e), f()
							} : s[p] = function(e) {
								return function() {
									var t = [].slice.call(arguments);
									e && e.apply(this, t), f()
								}
							}(u[p])), a(e[p], s, t, p, c))
					} else !n && f()
				}
				var c = !!e.test,
					l = e.load || e.both,
					s = e.callback || i,
					u = s,
					f = e.complete || i,
					d, p;
				n(c ? e.yep : e.nope, !!l), l && n(l)
			}
			var l, s, f = this.yepnope.loader;
			if (o(e)) a(e, 0, f, 0);
			else if (C(e))
				for (l = 0; l < e.length; l++) s = e[l], o(s) ? a(s, 0, f, 0) : C(s) ? T(s) : Object(s) === s && c(s, f);
			else Object(e) === e && c(e, f)
		}, T.addPrefix = function(e, t) {
			N[e] = t
		}, T.addFilter = function(e) {
			w.push(e)
		}, T.errorTimeout = 1e4, null == t.readyState && t.addEventListener && (t.readyState = "loading", t.addEventListener("DOMContentLoaded", x = function() {
			t.removeEventListener("DOMContentLoaded", x, 0), t.readyState = "complete"
		}, 0)), e.yepnope = u(), e.yepnope.executeStack = c, e.yepnope.injectJs = function(e, n, r, o, l, s) {
			var u = t.createElement("script"),
				f, h, o = o || T.errorTimeout;
			u.src = e;
			for (h in r) u.setAttribute(h, r[h]);
			n = s ? c : n || i, u.onreadystatechange = u.onload = function() {
				!f && a(u.readyState) && (f = 1, n(), u.onload = u.onreadystatechange = null)
			}, d(function() {
				f || (f = 1, n(1))
			}, o), l ? u.onload() : p.parentNode.insertBefore(u, p)
		}, e.yepnope.injectCss = function(e, n, r, o, a, l) {
			var o = t.createElement("link"),
				s, n = l ? c : n || i;
			o.href = e, o.rel = "stylesheet", o.type = "text/css";
			for (s in r) o.setAttribute(s, r[s]);
			a || (p.parentNode.insertBefore(o, p), d(n, 0))
		}
	}(this, document), Modernizr.load = function() {
		yepnope.apply(window, [].slice.call(arguments, 0))
	}
})();;