(function(window,document)
{
	window.megafonDevice = [];
	var reg = 'spb.';
	if(reg.indexOf('.') == -1)
	{
		reg += '.';
	}
	if(document.location.href === 'http://www.megafon.ru/index.html' || document.location.href === 'https://www.megafon.ru/index.html')
	{
		reg = 'moscow.';
	}
	if(document.location.href === 'http://volga.megafon.ru/' || document.location.href === 'https://volga.megafon.ru/')
	{
		reg = 'volgograd.';
	}
	var check = false,
		inblock = '',
		devJS,
		fixst = '<style>@media screen and (min-width: 1025px) and (max-width: 1439px) {.b-options__itemLink__img_desktop {display: inline-block;margin-top: 20px;left: -25px;height:90px;}}@media screen and (min-width: 768px) and (max-width: 1024px) {.b-options__itemLink__img_tablet {display: inline-block;left: -40px;margin-top: 40px;}}</style>',
		ph = document.getElementById('AdFox_banner_584762');
		devs = document.createElement('script');
		devs.async = true;
		devs.type = 'text/javascript';
		devs.src = '//'+reg+'shop.megafon.ru/catalog/megafon.json';
		if(document.body)
			document.body.appendChild(devs);
		devs.onload = function()
		{
			createBlock();
		}
		devs.onreadystatechange = function()
		{
			if(devs.readyState == 'loaded'){
				createBlock();
			}
		}
	if(!document.getElementsByClassName) {
		document.getElementsByClassName = function (class_name) {
			var elements = document.body.getElementsByTagName("*"),
				length   = elements.length,
				out = [], i;
			for (i = 0; i < length; i += 1) {
				if (elements[i].className.indexOf(class_name) !== -1) {
					out.push(elements[i]);
				}
			}
			return out;
		};
	}
	function createBlock()
	{
		devJS = window.megafonDevice;
		shuffle(devJS);
		if(!+"\v1"){
			var fst = 'style="display:block;"';
		}else{ var fst = '';}
		if(check == false)
		{
			check == true;
			for(var i = 0; i < 2;i++)
			{
				if(devJS[i]){
				switch(devJS[i].currencyId)
				{
					case 'RUR' :
						devJS[i].currencyId = '&#8381;';
						break;
				}
				var pic = devJS[i].picture.replace(/^http[s]?:/,'');
				inblock +='<li class="b-options__item b-options__item_tall b-options__item__specialWidth b-options__item__'+(i==0?'paddingBottom':'last')+'"><div class="b-options__item__clamped"><div class="b-options__adv__wrapper"><a href="https://adfox.megafon.ru/218063/goLink?p2=euse&p1=blzqz&p5=cacao&pr=dabgbrn&puid1=spb.@'+devJS[i].url+'" class="b-options__itemLink"><span class="b-options__itemLink__bg b-options__itemLink__bg_adv"><span class="b-options__itemLink__bg__bgAnimation"></span></span><img src="'+pic+'" alt="" class="b-options__itemLink__img b-options__itemLink__img_desktop" '+fst+'><img src="'+pic+'" alt="" class="b-options__itemLink__img b-options__itemLink__img_tablet"><span class="b-options__itemLink__title b-options__itemLink__title_gadget">'+devJS[i].name+'</span><i class="b-options__itemLink__arrow"></i><span class="b-options__itemLink__icon b-options__itemLink__icon_gadget"><span class="b-options__itemLink__icon__iconAnimation"></span><i class="b-options__itemLink__icon__iconChar b-options__itemLink__icon__iconChar_gadget">'+devJS[i].price+' '+devJS[i].currencyId+'</i></span></a></div></div></li>';
				}
			}
			innerBlock();

		}
	}
	function shuffle(array) {
		var currentIndex = array.length,
			temporaryValue,
			randomIndex;
	  while (0 !== currentIndex) {
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex -= 1;
		temporaryValue = array[currentIndex];
		array[currentIndex] = array[randomIndex];
		array[randomIndex] = temporaryValue;
	  }
	  return array;
	}
	function innerBlock()
	{
		var b1 = document.getElementsByClassName('b-adfox-device-1')[0],
			b2 = document.getElementsByClassName('b-adfox-device-2')[0],
			p;

			try {
				p = b1.parentNode || b2.parentNode || undefined;
			} catch (e) {};

			if (p != undefined)
			{
				try {
					p.removeChild(b1);
					p.removeChild(b2);
				} catch (e) {};
				p.innerHTML += inblock;
				p.innerHTML += fixst;
				fixst = '';
				inblock = '';
			}
			else
			{
				setTimeout(innerBlock,100);
			}
	}
})(parent,parent.document);
document.close();