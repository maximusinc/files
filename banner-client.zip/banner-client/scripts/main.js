(function () {

    BEM.DOM.decl("b-fox-banner", {
    	linkBase: "//adfox.megafon.ru/218063/prepareCode",
    	onSetMod: {
    		js: function() {
                var e, t = this.params, i = [location.protocol, this.linkBase, "?pp=", t.pp, "&ps=", t.ps, "&p2=", t.p2, "&pct=", t.pct, "&plp=", t.plp, "&pli=", t.pli, "&pop=", t.pop, "&puid1=", t.puid1];
                t.random && i.push("&random=", t.random);
                e = new n(i.join(""), t.params || "", t.t);
                this.domElem.html(e.getBannerCode());
                e.createBanner()
            }
    	}
    });
    /**
     * Конструктор основных настроек (синглетон)
     * @return {[type]} [description]
     */
    function e() {
        var e;
        if (!t)
            e = this;
        else
            return t;
        this.phoneWidth = 767;
        this.tabletWidth = 1024;
        this.minWidth = 200;
        this.autoReloads = false;
        this.pc = "display";
        this.pad = "tablet";
        this.phone = "phone";
        this.rnd = function() {
            return Math.floor(Math.random() * 1e6)
        };
        this.pr = window.adfox_pr = typeof window.adfox_pr == "undefined" ? this.rnd() : window.adfox_pr;
        this.ref = escape(document.referrer);
        this.dl = escape(document.location);
        this.banners = [];
        this.state = "";
        this.prev = "";
        this.screen = function() {
            var e = this.getWidth();
            if (e > this.tabletWidth) {
                this.prev = this.state;
                this.state = this.pc
            } else if (e <= this.tabletWidth && e > this.phoneWidth) {
                this.prev = this.state;
                this.state = this.pad
            } else if (e <= this.phoneWidth) {
                this.prev = this.state;
                this.state = this.phone
            }
        };
        this.getWidth = function() {
            var e = window, t = document, i = t.documentElement, n = t.getElementsByTagName("body")[0], s = e.innerWidth || i.clientWidth || n.clientWidth;
            return s
        };
        this.removeBanner = function(e) {
            for (var i = 0; i < t.banners.length; i++) {
                if (t.banners[i] == e) {
                    t.banners[i].ph.innerHTML = "";
                    t.banners.splice(i, 1)
                }
            }
        };
        this.loadDefault = function(e, i, n, s) {
            clearTimeout(n);
            t.gDefaultElement(s, e)
        };
        this.gDefaultElement = function(e, i, n) {
            if (n)
                clearTimeout(n);
            if (e > 9 && e < 100) {
                setTimeout(function s() {
                    if (typeof bmLinks == "function")
                        bmLinks(e, i);
                    else
                        setTimeout(s, 30)
                }, 30)
            }
            if (e == 100) {
                setTimeout(function a() {
                    if (typeof t.slider == "function")
                        t.slider(i);
                    else
                        setTimeout(a, 30)
                }, 30)
            }
        };
        this.enterframe = function() {
            var e = this.pc, i = this.pad, n = this.phone;
            function s() {
                t.screen();
                for (var a = 0; a < t.banners.length; a++) {
                    var o = t.banners[a];
                    if (o.settings != "none") {
                        if (t.parse(e, o.settings) || t.parse(i, o.settings) || t.parse(n, o.settings)) {
                            o.ph.style.display = t.parse(t.state, o.settings) ? "none" : "block"
                        }
                        if (t.parse("scale", o.settings) && o.w != "") {
                            var r = o.ph.parentNode.clientWidth / o.w < 1 ? o.ph.parentNode.clientWidth / o.w : 1;
                            o.ph.style.width = Math.floor(r * o.w) + "px";
                            if (parseInt(o.ph.style.width) < t.minWidth) {
                                o.ph.style.width = Math.floor(t.minWidth) + "px"
                            }
                        }
                    }
                    if (t.autoReloads == true && (o.ph.style.display == "block" || o.ph.style.display == "")) {
                        if (t.state != t.prev) {
                            t.removeBanner(o);
                            o.createBanner()
                        }
                    }
                }
                setTimeout(s, 200)
            }
            s()
        };
        this.parse = function(e, t) {
            var i = e.toLowerCase(), n = t.toLowerCase();
            return n.indexOf(i) != -1
        }
    }
    var t = new e;
    t.enterframe();
    var i = document.createElement("style");
    i.type = "text/css";
    i[i.innerText ? "innerText" : "textContent"] = "img{height:auto;}";
    document.getElementsByTagName("head")[0].appendChild(i);
    /**
     * Функция конструктор для баннера
     * @param   e - часть сформированного запроса URL (параметры указаны в параметрах BEM элемента)
     * @param  	i параметр params из BEM
     * @param  	n - параметр t из BEM
     * @return {[type]}   [description]
     */
    function n(e, i, n) {
        var a = this;
        this.pr1 = t.rnd();
        this.ph = null;
        this.date;
        this.iframe;
        this.settings = i || "none";
        this.link = e;
        this.w = "";
        this.defaultLoad = n;
        this.getCode = function(e) {
            var i = this.link, n = this.pr1, o = this.settings, r = function() {
                if (o != "") {
                    if (t.parse(t.state, o)) {
                        setTimeout(r, 30)
                    } else {
                        s(a.defaultLoad, n, i)
                    }
                } else {
                    s(a.defaultLoad, n, i)
                }
            };
            r()
        };
        this.getBannerCode = function() {
            var e = [];
            if (this.ph == "" || this.ph == null) {
                e.push('<div id="AdFox_banner_' + this.pr1 + '"></div>');
                e.push('<div style="visibility:hidden; position:absolute;"><iframe id="AdFox_iframe_' + this.pr1 + '" width=1 height=1 marginwidth=0 marginheight=0 scrolling=no frameborder=0></iframe></div>')
            }
            return e.join("")
        };
        this.createBanner = function() {
            var e = true, i;
            this.date = new Date;
            this.secParams = "&pr=" + t.pr + "&pt=b&pd=" + this.date.getDate() + "&pw=" + this.date.getDay() + "&pv=" + this.date.getHours() + "&prr=" + t.ref + "&dl=" + t.dl + "&pr1=" + this.pr1 + "&phid=AdFox_banner_" + this.pr1;
            for (var n = 0; n < t.banners.length; n++) {
                if (t.banners[n] == this) {
                    e = false;
                    break
                }
            }
            if (e) {
                t.banners.push(this);
                i = t.banners.length - 1
            }
            this.ph = document.getElementById("AdFox_banner_" + this.pr1);
            this.iframe = document.getElementById("AdFox_iframe_" + this.pr1);
            if (this.ph != null) {
                this.link = this.link.replace(/&amp;/g, "&");
                this.link += this.secParams;
                this.getCode(i)
            }
        }
    }
    /**
     * Загружает скрипт
     * @param  {[type]} e [description]
     * @param  {[type]} i [description]
     * @param  n - url для загрузки скрипта
     * @return {[type]}   [description]
     */
    function s(e, i, n) {
        var s = document.getElementsByTagName("script"), a, o, r = setTimeout(l, 1e4);
        s = s[s.length - 1];
        try {
            if (document.all && !window.opera) {
                a = window.frames["AdFox_iframe_" + i].document
            } else if (document.getElementById) {
                a = document.getElementById("AdFox_iframe_" + i).contentDocument
            }
            /*  Если у iframe элемента есть окно */
            if (a) {
                if (+"1") {
                    a.open();
                    a.close()
                }
                n = n.replace(/&amp;/g, "&");
                o = a.createElement("script");
                o.src = n + "&pap1=" + r;
                o.onload = function() {
                    clearTimeout(r);
                    r = null
                };
                o.onerror = function() {
                    clearTimeout(r);
                    r = null;
                    t.gDefaultElement(e, i)
                };
                o.onreadystatechange = function() {
                    if (o.readyState == "complete") {
                        clearTimeout(r);
                        r = null
                    }
                };
                d()
            }
        } catch (h) {
            t.loadDefault(i, s, r, e)
        }
        function d() {
            setTimeout(function() {
                var e = a.getElementsByTagName("head")[0];
                if (e) {
                    e.appendChild(o)
                } else {
                    d()
                }
            }, 30)
        }
        /* Если не удалось загрузить - грузим заглушку */
        function l(n) {
            if (!r) {
                return
            }
            var a = document.getElementById("AdFox_iframe_" + i);
            a && a.parentNode.removeChild(a);
            t.loadDefault(i, s, r, e)
        }
    }
    function a(e, t) {
        document.getElementById(e).style.visibility = t
    }
    function o(e) {
        a("AdFox_DivBaseFlash_" + e, "hidden");
        a("AdFox_DivOverFlash_" + e, "visible")
    }
    function r(e) {
        a("AdFox_DivOverFlash_" + e, "hidden");
        a("AdFox_DivBaseFlash_" + e, "visible")
    }
    function h(e, t, i) {
        var n = document.getElementById("adfoxBanner" + e).style;
        if (t == "100%")
            n.width = t;
        else
            n.width = t + "px";
        if (i == "100%")
            n.height = i;
        else
            n.height = i + "px"
    }
    function d(e, t, i) {
        var n = document.getElementById(e).style;
        if (t == "100%")
            n.width = t;
        else
            n.width = t + "px";
        if (i == "100%")
            n.height = i;
        else
            n.height = i + "px"
    }
    function l(e, t, i, n, s, a, o, r) {
        if (t == 1)
            d("adfoxFlash1" + e, s, a);
        else if (t == 2) {
            d("adfoxFlash2" + e, o, r);
            if (i == "yes")
                d("adfoxFlash1" + e, s, a);
            if (n == "yes")
                h(e, o, r);
            else
                h(e, s, a)
        }
    }
    function f(e, t, i, n, s) {
        var a = new Image;
        var o = document.getElementById("aEventOpen" + e);
        if (o)
            a.src = o.title + "&rand=" + Math.random() * 1e6 + "&prb=" + Math.random() * 1e6;
        d("adfoxFlash2" + e, n, s);
        if (t != "yes")
            d("adfoxFlash1" + e, 1, 1);
        if (i == "yes")
            h(e, n, s)
    }
    function p(e, t, i, n, s) {
        var a = new Image;
        var o = document.getElementById("aEventClose" + e);
        if (o)
            a.src = o.title + "&rand=" + Math.random() * 1e6 + "&prb=" + Math.random() * 1e6;
        d("adfoxFlash2" + e, 1, 1);
        if (t != "yes")
            d("adfoxFlash1" + e, n, s);
        if (i == "yes")
            h(e, n, s)
    }

})();