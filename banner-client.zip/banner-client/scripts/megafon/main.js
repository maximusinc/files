(function () {

  BEM.DOM.decl("b-fox-banner", {
      linkBase: "//ads.adfox.ru/228840/prepareCode",
      onSetMod: {
        js: function() {
            console.info('BEM onSetMod js execute');
            var self = this,
                callback = function () {
                    var banner,
                      params = this.params,
                      auxArr = [location.protocol, this.linkBase, "?pp=", params.pp, "&ps=", params.ps, "&p2=", params.p2, "&pct=", params.pct, "&plp=", params.plp, "&pli=", params.pli, "&pop=", params.pop, "&puid1=", params.puid1];
                      if (params.random) {
                          auxArr.push("&random=", params.random);
                      }
                      banner = new Banner(auxArr.join(""), params.params || "", params.t);
                      this.domElem.html(banner.getBannerCode());
                      banner.createBanner()
                      console.info('execute rooxTargeting.wait() callback');
                };
                rooxTargeting.wait().then(function () {
                  callback.call(self);
                });
            }
      }
    });

  function DisplayUtils() {
    var e;
        if (!utils)
            e = this;
        else
            return utils;
        this.phoneWidth = 767;
        this.tabletWidth = 1024;
        this.minWidth = 200;
        this.autoReloads = false;
        this.pc = "display";
        this.pad = "tablet";
        this.phone = "phone";
        this.rnd = function() {
            return Math.floor(Math.random() * 1e6)
        };
        this.pr = window.adfox_pr = typeof window.adfox_pr == "undefined" ? this.rnd() : window.adfox_pr;
        this.ref = escape(document.referrer);
        this.dl = escape(document.location);
        this.banners = [];
        this.state = "";
        this.prev = "";
        this.screen = function() {
            var e = this.getWidth();
            if (e > this.tabletWidth) {
                this.prev = this.state;
                this.state = this.pc
            } else if (e <= this.tabletWidth && e > this.phoneWidth) {
                this.prev = this.state;
                this.state = this.pad
            } else if (e <= this.phoneWidth) {
                this.prev = this.state;
                this.state = this.phone
            }
        };
        this.getWidth = function() {
            var e = window, t = document, i = t.documentElement, n = t.getElementsByTagName("body")[0], s = e.innerWidth || i.clientWidth || n.clientWidth;
            return s
        };
        this.removeBanner = function(e) {
            for (var i = 0; i < utils.banners.length; i++) {
                if (utils.banners[i] == e) {
                    utils.banners[i].ph.innerHTML = "";
                    utils.banners.splice(i, 1)
                }
            }
        };
        this.loadDefault = function(e, i, n, s) {
            clearTimeout(n);
            utils.gDefaultElement(s, e)
        };
        this.gDefaultElement = function(e, i, n) {
            if (n)
                clearTimeout(n);
            if (e > 9 && e < 100) {
                setTimeout(function s() {
                    if (typeof bmLinks == "function")
                        bmLinks(e, i);
                    else
                        setTimeout(s, 30)
                }, 30)
            }
            if (e == 100) {
                setTimeout(function a() {
                    if (typeof t.slider == "function")
                        t.slider(i);
                    else
                        setTimeout(a, 30)
                }, 30)
            }
        };
        this.enterframe = function() {
            var e = this.pc, i = this.pad, n = this.phone;
            function s() {
                utils.screen();
                for (var a = 0; a < utils.banners.length; a++) {
                    var o = utils.banners[a];
                    if (o.settings != "none") {
                        if (utils.parse(e, o.settings) || utils.parse(i, o.settings) || utils.parse(n, o.settings)) {
                            o.ph.style.display = utils.parse(t.state, o.settings) ? "none" : "block"
                        }
                        if (utils.parse("scale", o.settings) && o.w != "") {
                            var r = o.ph.parentNode.clientWidth / o.w < 1 ? o.ph.parentNode.clientWidth / o.w : 1;
                            o.ph.style.width = Math.floor(r * o.w) + "px";
                            if (parseInt(o.ph.style.width) < t.minWidth) {
                                o.ph.style.width = Math.floor(t.minWidth) + "px"
                            }
                        }
                    }
                    if (utils.autoReloads == true && (o.ph.style.display == "block" || o.ph.style.display == "")) {
                        if (utils.state != utils.prev) {
                            utils.removeBanner(o);
                            o.createBanner()
                        }
                    }
                }
                setTimeout(s, 200)
            }
            s()
        };
        this.parse = function(e, t) {
            var i = e.toLowerCase(), n = t.toLowerCase();
            return n.indexOf(i) != -1
        }
  }

  var utils = new DisplayUtils();
  utils.enterframe();
  var i = document.createElement("style");
  i.type = "text/css";
  i[i.innerText ? "innerText" : "textContent"] = "img{height:auto;}";
  document.getElementsByTagName("head")[0].appendChild(i);

  function Banner(link, params, timeout) {
    var self = this;
        this.pr1 = utils.rnd();
        this.ph = null;
        this.date;
        this.iframe;
        this.settings = params || "none";
        this.link = link;
        this.w = "";
        this.defaultLoad = timeout;
        this.getCode = function(e) {
            var i = this.link, n = this.pr1, o = this.settings, r = function() {
                if (o != "") {
                    if (utils.parse(utils.state, o)) {
                        setTimeout(r, 30)
                    } else {
                        loadScriptBanner(self.defaultLoad, n, i);
                    }
                } else {
                    loadScriptBanner(self.defaultLoad, n, i);
                }
            };
            r()
        };
        this.getBannerCode = function() {
            var aux = [];
            if (this.ph == "" || this.ph == null) {
                aux.push('<div id="AdFox_banner_' + this.pr1 + '"></div>');
                aux.push('<div style="visibility:hidden; position:absolute;"><iframe id="AdFox_iframe_' + this.pr1 + '" width=1 height=1 marginwidth=0 marginheight=0 scrolling=no frameborder=0></iframe></div>')
            }
            return aux.join("");
        };
        this.createBanner = function() {
            var e = true, i;
            this.date = new Date;
            this.secParams = "&pr=" + utils.pr + "&pt=b&pd=" + this.date.getDate() + "&pw=" + this.date.getDay() + "&pv=" + this.date.getHours() + "&prr=" + utils.ref + "&dl=" + utils.dl + "&pr1=" + this.pr1 + "&phid=AdFox_banner_" + this.pr1;
            for (var n = 0; n < utils.banners.length; n++) {
                if (utils.banners[n] == this) {
                    e = false;
                    break
                }
            }
            if (e) {
                utils.banners.push(this);
                i = utils.banners.length - 1;
            }
            this.ph = document.getElementById("AdFox_banner_" + this.pr1);
            this.iframe = document.getElementById("AdFox_iframe_" + this.pr1);
            if (this.ph != null) {
                this.link = this.link.replace(/&amp;/g, "&");
                this.link += this.secParams;
                this.getCode(i)
            }
        }
  }

  /**
     * Загружает скрипт
     * @param  {[type]} e [description]
     * @param  {[type]} i [description]
     * @param  n - url для загрузки скрипта
     * @return {[type]}   [description]
     */
    function loadScriptBanner(defaultLoad, random, link) {
        var s = document.getElementsByTagName("script"), a, o, r = setTimeout(l, 1e4);
        s = s[s.length - 1];
        try {
            if (document.all && !window.opera) {
                a = window.frames["AdFox_iframe_" + i].document
            } else if (document.getElementById) {
                a = document.getElementById("AdFox_iframe_" + random).contentDocument;
            }
            /*  Если у iframe элемента есть окно */
            if (a) {
                if (+"1") {
                    a.open();
                    a.close()
                }
                link = link.replace(/&amp;/g, "&");
                o = a.createElement("script");
                o.src = link + "&pap1=" + r;
                o.onload = function() {
                    clearTimeout(r);
                    r = null
                };
                o.onerror = function() {
                    clearTimeout(r);
                    r = null;
                    utils.gDefaultElement(defaultLoad, random);
                };
                o.onreadystatechange = function() {
                    if (o.readyState == "complete") {
                        clearTimeout(r);
                        r = null
                    }
                };
                d()
            }
        } catch (h) {
            utils.loadDefault(i, s, r, e)
        }
        function d() {
            setTimeout(function() {
                var e = a.getElementsByTagName("head")[0];
                if (e) {
                    e.appendChild(o)
                } else {
                    d()
                }
            }, 30)
        }
        /* Если не удалось загрузить - грузим заглушку */
        function l(n) {
            if (!r) {
                return
            }
            var a = document.getElementById("AdFox_iframe_" + i);
            a && a.parentNode.removeChild(a);
            t.loadDefault(i, s, r, e)
        }
    }

  /* Ассинхронный код загрузки adfox см. http://sites.help.adfox.ru/page/36/ */
  function AdFox_SetLayerVis(spritename,state){
     document.getElementById(spritename).style.visibility=state;
  }

  function AdFox_Open(AF_id){
     AdFox_SetLayerVis('AdFox_DivBaseFlash_'+AF_id, "hidden");
     AdFox_SetLayerVis('AdFox_DivOverFlash_'+AF_id, "visible");
  }

  function AdFox_Close(AF_id){
     AdFox_SetLayerVis('AdFox_DivOverFlash_'+AF_id, "hidden");
     AdFox_SetLayerVis('AdFox_DivBaseFlash_'+AF_id, "visible");
  }

  function AdFox_getCodeScript(AF_n,AF_id,AF_src){
     var AF_doc;
     if(AF_n<10){
        try{
           if(document.all && !window.opera){
              AF_doc = window.frames['AdFox_iframe_'+AF_id].document;
              }else if(document.getElementById){
                       AF_doc = document.getElementById('AdFox_iframe_'+AF_id).contentDocument;
                       }
           }catch(e){}
      if(AF_doc){
         AF_doc.write('<scr'+'ipt type="text/javascript" src="'+AF_src+'"><\/scr'+'ipt>');
         }else{
            setTimeout('AdFox_getCodeScript('+(++AF_n)+','+AF_id+',"'+AF_src+'");', 100);
            }
            }
  }

  function adfoxSdvigContent(banID, flashWidth, flashHeight){
      var obj = document.getElementById('adfoxBanner'+banID).style;
      if (flashWidth == '100%') obj.width = flashWidth;
          else obj.width = flashWidth + "px";
      if (flashHeight == '100%') obj.height = flashHeight;
          else obj.height = flashHeight + "px";
  }

  function adfoxVisibilityFlash(banName, flashWidth, flashHeight){
          var obj = document.getElementById(banName).style;
      if (flashWidth == '100%') obj.width = flashWidth;
          else obj.width = flashWidth + "px";
      if (flashHeight == '100%') obj.height = flashHeight;
          else obj.height = flashHeight + "px";
  }

  function adfoxStart(banID, FirShowFlNum, constVisFlashFir, sdvigContent, flash1Width, flash1Height, flash2Width, flash2Height){
      if (FirShowFlNum == 1) adfoxVisibilityFlash('adfoxFlash1'+banID, flash1Width, flash1Height);
          else if (FirShowFlNum == 2) {
              adfoxVisibilityFlash('adfoxFlash2'+banID, flash2Width, flash2Height);
              if (constVisFlashFir == 'yes') adfoxVisibilityFlash('adfoxFlash1'+banID, flash1Width, flash1Height);
              if (sdvigContent == 'yes') adfoxSdvigContent(banID, flash2Width, flash2Height);
                  else adfoxSdvigContent(banID, flash1Width, flash1Height);
      }
  }

  function adfoxOpen(banID, constVisFlashFir, sdvigContent, flash2Width, flash2Height){
      var aEventOpenClose = new Image();
      var obj = document.getElementById("aEventOpen"+banID);
      if (obj) aEventOpenClose.src =  obj.title+'&rand='+Math.random()*1000000+'&prb='+Math.random()*1000000;
      adfoxVisibilityFlash('adfoxFlash2'+banID, flash2Width, flash2Height);
      if (constVisFlashFir != 'yes') adfoxVisibilityFlash('adfoxFlash1'+banID, 1, 1);
      if (sdvigContent == 'yes') adfoxSdvigContent(banID, flash2Width, flash2Height);
  }


  function adfoxClose(banID, constVisFlashFir, sdvigContent, flash1Width, flash1Height){
      var aEventOpenClose = new Image();
      var obj = document.getElementById("aEventClose"+banID);
      if (obj) aEventOpenClose.src =  obj.title+'&rand='+Math.random()*1000000+'&prb='+Math.random()*1000000;
      adfoxVisibilityFlash('adfoxFlash2'+banID, 1, 1);
      if (constVisFlashFir != 'yes') adfoxVisibilityFlash('adfoxFlash1'+banID, flash1Width, flash1Height);
      if (sdvigContent == 'yes') adfoxSdvigContent(banID, flash1Width, flash1Height);
  }

})();