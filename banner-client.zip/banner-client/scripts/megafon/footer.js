(function() {
	(function() {
		window.device = {};
		_user_agent = window.navigator.userAgent.toLowerCase();
		device.windows = function() {
			return _find("windows")
		};
		device.windowsTablet = function() {
			return device.windows() && _find("touch")
		};
		device.tablet = function() {
			return device.windowsTablet()
		};
		_find = function(n) {
			return _user_agent.indexOf(n) !== -1
		}
	}).call(this);
	$(function() {
		var n = "ontouchstart" in window ? true : false;
		var e = device.windowsTablet();
		var i = $(".b-additionalmenu__item-customers");
		var a = $("#b-additionalmenu__wrapper");
		var t = $(".b-additionalmenu__submenu");
		var d = "b-additionalmenu__item-hover";
		var o = $(".b-additionalmenu__submenu-link-scroller");
		var s = $(".b-additionalmenu__submenu-link");
		var l = $(".b-additionalmenu__item-cities");
		var u = /iPad/.test(window.navigator.userAgent);
		var r = u ? "touchend" : "click";
		var m;
		a.bind("touchmove", function() {
			m = true
		});
		if (n || e) {
			l.bind(r, function() {
				if (!m) {
					l.toggleClass(d);
					a.toggleClass("b-additionalmenu__wrapper")
				}
				m = false
			});
			i.bind(r, function() {
				i.toggleClass(d);
				$(".b-additionalmenu__submenu").toggleClass("b-additionalmenu__submenu-customers")
			})
		} else {
			l.bind({
				mouseenter: function() {
					l.addClass(d);
					$(".b-additionalmenu-item__link-scroller").addClass("b-additionalmenu-item__link-hover");
					a.removeClass("b-additionalmenu__wrapper")
				},
				mouseleave: function() {
					l.removeClass(d);
					$(".b-additionalmenu-item__link-scroller").removeClass("b-additionalmenu-item__link-hover");
					a.addClass("b-additionalmenu__wrapper")
				},
				click: function() {
					l.removeClass(d);
					a.addClass("b-additionalmenu__wrapper")
				}
			});
			i.bind({
				mouseenter: function() {
					i.addClass(d);
					$(".b-additionalmenu-item__link").addClass("b-additionalmenu-item__link-hover");
					$(".b-additionalmenu__submenu").removeClass("b-additionalmenu__submenu-customers")
				},
				mouseleave: function() {
					i.removeClass(d);
					$(".b-additionalmenu-item__link").removeClass("b-additionalmenu-item__link-hover");
					$(".b-additionalmenu__submenu").addClass("b-additionalmenu__submenu-customers")
				},
				click: function() {
					i.removeClass(d);
					$(".b-additionalmenu__submenu").addClass("b-additionalmenu__submenu-customers")
				}
			})
		}
		o.bind(r, function() {
			if (!m) {
				var n = $(this).text();
				l.children(".b-additionalmenu-item__link-scroller").text(n);
				o.removeClass("b-additionalmenu__submenu-link-hover");
				$(this).addClass("b-additionalmenu__submenu-link-hover")
			}
		});
		s.bind(r, function() {
			var n = $(this).text();
			$(".b-additionalmenu__item-customers").children(".b-additionalmenu-item__link").text(n);
			s.removeClass("b-additionalmenu__submenu-link-hover");
			$(this).addClass("b-additionalmenu__submenu-link-hover")
		});
		setTimeout(function() {
			$(".p__body").bind(r, function(n) {
				if (!$(n.target).hasClass("b-additionalmenu-item__link-scroller") && !$(n.target).closest(".b-additionalmenu__wrapper-click").length) {
					l.removeClass("b-additionalmenu__item-hover");
					a.addClass("b-additionalmenu__wrapper")
				}
				if (!$(n.target).hasClass("b-additionalmenu-item__link") && !$(n.target).closest(".b-additionalmenu__submenu").length) {
					i.removeClass("b-additionalmenu__item-hover");
					t.addClass("b-additionalmenu__submenu-customers")
				}
			})
		}, 10);
		var _ = $(".b-dropdown"),
			a = _.find(".b-dropdown__list-wrap");
		_.bind({
			mouseenter: function() {
				setTimeout(function() {
					var n = a.find(".b-dropdown__link-hover"),
						e = a.find(".b-dropdown__link").outerHeight();
					a.scrollTop(e * n.parent().index() + 5)
				}, 50)
			}
		})
	})
})();;
(function() {
	$(function() {
		$(".b-menu__item").mouseover(function() {
			$(this).addClass("b-menu__item_active")
		}).mouseleave(function() {
			$(this).removeClass("b-menu__item_active")
		})
	})
})();;
(function() {
	! function(e, t) {
		"use strict";

		function n() {
			r.READY || (T.determineEventTypes(), E.each(r.gestures, function(e) {
				M.register(e)
			}), T.onTouch(r.DOCUMENT, d, M.detect), T.onTouch(r.DOCUMENT, g, M.detect), r.READY = !0)
		}
		var r = function y(e, t) {
			return new y.Instance(e, t || {})
		};
		r.VERSION = "1.1.3", r.defaults = {
			behavior: {
				userSelect: "none",
				touchAction: "pan-y",
				touchCallout: "none",
				contentZooming: "none",
				userDrag: "none",
				tapHighlightColor: "rgba(0,0,0,0)"
			}
		}, r.DOCUMENT = document, r.HAS_POINTEREVENTS = navigator.pointerEnabled || navigator.msPointerEnabled, r.HAS_TOUCHEVENTS = "ontouchstart" in e, r.IS_MOBILE = /mobile|tablet|ip(ad|hone|od)|android|silk/i.test(navigator.userAgent), r.NO_MOUSEEVENTS = r.HAS_TOUCHEVENTS && r.IS_MOBILE || r.HAS_POINTEREVENTS, r.CALCULATE_INTERVAL = 25;
		var i = {},
			a = r.DIRECTION_DOWN = "down",
			o = r.DIRECTION_LEFT = "left",
			s = r.DIRECTION_UP = "up",
			c = r.DIRECTION_RIGHT = "right",
			u = r.POINTER_MOUSE = "mouse",
			l = r.POINTER_TOUCH = "touch",
			h = r.POINTER_PEN = "pen",
			p = r.EVENT_START = "start",
			d = r.EVENT_MOVE = "move",
			g = r.EVENT_END = "end",
			f = r.EVENT_RELEASE = "release",
			v = r.EVENT_TOUCH = "touch";
		r.READY = !1, r.plugins = r.plugins || {}, r.gestures = r.gestures || {};
		var E = r.utils = {
				extend: function(e, n, r) {
					for (var i in n)!n.hasOwnProperty(i) || e[i] !== t && r || (e[i] = n[i]);
					return e
				},
				on: function(e, t, n) {
					e.addEventListener(t, n, !1)
				},
				off: function(e, t, n) {
					e.removeEventListener(t, n, !1)
				},
				each: function(e, n, r) {
					var i, a;
					if ("forEach" in e) e.forEach(n, r);
					else if (e.length !== t) {
						for (i = 0, a = e.length; a > i; i++)
							if (n.call(r, e[i], i, e) === !1) return
					} else
						for (i in e)
							if (e.hasOwnProperty(i) && n.call(r, e[i], i, e) === !1) return
				},
				inStr: function(e, t) {
					return e.indexOf(t) > -1
				},
				inArray: function(e, t) {
					if (e.indexOf) {
						var n = e.indexOf(t);
						return -1 === n ? !1 : n
					}
					for (var r = 0, i = e.length; i > r; r++)
						if (e[r] === t) return r;
					return !1
				},
				toArray: function(e) {
					return Array.prototype.slice.call(e, 0)
				},
				hasParent: function(e, t) {
					for (; e;) {
						if (e == t) return !0;
						e = e.parentNode
					}
					return !1
				},
				getCenter: function(e) {
					var t = [],
						n = [],
						r = [],
						i = [],
						a = Math.min,
						o = Math.max;
					return 1 === e.length ? {
						pageX: e[0].pageX,
						pageY: e[0].pageY,
						clientX: e[0].clientX,
						clientY: e[0].clientY
					} : (E.each(e, function(e) {
						t.push(e.pageX), n.push(e.pageY), r.push(e.clientX), i.push(e.clientY)
					}), {
						pageX: (a.apply(Math, t) + o.apply(Math, t)) / 2,
						pageY: (a.apply(Math, n) + o.apply(Math, n)) / 2,
						clientX: (a.apply(Math, r) + o.apply(Math, r)) / 2,
						clientY: (a.apply(Math, i) + o.apply(Math, i)) / 2
					})
				},
				getVelocity: function(e, t, n) {
					return {
						x: Math.abs(t / e) || 0,
						y: Math.abs(n / e) || 0
					}
				},
				getAngle: function(e, t) {
					var n = t.clientX - e.clientX,
						r = t.clientY - e.clientY;
					return 180 * Math.atan2(r, n) / Math.PI
				},
				getDirection: function(e, t) {
					var n = Math.abs(e.clientX - t.clientX),
						r = Math.abs(e.clientY - t.clientY);
					return n >= r ? e.clientX - t.clientX > 0 ? o : c : e.clientY - t.clientY > 0 ? s : a
				},
				getDistance: function(e, t) {
					var n = t.clientX - e.clientX,
						r = t.clientY - e.clientY;
					return Math.sqrt(n * n + r * r)
				},
				getScale: function(e, t) {
					return e.length >= 2 && t.length >= 2 ? this.getDistance(t[0], t[1]) / this.getDistance(e[0], e[1]) : 1
				},
				getRotation: function(e, t) {
					return e.length >= 2 && t.length >= 2 ? this.getAngle(t[1], t[0]) - this.getAngle(e[1], e[0]) : 0
				},
				isVertical: function(e) {
					return e == s || e == a
				},
				setPrefixedCss: function(e, t, n, r) {
					var i = ["", "Webkit", "Moz", "O", "ms"];
					t = E.toCamelCase(t);
					for (var a = 0; a < i.length; a++) {
						var o = t;
						if (i[a] && (o = i[a] + o.slice(0, 1).toUpperCase() + o.slice(1)), o in e.style) {
							e.style[o] = (null == r || r) && n || "";
							break
						}
					}
				},
				toggleBehavior: function(e, t, n) {
					if (t && e && e.style) {
						E.each(t, function(t, r) {
							E.setPrefixedCss(e, r, t, n)
						});
						var r = n && function() {
							return !1
						};
						"none" == t.userSelect && (e.onselectstart = r), "none" == t.userDrag && (e.ondragstart = r)
					}
				},
				toCamelCase: function(e) {
					return e.replace(/[_-]([a-z])/g, function(e) {
						return e[1].toUpperCase()
					})
				}
			},
			T = r.event = {
				preventMouseEvents: !1,
				started: !1,
				shouldDetect: !1,
				on: function(e, t, n, r) {
					var i = t.split(" ");
					E.each(i, function(t) {
						E.on(e, t, n), r && r(t)
					})
				},
				off: function(e, t, n, r) {
					var i = t.split(" ");
					E.each(i, function(t) {
						E.off(e, t, n), r && r(t)
					})
				},
				onTouch: function(e, t, n) {
					var a = this,
						o = function(i) {
							var o, s = i.type.toLowerCase(),
								c = r.HAS_POINTEREVENTS,
								u = E.inStr(s, "mouse");
							u && a.preventMouseEvents || (u && t == p && 0 === i.button ? (a.preventMouseEvents = !1, a.shouldDetect = !0) : c && t == p ? a.shouldDetect = 1 === i.buttons || m.matchType(l, i) : u || t != p || (a.preventMouseEvents = !0, a.shouldDetect = !0), c && t != g && m.updatePointer(t, i), a.shouldDetect && (o = a.doDetect.call(a, i, t, e, n)), o == g && (a.preventMouseEvents = !1, a.shouldDetect = !1, m.reset()), c && t == g && m.updatePointer(t, i))
						};
					return this.on(e, i[t], o), o
				},
				doDetect: function(e, t, n, r) {
					var i = this.getTouchList(e, t),
						a = i.length,
						o = t,
						s = i.trigger,
						c = a;
					t == p ? s = v : t == g && (s = f, c = i.length - (e.changedTouches ? e.changedTouches.length : 1)), c > 0 && this.started && (o = d), this.started = !0;
					var u = this.collectEventData(n, o, i, e);
					return t != g && r.call(M, u), s && (u.changedLength = c, u.eventType = s, r.call(M, u), u.eventType = o, delete u.changedLength), o == g && (r.call(M, u), this.started = !1), o
				},
				determineEventTypes: function() {
					var t;
					return t = r.HAS_POINTEREVENTS ? e.PointerEvent ? ["pointerdown", "pointermove", "pointerup pointercancel lostpointercapture"] : ["MSPointerDown", "MSPointerMove", "MSPointerUp MSPointerCancel MSLostPointerCapture"] : r.NO_MOUSEEVENTS ? ["touchstart", "touchmove", "touchend touchcancel"] : ["touchstart mousedown", "touchmove mousemove", "touchend touchcancel mouseup"], i[p] = t[0], i[d] = t[1], i[g] = t[2], i
				},
				getTouchList: function(e, t) {
					if (r.HAS_POINTEREVENTS) return m.getTouchList();
					if (e.touches) {
						if (t == d) return e.touches;
						var n = [],
							i = [].concat(E.toArray(e.touches), E.toArray(e.changedTouches)),
							a = [];
						return E.each(i, function(e) {
							E.inArray(n, e.identifier) === !1 && a.push(e), n.push(e.identifier)
						}), a
					}
					return e.identifier = 1, [e]
				},
				collectEventData: function(e, t, n, r) {
					var i = l;
					return E.inStr(r.type, "mouse") || m.matchType(u, r) ? i = u : m.matchType(h, r) && (i = h), {
						center: E.getCenter(n),
						timeStamp: Date.now(),
						target: r.target,
						touches: n,
						eventType: t,
						pointerType: i,
						srcEvent: r,
						preventDefault: function() {
							var e = this.srcEvent;
							e.preventManipulation && e.preventManipulation(), e.preventDefault && e.preventDefault()
						},
						stopPropagation: function() {
							this.srcEvent.stopPropagation()
						},
						stopDetect: function() {
							return M.stopDetect()
						}
					}
				}
			},
			m = r.PointerEvent = {
				pointers: {},
				getTouchList: function() {
					var e = [];
					return E.each(this.pointers, function(t) {
						e.push(t)
					}), e
				},
				updatePointer: function(e, t) {
					e == g || e != g && 1 !== t.buttons ? delete this.pointers[t.pointerId] : (t.identifier = t.pointerId, this.pointers[t.pointerId] = t)
				},
				matchType: function(e, t) {
					if (!t.pointerType) return !1;
					var n = t.pointerType,
						r = {};
					return r[u] = n === (t.MSPOINTER_TYPE_MOUSE || u), r[l] = n === (t.MSPOINTER_TYPE_TOUCH || l), r[h] = n === (t.MSPOINTER_TYPE_PEN || h), r[e]
				},
				reset: function() {
					this.pointers = {}
				}
			},
			M = r.detection = {
				gestures: [],
				current: null,
				previous: null,
				stopped: !1,
				startDetect: function(e, t) {
					this.current || (this.stopped = !1, this.current = {
						inst: e,
						startEvent: E.extend({}, t),
						lastEvent: !1,
						lastCalcEvent: !1,
						futureCalcEvent: !1,
						lastCalcData: {},
						name: ""
					}, this.detect(t))
				},
				detect: function(e) {
					if (this.current && !this.stopped) {
						e = this.extendEventData(e);
						var t = this.current.inst,
							n = t.options;
						return E.each(this.gestures, function(r) {
							!this.stopped && t.enabled && n[r.name] && r.handler.call(r, e, t)
						}, this), this.current && (this.current.lastEvent = e), e.eventType == g && this.stopDetect(), e
					}
				},
				stopDetect: function() {
					this.previous = E.extend({}, this.current), this.current = null, this.stopped = !0
				},
				getCalculatedData: function(e, t, n, i, a) {
					var o = this.current,
						s = !1,
						c = o.lastCalcEvent,
						u = o.lastCalcData;
					c && e.timeStamp - c.timeStamp > r.CALCULATE_INTERVAL && (t = c.center, n = e.timeStamp - c.timeStamp, i = e.center.clientX - c.center.clientX, a = e.center.clientY - c.center.clientY, s = !0), (e.eventType == v || e.eventType == f) && (o.futureCalcEvent = e), (!o.lastCalcEvent || s) && (u.velocity = E.getVelocity(n, i, a), u.angle = E.getAngle(t, e.center), u.direction = E.getDirection(t, e.center), o.lastCalcEvent = o.futureCalcEvent || e, o.futureCalcEvent = e), e.velocityX = u.velocity.x, e.velocityY = u.velocity.y, e.interimAngle = u.angle, e.interimDirection = u.direction
				},
				extendEventData: function(e) {
					var t = this.current,
						n = t.startEvent,
						r = t.lastEvent || n;
					(e.eventType == v || e.eventType == f) && (n.touches = [], E.each(e.touches, function(e) {
						n.touches.push({
							clientX: e.clientX,
							clientY: e.clientY
						})
					}));
					var i = e.timeStamp - n.timeStamp,
						a = e.center.clientX - n.center.clientX,
						o = e.center.clientY - n.center.clientY;
					return this.getCalculatedData(e, r.center, i, a, o), E.extend(e, {
						startEvent: n,
						deltaTime: i,
						deltaX: a,
						deltaY: o,
						distance: E.getDistance(n.center, e.center),
						angle: E.getAngle(n.center, e.center),
						direction: E.getDirection(n.center, e.center),
						scale: E.getScale(n.touches, e.touches),
						rotation: E.getRotation(n.touches, e.touches)
					}), e
				},
				register: function(e) {
					var n = e.defaults || {};
					return n[e.name] === t && (n[e.name] = !0), E.extend(r.defaults, n, !0), e.index = e.index || 1e3, this.gestures.push(e), this.gestures.sort(function(e, t) {
						return e.index < t.index ? -1 : e.index > t.index ? 1 : 0
					}), this.gestures
				}
			};
		r.Instance = function(e, t) {
			var i = this;
			n(), this.element = e, this.enabled = !0, E.each(t, function(e, n) {
				delete t[n], t[E.toCamelCase(n)] = e
			}), this.options = E.extend(E.extend({}, r.defaults), t || {}), this.options.behavior && E.toggleBehavior(this.element, this.options.behavior, !0), this.eventStartHandler = T.onTouch(e, p, function(e) {
				i.enabled && e.eventType == p ? M.startDetect(i, e) : e.eventType == v && M.detect(e)
			}), this.eventHandlers = []
		}, r.Instance.prototype = {
			on: function(e, t) {
				var n = this;
				return T.on(n.element, e, t, function(e) {
					n.eventHandlers.push({
						gesture: e,
						handler: t
					})
				}), n
			},
			off: function(e, t) {
				var n = this;
				return T.off(n.element, e, t, function(e) {
					var r = E.inArray({
						gesture: e,
						handler: t
					});
					r !== !1 && n.eventHandlers.splice(r, 1)
				}), n
			},
			trigger: function(e, t) {
				t || (t = {});
				var n = r.DOCUMENT.createEvent("Event");
				n.initEvent(e, !0, !0), n.gesture = t;
				var i = this.element;
				return E.hasParent(t.target, i) && (i = t.target), i.dispatchEvent(n), this
			},
			enable: function(e) {
				return this.enabled = e, this
			},
			dispose: function() {
				var e, t;
				for (E.toggleBehavior(this.element, this.options.behavior, !1), e = -1; t = this.eventHandlers[++e];) E.off(this.element, t.gesture, t.handler);
				return this.eventHandlers = [], T.off(this.element, i[p], this.eventStartHandler), null
			}
		},
		function(e) {
			function t(t, r) {
				var i = M.current;
				if (!(r.options.dragMaxTouches > 0 && t.touches.length > r.options.dragMaxTouches)) switch (t.eventType) {
					case p:
						n = !1;
						break;
					case d:
						if (t.distance < r.options.dragMinDistance && i.name != e) return;
						var u = i.startEvent.center;
						if (i.name != e && (i.name = e, r.options.dragDistanceCorrection && t.distance > 0)) {
							var l = Math.abs(r.options.dragMinDistance / t.distance);
							u.pageX += t.deltaX * l, u.pageY += t.deltaY * l, u.clientX += t.deltaX * l, u.clientY += t.deltaY * l, t = M.extendEventData(t)
						}(i.lastEvent.dragLockToAxis || r.options.dragLockToAxis && r.options.dragLockMinDistance <= t.distance) && (t.dragLockToAxis = !0);
						var h = i.lastEvent.direction;
						t.dragLockToAxis && h !== t.direction && (t.direction = E.isVertical(h) ? t.deltaY < 0 ? s : a : t.deltaX < 0 ? o : c), n || (r.trigger(e + "start", t), n = !0), r.trigger(e, t), r.trigger(e + t.direction, t);
						var v = E.isVertical(t.direction);
						(r.options.dragBlockVertical && v || r.options.dragBlockHorizontal && !v) && t.preventDefault();
						break;
					case f:
						n && t.changedLength <= r.options.dragMaxTouches && (r.trigger(e + "end", t), n = !1);
						break;
					case g:
						n = !1
				}
			}
			var n = !1;
			r.gestures.Drag = {
				name: e,
				index: 50,
				handler: t,
				defaults: {
					dragMinDistance: 10,
					dragDistanceCorrection: !0,
					dragMaxTouches: 1,
					dragBlockHorizontal: !1,
					dragBlockVertical: !1,
					dragLockToAxis: !1,
					dragLockMinDistance: 25
				}
			}
		}("drag"), r.gestures.Gesture = {
			name: "gesture",
			index: 1337,
			handler: function(e, t) {
				t.trigger(this.name, e)
			}
		},
		function(e) {
			function t(t, r) {
				var i = r.options,
					a = M.current;
				switch (t.eventType) {
					case p:
						clearTimeout(n), a.name = e, n = setTimeout(function() {
							a && a.name == e && r.trigger(e, t)
						}, i.holdTimeout);
						break;
					case d:
						t.distance > i.holdThreshold && clearTimeout(n);
						break;
					case f:
						clearTimeout(n)
				}
			}
			var n;
			r.gestures.Hold = {
				name: e,
				index: 10,
				defaults: {
					holdTimeout: 500,
					holdThreshold: 2
				},
				handler: t
			}
		}("hold"), r.gestures.Release = {
			name: "release",
			index: 1 / 0,
			handler: function(e, t) {
				e.eventType == f && t.trigger(this.name, e)
			}
		}, r.gestures.Swipe = {
			name: "swipe",
			index: 40,
			defaults: {
				swipeMinTouches: 1,
				swipeMaxTouches: 1,
				swipeVelocityX: .6,
				swipeVelocityY: .6
			},
			handler: function(e, t) {
				if (e.eventType == f) {
					var n = e.touches.length,
						r = t.options;
					if (n < r.swipeMinTouches || n > r.swipeMaxTouches) return;
					(e.velocityX > r.swipeVelocityX || e.velocityY > r.swipeVelocityY) && (t.trigger(this.name, e), t.trigger(this.name + e.direction, e))
				}
			}
		},
		function(e) {
			function t(t, r) {
				var i, a, o = r.options,
					s = M.current,
					c = M.previous;
				switch (t.eventType) {
					case p:
						n = !1;
						break;
					case d:
						n = n || t.distance > o.tapMaxDistance;
						break;
					case g:
						!E.inStr(t.srcEvent.type, "cancel") && t.deltaTime < o.tapMaxTime && !n && (i = c && c.lastEvent && t.timeStamp - c.lastEvent.timeStamp, a = !1, c && c.name == e && i && i < o.doubleTapInterval && t.distance < o.doubleTapDistance && (r.trigger("doubletap", t), a = !0), (!a || o.tapAlways) && (s.name = e, r.trigger(s.name, t)))
				}
			}
			var n = !1;
			r.gestures.Tap = {
				name: e,
				index: 100,
				handler: t,
				defaults: {
					tapMaxTime: 250,
					tapMaxDistance: 10,
					tapAlways: !0,
					doubleTapDistance: 20,
					doubleTapInterval: 300
				}
			}
		}("tap"), r.gestures.Touch = {
			name: "touch",
			index: -1 / 0,
			defaults: {
				preventDefault: !1,
				preventMouse: !1
			},
			handler: function(e, t) {
				return t.options.preventMouse && e.pointerType == u ? void e.stopDetect() : (t.options.preventDefault && e.preventDefault(), void(e.eventType == v && t.trigger("touch", e)))
			}
		},
		function(e) {
			function t(t, r) {
				switch (t.eventType) {
					case p:
						n = !1;
						break;
					case d:
						if (t.touches.length < 2) return;
						var i = Math.abs(1 - t.scale),
							a = Math.abs(t.rotation);
						if (i < r.options.transformMinScale && a < r.options.transformMinRotation) return;
						M.current.name = e, n || (r.trigger(e + "start", t), n = !0), r.trigger(e, t), a > r.options.transformMinRotation && r.trigger("rotate", t), i > r.options.transformMinScale && (r.trigger("pinch", t), r.trigger("pinch" + (t.scale < 1 ? "in" : "out"), t));
						break;
					case f:
						n && t.changedLength < 2 && (r.trigger(e + "end", t), n = !1)
				}
			}
			var n = !1;
			r.gestures.Transform = {
				name: e,
				index: 45,
				defaults: {
					transformMinScale: .01,
					transformMinRotation: 1
				},
				handler: t
			}
		}("transform"), "function" == typeof define && define.amd ? define(function() {
			return r
		}) : "undefined" != typeof module && module.exports ? module.exports = r : e.Hammer = r
	}(window)
})();;
(function() {
	$(function() {
		"use strict";
		var e = window.globalStorage || {},
			n = window._promo_dummy || {};
		n = "object" === typeof n ? n : {};
		n = "number" === typeof n.length ? {} : n;

		function i() {
			var i = $(".b-banners-slider__spacer").outerHeight(),
				a = null;
			a = e.IS_MOBILE && !e.IS_TABLET ? n.image_mobile : n.image;
			$(".b-banners-slider__link, .b-banners-slider__viewpoint").outerHeight(i);
			$(".b-banners-slider__bg").css("filter", ["progid:DXImageTransform.Microsoft.AlphaImageLoader(src='", a, "',sizingMethod='scale')"].join("")).css("background-image", ["url(", a, ")"].join(""))
		}

		function a() {
			var e = $("<div/>"),
				i = $("<a/>"),
				a = $("<div/>"),
				s = $("<span/>");
			e.addClass("b-banners-slider__viewpoint");
			a.addClass("b-banners-slider__bg");
			i.addClass("b-banners-slider__link");
			i.addClass("b-banners-slider__active");
			i.prop("href", n.href);
			if (n.new_window) {
				i.prop("target", "_blank")
			}
			s.addClass("b-banners-slider__spacer");
			a.append(s);
			i.append(a);
			e.append(i);
			$(".b-banners-slider").html(e)
		}
		if (!window._promo_adblock_disabled) {
			r()
		} else {
			setTimeout(r, 500)
		}

		function s() {
			$(window).off("resize", i).off("adfox-loaded", s)
		}

		function r() {
			var e = $(".b-banners-slider");
			Hammer(e.get(0)).on("dragleft swipeleft", function() {
				if (!e.data("isAnimated")) {
					$(".b-banners-simple-slider__navy-button_action_next").click()
				}
			}).on("dragright swiperight", function() {
				if (!e.data("isAnimated")) {
					$(".b-banners-simple-slider__navy-button_action_prev").click()
				}
			});
			if ($("html").hasClass("ua_adfox_yes")) {
				return
			}
			$(window).on("resize", i).on("adfox-loaded", s);
			a();
			i()
		}
	})
})();;
(function() {
	window.Modernizr = function(e, t, n) {
		function r(e) {
			h.cssText = e
		}

		function o(e, t) {
			return r(v.join(e + ";") + (t || ""))
		}

		function i(e, t) {
			return typeof e === t
		}

		function a(e, t) {
			return !!~("" + e).indexOf(t)
		}

		function c(e, t, r) {
			for (var o in e) {
				var a = t[e[o]];
				if (a !== n) return r === !1 ? e[o] : i(a, "function") ? a.bind(r || t) : a
			}
			return !1
		}
		var l = "2.8.2",
			s = {},
			u = !0,
			f = t.documentElement,
			d = "modernizr",
			p = t.createElement(d),
			h = p.style,
			m, y = {}.toString,
			v = " -webkit- -moz- -o- -ms- ".split(" "),
			g = {},
			b = {},
			E = {},
			j = [],
			C = j.slice,
			w, S = function(e, n, r, o) {
				var i, a, c, l, s = t.createElement("div"),
					u = t.body,
					p = u || t.createElement("body");
				if (parseInt(r, 10))
					while (r--) c = t.createElement("div"), c.id = o ? o[r] : d + (r + 1), s.appendChild(c);
				return i = ["&#173;", '<style id="s', d, '">', e, "</style>"].join(""), s.id = d, (u ? s : p).innerHTML += i, p.appendChild(s), u || (p.style.background = "", p.style.overflow = "hidden", l = f.style.overflow, f.style.overflow = "hidden", f.appendChild(p)), a = n(s, e), u ? s.parentNode.removeChild(s) : (p.parentNode.removeChild(p), f.style.overflow = l), !!a
			},
			N = {}.hasOwnProperty,
			x;
		!i(N, "undefined") && !i(N.call, "undefined") ? x = function(e, t) {
			return N.call(e, t)
		} : x = function(e, t) {
			return t in e && i(e.constructor.prototype[t], "undefined")
		}, Function.prototype.bind || (Function.prototype.bind = function(e) {
			var t = this;
			if (typeof t != "function") throw new TypeError;
			var n = C.call(arguments, 1),
				r = function() {
					if (this instanceof r) {
						var o = function() {};
						o.prototype = t.prototype;
						var i = new o,
							a = t.apply(i, n.concat(C.call(arguments)));
						return Object(a) === a ? a : i
					}
					return t.apply(e, n.concat(C.call(arguments)))
				};
			return r
		}), g.touch = function() {
			var n;
			return "ontouchstart" in e || e.DocumentTouch && t instanceof DocumentTouch ? n = !0 : S(["@media (", v.join("touch-enabled),("), d, ")", "{#modernizr{top:9px;position:absolute}}"].join(""), function(e) {
				n = e.offsetTop === 9
			}), n
		};
		for (var T in g) x(g, T) && (w = T.toLowerCase(), s[w] = g[T](), j.push((s[w] ? "" : "no-") + w));
		return s.addTest = function(e, t) {
				if (typeof e == "object")
					for (var r in e) x(e, r) && s.addTest(r, e[r]);
				else {
					e = e.toLowerCase();
					if (s[e] !== n) return s;
					t = typeof t == "function" ? t() : t, typeof u != "undefined" && u && (f.className += " " + (t ? "" : "no-") + e), s[e] = t
				}
				return s
			}, r(""), p = m = null,
			function(e, t) {
				function n(e, t) {
					var n = e.createElement("p"),
						r = e.getElementsByTagName("head")[0] || e.documentElement;
					return n.innerHTML = "x<style>" + t + "</style>", r.insertBefore(n.lastChild, r.firstChild)
				}

				function r() {
					var e = g.elements;
					return typeof e == "string" ? e.split(" ") : e
				}

				function o(e) {
					var t = y[e[h]];
					return t || (t = {}, m++, e[h] = m, y[m] = t), t
				}

				function i(e, n, r) {
					n || (n = t);
					if (v) return n.createElement(e);
					r || (r = o(n));
					var i;
					return r.cache[e] ? i = r.cache[e].cloneNode() : d.test(e) ? i = (r.cache[e] = r.createElem(e)).cloneNode() : i = r.createElem(e), i.canHaveChildren && !f.test(e) && !i.tagUrn ? r.frag.appendChild(i) : i
				}

				function a(e, n) {
					e || (e = t);
					if (v) return e.createDocumentFragment();
					n = n || o(e);
					var i = n.frag.cloneNode(),
						a = 0,
						c = r(),
						l = c.length;
					for (; a < l; a++) i.createElement(c[a]);
					return i
				}

				function c(e, t) {
					t.cache || (t.cache = {}, t.createElem = e.createElement, t.createFrag = e.createDocumentFragment, t.frag = t.createFrag()), e.createElement = function(n) {
						return g.shivMethods ? i(n, e, t) : t.createElem(n)
					}, e.createDocumentFragment = Function("h,f", "return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&(" + r().join().replace(/[\w\-]+/g, function(e) {
						return t.createElem(e), t.frag.createElement(e), 'c("' + e + '")'
					}) + ");return n}")(g, t.frag)
				}

				function l(e) {
					e || (e = t);
					var r = o(e);
					return g.shivCSS && !p && !r.hasCSS && (r.hasCSS = !!n(e, "article,aside,dialog,figcaption,figure,footer,header,hgroup,main,nav,section{display:block}mark{background:#FF0;color:#000}template{display:none}")), v || c(e, r), e
				}
				var s = "3.7.0",
					u = e.html5 || {},
					f = /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,
					d = /^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,
					p, h = "_html5shiv",
					m = 0,
					y = {},
					v;
				(function() {
					try {
						var e = t.createElement("a");
						e.innerHTML = "<xyz></xyz>", p = "hidden" in e, v = e.childNodes.length == 1 || function() {
							t.createElement("a");
							var e = t.createDocumentFragment();
							return typeof e.cloneNode == "undefined" || typeof e.createDocumentFragment == "undefined" || typeof e.createElement == "undefined"
						}()
					} catch (n) {
						p = !0, v = !0
					}
				})();
				var g = {
					elements: u.elements || "abbr article aside audio bdi canvas data datalist details dialog figcaption figure footer header hgroup main mark meter nav output progress section summary template time video",
					version: s,
					shivCSS: u.shivCSS !== !1,
					supportsUnknownElements: v,
					shivMethods: u.shivMethods !== !1,
					type: "default",
					shivDocument: l,
					createElement: i,
					createDocumentFragment: a
				};
				e.html5 = g, l(t)
			}(this, t), s._version = l, s._prefixes = v, s.testStyles = S, f.className = f.className.replace(/(^|\s)no-js(\s|$)/, "$1$2") + (u ? " js " + j.join(" ") : ""), s
	}(this, this.document),
	function(e, t, n) {
		function r(e) {
			return "[object Function]" == h.call(e)
		}

		function o(e) {
			return "string" == typeof e
		}

		function i() {}

		function a(e) {
			return !e || "loaded" == e || "complete" == e || "uninitialized" == e
		}

		function c() {
			var e = m.shift();
			y = 1, e ? e.t ? d(function() {
				("c" == e.t ? T.injectCss : T.injectJs)(e.s, 0, e.a, e.x, e.e, 1)
			}, 0) : (e(), c()) : y = 0
		}

		function l(e, n, r, o, i, l, s) {
			function u(t) {
				if (!h && a(f.readyState) && (E.r = h = 1, !y && c(), f.onload = f.onreadystatechange = null, t)) {
					"img" != e && d(function() {
						b.removeChild(f)
					}, 50);
					for (var r in S[n]) S[n].hasOwnProperty(r) && S[n][r].onload()
				}
			}
			var s = s || T.errorTimeout,
				f = t.createElement(e),
				h = 0,
				v = 0,
				E = {
					t: r,
					s: n,
					e: i,
					a: l,
					x: s
				};
			1 === S[n] && (v = 1, S[n] = []), "object" == e ? f.data = n : (f.src = n, f.type = e), f.width = f.height = "0", f.onerror = f.onload = f.onreadystatechange = function() {
				u.call(this, v)
			}, m.splice(o, 0, E), "img" != e && (v || 2 === S[n] ? (b.insertBefore(f, g ? null : p), d(u, s)) : S[n].push(f))
		}

		function s(e, t, n, r, i) {
			return y = 0, t = t || "j", o(e) ? l("c" == t ? j : E, e, t, this.i++, n, r, i) : (m.splice(this.i++, 0, e), 1 == m.length && c()), this
		}

		function u() {
			var e = T;
			return e.loader = {
				load: s,
				i: 0
			}, e
		}
		var f = t.documentElement,
			d = e.setTimeout,
			p = t.getElementsByTagName("script")[0],
			h = {}.toString,
			m = [],
			y = 0,
			v = "MozAppearance" in f.style,
			g = v && !!t.createRange().compareNode,
			b = g ? f : p.parentNode,
			f = e.opera && "[object Opera]" == h.call(e.opera),
			f = !!t.attachEvent && !f,
			E = v ? "object" : f ? "script" : "img",
			j = f ? "script" : E,
			C = Array.isArray || function(e) {
				return "[object Array]" == h.call(e)
			},
			w = [],
			S = {},
			N = {
				timeout: function(e, t) {
					return t.length && (e.timeout = t[0]), e
				}
			},
			x, T;
		T = function(e) {
			function t(e) {
				var e = e.split("!"),
					t = w.length,
					n = e.pop(),
					r = e.length,
					n = {
						url: n,
						origUrl: n,
						prefixes: e
					},
					o, i, a;
				for (i = 0; i < r; i++) a = e[i].split("="), (o = N[a.shift()]) && (n = o(n, a));
				for (i = 0; i < t; i++) n = w[i](n);
				return n
			}

			function a(e, o, i, a, c) {
				var l = t(e),
					s = l.autoCallback;
				l.url.split(".").pop().split("?").shift(), l.bypass || (o && (o = r(o) ? o : o[e] || o[a] || o[e.split("/").pop().split("?")[0]]), l.instead ? l.instead(e, o, i, a, c) : (S[l.url] ? l.noexec = !0 : S[l.url] = 1, i.load(l.url, l.forceCSS || !l.forceJS && "css" == l.url.split(".").pop().split("?").shift() ? "c" : n, l.noexec, l.attrs, l.timeout), (r(o) || r(s)) && i.load(function() {
					u(), o && o(l.origUrl, c, a), s && s(l.origUrl, c, a), S[l.url] = 2
				})))
			}

			function c(e, t) {
				function n(e, n) {
					if (e) {
						if (o(e)) n || (s = function() {
							var e = [].slice.call(arguments);
							u.apply(this, e), f()
						}), a(e, s, t, 0, c);
						else if (Object(e) === e)
							for (p in d = function() {
								var t = 0,
									n;
								for (n in e) e.hasOwnProperty(n) && t++;
								return t
							}(), e) e.hasOwnProperty(p) && (!n && !--d && (r(s) ? s = function() {
								var e = [].slice.call(arguments);
								u.apply(this, e), f()
							} : s[p] = function(e) {
								return function() {
									var t = [].slice.call(arguments);
									e && e.apply(this, t), f()
								}
							}(u[p])), a(e[p], s, t, p, c))
					} else !n && f()
				}
				var c = !!e.test,
					l = e.load || e.both,
					s = e.callback || i,
					u = s,
					f = e.complete || i,
					d, p;
				n(c ? e.yep : e.nope, !!l), l && n(l)
			}
			var l, s, f = this.yepnope.loader;
			if (o(e)) a(e, 0, f, 0);
			else if (C(e))
				for (l = 0; l < e.length; l++) s = e[l], o(s) ? a(s, 0, f, 0) : C(s) ? T(s) : Object(s) === s && c(s, f);
			else Object(e) === e && c(e, f)
		}, T.addPrefix = function(e, t) {
			N[e] = t
		}, T.addFilter = function(e) {
			w.push(e)
		}, T.errorTimeout = 1e4, null == t.readyState && t.addEventListener && (t.readyState = "loading", t.addEventListener("DOMContentLoaded", x = function() {
			t.removeEventListener("DOMContentLoaded", x, 0), t.readyState = "complete"
		}, 0)), e.yepnope = u(), e.yepnope.executeStack = c, e.yepnope.injectJs = function(e, n, r, o, l, s) {
			var u = t.createElement("script"),
				f, h, o = o || T.errorTimeout;
			u.src = e;
			for (h in r) u.setAttribute(h, r[h]);
			n = s ? c : n || i, u.onreadystatechange = u.onload = function() {
				!f && a(u.readyState) && (f = 1, n(), u.onload = u.onreadystatechange = null)
			}, d(function() {
				f || (f = 1, n(1))
			}, o), l ? u.onload() : p.parentNode.insertBefore(u, p)
		}, e.yepnope.injectCss = function(e, n, r, o, a, l) {
			var o = t.createElement("link"),
				s, n = l ? c : n || i;
			o.href = e, o.rel = "stylesheet", o.type = "text/css";
			for (s in r) o.setAttribute(s, r[s]);
			a || (p.parentNode.insertBefore(o, p), d(n, 0))
		}
	}(this, document), Modernizr.load = function() {
		yepnope.apply(window, [].slice.call(arguments, 0))
	}
})();;