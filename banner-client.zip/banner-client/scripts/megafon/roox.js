(function ($) {
	window.rooxTargeting = (function () {
		var targetingData,
			body = document.body,
			defer = $.Deferred(),
			makeIframe = function () {
				var random = Math.floor(Math.random() * 1e6),
					iframe = '<iframe id="RooX_iframe_' + random + '" src="data.html" width=1 height=1 marginwidth=0 marginheight=0 scrolling=no frameborder=0></iframe>';
				$('body').append(iframe);
				console.info( 'add element to body: ' + iframe);
			},
			get = function () {
				return targetingData && targetingData.data || '';
			},
			wait = function () {
				return defer.promise();
			};
		makeIframe();
		$(window).on('message', function (e) {
			var data = e.originalEvent.data;
			console.info('postMessage from RooX: ', e.originalEvent.data );
			targetingData = JSON.parse(data);
			defer.resolve( targetingData );
		});

		window.setTimeout(function () {
			console.info('resolve Defaulf after 1200');
			defer.resolve({});
		}, 1200);

		return {
			wait: wait,
			get: get
		};
	})();
})(window.jQuery);